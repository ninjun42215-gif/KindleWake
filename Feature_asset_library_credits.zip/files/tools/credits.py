#!/usr/bin/env python3
"""Single source of truth for credits: data/credits.json.
  python3 tools/credits.py build   -> writes CREDITS.md from the json
  python3 tools/credits.py check   -> verifies the json against the files on disk (library folders, licence texts, music)
"""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load():
    return json.load(open(os.path.join(ROOT, "data", "credits.json"), encoding="utf-8"))

def build():
    c = load()
    out = ["# Credits", "", "**%s**" % c["game"], "", "Created by **%s**." % c["creator"], "", c["usage"], "",
           "Generated from `data/credits.json` by `python3 tools/credits.py build`. Edit the json, not this file.", "",
           "| Pack | Kind | Author | Licence | In the project | Used for | Restrictions / notes |", "|---|---|---|---|---|---|---|"]
    for p in c["packs"]:
        where = "yes" if p["stored"] else "no"
        out.append("| %s | %s | %s | %s | %s | %s | %s |" % (p["title"], p["kind"], p["author"], p["license"], where, p["used"],
                   " ".join(x for x in (p["restrictions"], p["note"]) if x)))
    open(os.path.join(ROOT, "CREDITS.md"), "w", encoding="utf-8").write("\n".join(out) + "\n")
    print("CREDITS.md written (%d packs)" % len(c["packs"]))

def check() -> int:
    c = load(); bad = []
    if c.get("creator") != "Jose Basinillo Jr.":
        bad.append("creator missing")
    for p in c["packs"]:
        for k in ("id", "title", "kind", "author", "license", "stored", "used"):
            if k not in p: bad.append("%s: missing %s" % (p.get("id"), k))
        if p.get("license_file") and not os.path.exists(os.path.join(ROOT, p["license_file"])):
            bad.append("%s: licence file missing %s" % (p["id"], p["license_file"]))
        if p.get("stored") and p["kind"] in ("sprites", "tiles") and p["used"] == "library":
            if not os.path.isdir(os.path.join(ROOT, "assets", "library", p["id"])): bad.append("%s: library folder missing" % p["id"])
    audio = json.load(open(os.path.join(ROOT, "data", "audio.json"), encoding="utf-8"))
    for ctx, e in audio["music"].items():
        path = os.path.join(ROOT, e["stream"].replace("res://", ""))
        if not os.path.exists(path): bad.append("audio %s: %s missing" % (ctx, e["stream"]))
    for b in bad: print("CREDITS CHECK:", b)
    print("credits check: %d packs, %d problems" % (len(c["packs"]), len(bad)))
    return 1 if bad else 0

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "build": build()
    elif len(sys.argv) > 1 and sys.argv[1] == "check": sys.exit(check())
    else: print(__doc__)
