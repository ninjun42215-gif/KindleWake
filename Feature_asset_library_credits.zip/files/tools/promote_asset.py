#!/usr/bin/env python3
"""Copies a file or folder out of assets/library (ignored by Godot) into a folder Godot imports.
  python3 tools/promote_asset.py assets/library/<pack>/<path> assets/sprites/<where>
Then wire it in code and fill in "used" for that pack in data/credits.json (and run tools/credits.py build)."""
import os, shutil, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__); return 2
    src = os.path.join(ROOT, sys.argv[1]); dst = os.path.join(ROOT, sys.argv[2])
    if not os.path.exists(src) or "assets/library" not in sys.argv[1].replace("\\", "/"):
        print("source must exist and be inside assets/library"); return 1
    if os.path.abspath(dst).startswith(os.path.join(ROOT, "assets", "library")):
        print("destination must be outside assets/library"); return 1
    if os.path.isdir(src):
        shutil.copytree(src, os.path.join(dst, os.path.basename(src.rstrip("/"))), dirs_exist_ok=True)
    else:
        os.makedirs(dst, exist_ok=True); shutil.copy2(src, dst)
    print("promoted %s -> %s (remember: credit it in data/credits.json)" % (sys.argv[1], sys.argv[2]))
    return 0

if __name__ == "__main__":
    sys.exit(main())
