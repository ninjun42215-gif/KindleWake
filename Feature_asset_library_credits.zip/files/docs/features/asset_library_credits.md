# Feature asset_library_credits (v0.9.4)

Asset library, music per scene, credits for every pack. Creator: Jose Basinillo Jr.; the game is for private use. Not run in Godot.

## What it adds
- `assets/library/` (17 sprite/tile packs, `.gdignore`, `LICENSES/`), `assets/audio/music/` (40 OGG tracks): **these binaries live in the main `Kindlewake_Project.zip` only**; this pack carries the code, data, docs and licence texts. Merge it into a project that already has the asset folders (or into one that has not: music then falls back to the generated drone).
- `data/audio.json`, `AudioManager.start_music(context)` (home, world, battle, room), callers updated in `home_scene.gd`, `world_scene.gd`, `battle_scene.gd`.
- `data/credits.json` -> `CREDITS.md` (`tools/credits.py build|check`), Home Credits button and creator line (`HomeScene.credits_text()`).
- `tools/promote_asset.py` (copy a library file into an imported folder), small fixes to `tools/merge_features.py list` and the linter (`AudioStream`).
- Tests: `_test_credits_and_audio`.

## Merging
`python3 -I tools/merge_features.py apply Feature_asset_library_credits.zip` (dry run), then `--apply`. Docs (GDD, WIP, handoff, prompt) may need a hand merge; the GDD text is section 11.13.

## Check on a phone
Music loops cleanly and the volume balance between tracks; the Credits dialog scrolls; nothing in `assets/library/` ends up in the APK (it must not).
