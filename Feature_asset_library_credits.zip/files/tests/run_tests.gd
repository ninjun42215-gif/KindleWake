extends SceneTree
## Headless test-suite + AI-vs-AI battle simulator. Run from the project folder:
##   godot --headless --path . --script res://tests/run_tests.gd
## Exit code 0 = every check passed. (Autoloads are not available in --script mode, so the
## scripts are instantiated manually.)

var checks: int = 0
var failures: int = 0
var gd: Node
var ss: Node
var screen_closed: int = 0
var card_taps: int = 0
var chosen_count: int = 0
var chosen_lead: String = ""
var chosen_look: Dictionary = {}
var wm: WorldMap


func _initialize() -> void:
    gd = load("res://scripts/core/game_data.gd").new()
    gd.reload()
    ss = load("res://scripts/core/save_system.gd").new()
    _test_data()
    _test_class_tree()
    _test_map()
    _test_combat()
    _test_turn_queue()
    _test_controller()
    _test_auto_battle()
    _test_progression()
    _test_sigils()
    _test_weapon_skills()
    _test_world()
    _test_world_data()
    _test_world_gate_map()
    _test_world_content()
    _test_town_buildings()
    _test_world_story()
    _test_recruitment()
    _test_region_difficulty()
    _test_world_battles()
    _test_town_shops()
    _test_looks_and_select()
    _test_shop_and_screen()
    _test_view_only_screen()
    _test_world_save_format()
    _test_save_system()
    _test_settings_store()
    _test_home_navigation()
    _test_credits_and_audio()
    _test_rooms()
    _simulate_battles(30)
    print("")
    print("Checks: %d   Failures: %d" % [checks, failures])
    quit(1 if failures > 0 else 0)


func check(cond: bool, label: String) -> void:
    checks += 1
    if cond:
        print("  ok    " + label)
    else:
        failures += 1
        print("  FAIL  " + label)


func _make_unit(uid: int, char_id: String, team: String, cell: Vector2i, facing: int) -> BattleUnit:
    var cdef: Dictionary = gd.characters[char_id]
    var cls: Dictionary = gd.classes[str(cdef["class_id"])]
    return BattleUnit.create(uid, char_id, cdef, cls, team, cell, facing)


func _test_data() -> void:
    print("[data]")
    check(gd.classes.size() >= 5, "classes loaded")
    check(gd.weapons.size() >= 5, "weapons loaded")
    check(gd.characters.has("torren"), "characters loaded")
    var def: Dictionary = gd.battle_def("battle_01")
    check(not def.is_empty(), "battle_01 loaded")
    var db: Dictionary = gd.as_db()
    var spawns: Array = def["units"]
    for spawn in spawns:
        var cid: String = str(spawn["character_id"])
        check(db["characters"].has(cid), "spawn character exists: " + cid)
        var cdef: Dictionary = db["characters"][cid]
        check(db["classes"].has(str(cdef["class_id"])), "class exists for " + cid)
        check(db["weapons"].has(str(cdef["weapon_id"])), "weapon exists for " + cid)


func _test_class_tree() -> void:
    print("[class tree]")
    var stat_keys: Array = ["hp", "mp", "str", "dex", "int", "vit", "spd", "lck", "acc", "eva", "ldr", "mor"]
    var targeted: Dictionary = {}
    for cid in gd.classes.keys():
        var cdef: Dictionary = gd.classes[cid]
        for t in cdef.get("promotes_to", []):
            targeted[str(t)] = str(cid)
    var growth_ok := true
    var fields_ok := true
    var tree_ok := true
    var reach_ok := true
    var bad: Array[String] = []
    for cid in gd.classes.keys():
        var cdef: Dictionary = gd.classes[cid]
        for f in ["name", "branch", "tier", "move", "jump", "growth", "promotes_to"]:
            if not cdef.has(f):
                fields_ok = false
                bad.append("%s lacks %s" % [cid, f])
        if int(cdef.get("tier", 0)) < 1 or int(cdef.get("tier", 0)) > 4 or int(cdef.get("move", 0)) < 1 or int(cdef.get("jump", 0)) < 1:
            fields_ok = false
            bad.append("%s has bad tier/move/jump" % cid)
        var growth: Dictionary = cdef.get("growth", {})
        if not growth.has("hp"):
            growth_ok = false
            bad.append("%s has no hp growth" % cid)
        for k in growth.keys():
            if not stat_keys.has(str(k)) or int(growth[k]) < 0 or int(growth[k]) > 100:
                growth_ok = false
                bad.append("%s growth %s" % [cid, str(k)])
        for t in cdef.get("promotes_to", []):
            var tdef: Dictionary = gd.classes.get(str(t), {})
            if tdef.is_empty():
                tree_ok = false
                bad.append("%s promotes to missing class %s" % [cid, str(t)])
                continue
            if int(tdef.get("tier", 0)) != int(cdef.get("tier", 0)) + 1 or str(tdef.get("branch", "")) != str(cdef.get("branch", "")):
                tree_ok = false
                bad.append("%s -> %s must be the next tier in the same branch" % [cid, str(t)])
        var is_root: bool = int(cdef.get("tier", 1)) == 1 or bool(cdef.get("story_only", false))
        if not is_root and not targeted.has(str(cid)):
            reach_ok = false
            bad.append("%s can never be reached" % cid)
    for line in bad:
        print("        " + line)
    check(gd.classes.size() >= 28, "the full class tree is in data (%d classes)" % gd.classes.size())
    check(fields_ok, "every class has name, branch, tier 1-4, move, jump, growth and promotes_to")
    check(growth_ok, "growth tables use known stats with chances from 0 to 100 and always include hp")
    check(tree_ok, "every promotion target exists, is one tier higher and stays in the same branch")
    check(reach_ok, "every class is a tier-1 start, a story-only class or the target of a promotion")
    for cid in ["berserker", "paladin"]:
        check(bool((gd.classes[cid] as Dictionary).get("locked", false)), cid + " is locked until its requirement can be checked")
    check(bool((gd.classes["commander"] as Dictionary).get("story_only", false)) and not targeted.has("commander"), "commander is story-only and nothing promotes into it")
    check(int((gd.classes["thief"] as Dictionary)["jump"]) == 2 and int((gd.classes["scout"] as Dictionary)["jump"]) == 2, "thieves and scouts jump 2 (GDD 3)")


func _test_map() -> void:
    print("[map]")
    var m: BattleMap = BattleMap.from_battle_def(gd.battle_def("battle_01"), gd.terrain)
    check(m.width == 12 and m.height == 10, "map is 12x10")
    check(m.terrain_id(Vector2i(5, 4)) == "bridge", "bridge at (5,4)")
    check(m.move_cost(Vector2i(0, 4)) == -1, "deep water blocks movement")
    check(m.height_at(Vector2i(8, 1)) == 2, "hill height 2 at (8,1)")
    var reach: Dictionary = m.compute_reach(Vector2i(5, 7), 5, 1, {}, {})
    var cost: Dictionary = reach["cost"]
    check(cost.has(Vector2i(5, 4)) and int(cost[Vector2i(5, 4)]) == 3, "bridge reachable at cost 3")
    check(not cost.has(Vector2i(0, 4)), "deep water not reachable")
    var path: Array[Vector2i] = m.path_from(reach, Vector2i(5, 7), Vector2i(5, 4))
    check(path.size() == 3 and path[2] == Vector2i(5, 4), "path to bridge has 3 steps")
    var blocked: Dictionary = m.compute_reach(Vector2i(5, 7), 5, 1, {Vector2i(5, 5): true}, {})
    var bcost: Dictionary = blocked["cost"]
    check(not bcost.has(Vector2i(5, 4)), "enemy on the bridge blocks the crossing")
    var hill: Dictionary = m.compute_reach(Vector2i(7, 3), 6, 1, {}, {})
    var hcost: Dictionary = hill["cost"]
    check(hcost.has(Vector2i(8, 1)), "hill top reachable by climbing one step at a time")
    var low: Dictionary = m.compute_reach(Vector2i(9, 2), 3, 1, {}, {})
    var lcost: Dictionary = low["cost"]
    check(not lcost.has(Vector2i(9, 1)), "jump 1 cannot climb a 2-high step")
    check(not m.has_line_of_sight(Vector2i(11, 2), Vector2i(9, 2)), "rock wall blocks line of sight")
    check(m.has_line_of_sight(Vector2i(5, 8), Vector2i(5, 1)), "river does not block line of sight")


func _test_combat() -> void:
    print("[combat]")
    check(is_equal_approx(CombatCalc.base_damage(20.0, 20.0), 10.0), "defense equal to attack halves damage")
    check(is_equal_approx(CombatCalc.base_damage(10.0, 0.0), 10.0), "no defense = full damage")
    var m: BattleMap = BattleMap.from_battle_def(gd.battle_def("battle_01"), gd.terrain)
    var a: BattleUnit = _make_unit(1, "bram", "player", Vector2i(5, 7), 0)
    var r: BattleUnit = _make_unit(2, "roadreaver", "enemy", Vector2i(5, 6), 2)
    var units: Array = [a, r]
    var w: Dictionary = gd.weapon_def(a.weapon_id)
    var front: Dictionary = CombatCalc.preview(a, r, w, m, units)
    check(str(front["facing"]) == "front", "attacker in front of the defender")
    r.facing = 0
    var rear: Dictionary = CombatCalc.preview(a, r, w, m, units)
    check(str(rear["facing"]) == "rear", "attacker behind the defender")
    check(int(rear["dmg_max"]) > int(front["dmg_max"]), "rear attacks deal more damage")
    check(int(rear["crit"]) == int(front["crit"]) + 10, "rear attacks gain +10 crit")
    var ally: BattleUnit = _make_unit(3, "torren", "player", Vector2i(5, 5), 0)
    units.append(ally)
    var flank: Dictionary = CombatCalc.preview(a, r, w, m, units)
    check(bool(flank["flank"]) and int(flank["dmg_max"]) > int(rear["dmg_max"]), "ally on the opposite side gives a flank bonus")
    var archer: BattleUnit = _make_unit(4, "sela", "player", Vector2i(8, 1), 2)
    var low_target: BattleUnit = _make_unit(5, "roadreaver", "enemy", Vector2i(8, 3), 0)
    var high: Dictionary = CombatCalc.preview(archer, low_target, gd.weapon_def(archer.weapon_id), m, [archer, low_target])
    check(int(high["height_diff"]) == 2, "height advantage detected (+2)")
    check(int(high["hit"]) >= 10 and int(high["hit"]) <= 98, "hit chance stays within 10-98")
    var rng1 := RandomNumberGenerator.new()
    var rng2 := RandomNumberGenerator.new()
    rng1.seed = 42
    rng2.seed = 42
    var d1: BattleUnit = _make_unit(6, "roadreaver", "enemy", Vector2i(5, 6), 0)
    var d2: BattleUnit = _make_unit(7, "roadreaver", "enemy", Vector2i(5, 6), 0)
    var res1: Dictionary = CombatCalc.resolve(a, d1, w, m, [a, d1], rng1)
    var res2: Dictionary = CombatCalc.resolve(a, d2, w, m, [a, d2], rng2)
    check(res1["hit"] == res2["hit"] and res1["damage"] == res2["damage"], "same RNG seed gives the same result")


func _test_turn_queue() -> void:
    print("[turn queue]")
    var fast: BattleUnit = _make_unit(1, "sela", "player", Vector2i(1, 1), 0)
    var slow: BattleUnit = _make_unit(2, "brother_wystan", "player", Vector2i(2, 2), 0)
    fast.ctb = TurnQueue.initial_ctb(fast)
    slow.ctb = TurnQueue.initial_ctb(slow)
    check(TurnQueue.peek_next([fast, slow]) == fast, "faster unit acts first")
    var order: Array = TurnQueue.timeline([fast, slow], 10)
    var fast_count := 0
    for o in order:
        var u: BattleUnit = o
        if u.id == 1:
            fast_count += 1
    check(fast_count > 10 - fast_count, "faster unit acts more often (%d of 10)" % fast_count)
    check(TurnQueue.delay_after_turn(fast, true, true, {}) > TurnQueue.delay_after_turn(fast, false, false, {}), "acting costs more time than waiting")


func _test_controller() -> void:
    print("[controller]")
    var c := BattleController.new()
    c.setup(gd.battle_def("battle_01"), gd.as_db(), 12345)
    check(c.units.size() == 8, "8 units spawned")
    c.begin()
    check(c.active_unit() != null, "someone is active after begin()")
    var guard := 0
    while c.active_unit().team != "player" and guard < 20:
        c.run_ai_turn()
        guard += 1
    var a: BattleUnit = c.active_unit()
    check(a.team == "player", "a player unit becomes active")
    var moves: Array[Vector2i] = c.move_targets(a)
    check(moves.size() > 0, "active unit has legal moves")
    check(c.try_move(a, moves[0]), "move succeeds")
    check(not c.try_move(a, moves[0]), "cannot move twice in one turn")
    var json: String = JSON.stringify(c.to_dict())
    var parsed: Dictionary = JSON.parse_string(json)
    var c2 := BattleController.new()
    check(c2.restore(gd.battle_def("battle_01"), gd.as_db(), parsed), "restore from JSON succeeds")
    var same := c2.units.size() == c.units.size() and c2.active_id == c.active_id and c2.turn_count == c.turn_count
    for i in range(c.units.size()):
        if c.units[i].cell != c2.units[i].cell or c.units[i].hp != c2.units[i].hp or c.units[i].has_moved != c2.units[i].has_moved:
            same = false
    check(same, "restored state equals saved state")
    check(c.rng.randi() == c2.rng.randi(), "RNG state restored exactly")
    var bad: Dictionary = parsed.duplicate()
    bad["battle_id"] = "other"
    check(not BattleController.new().restore(gd.battle_def("battle_01"), gd.as_db(), bad), "restore rejects a different battle id")


## Auto Battle = the AI plays the player's units (run_ai_turn(true)); also covers the cleric's heal logic.
func _test_auto_battle() -> void:
    print("[auto battle]")
    var c := BattleController.new()
    c.setup(gd.battle_def("battle_01"), gd.as_db(), 777)
    c.begin()
    var cal: BattleUnit = null
    var bram: BattleUnit = null
    for o in c.units:
        var u: BattleUnit = o
        if u.character_id == "brother_wystan":
            cal = u
        elif u.character_id == "bram":
            bram = u
    check(cal != null and bram != null, "Brother Wystan and Sir Bram are in the battle")
    if cal == null or bram == null:
        return
    c.active_id = cal.id
    cal.has_moved = false
    cal.has_acted = false
    var idle_plan: Dictionary = BattleAI.decide(cal, c)
    check(str(idle_plan["action"]) != "skill", "cleric does not cast Mend when nobody is hurt")
    bram.hp = int(float(bram.max_hp()) * 0.3)
    var plan: Dictionary = BattleAI.decide(cal, c)
    check(str(plan["action"]) == "skill" and str(plan.get("skill_id", "")) == "mend", "cleric plans Mend for a badly hurt ally")
    check(plan["target"] == bram, "Mend is aimed at the wounded ally")
    var hp_before: int = bram.hp
    var mp_before: int = cal.mp
    var turns_before: int = c.turn_count
    c.run_ai_turn(true)
    check(bram.hp > hp_before, "auto turn heals the wounded ally")
    check(cal.mp < mp_before, "Mend spends MP")
    check(cal.has_acted, "the cleric's action is used up")
    check(c.turn_count == turns_before + 1, "the turn passes on after the auto turn")

    # Switching Auto on in the middle of a turn: a unit that already moved must not move again.
    var c2 := BattleController.new()
    c2.setup(gd.battle_def("battle_01"), gd.as_db(), 4242)
    c2.begin()
    var guard := 0
    while c2.active_unit().team != "player" and guard < 20:
        c2.run_ai_turn()
        guard += 1
    var a: BattleUnit = c2.active_unit()
    var moves: Array[Vector2i] = c2.move_targets(a)
    check(moves.size() > 0 and c2.try_move(a, moves[0]), "player unit moves by hand first")
    var cell_after_move: Vector2i = a.cell
    var turns2: int = c2.turn_count
    c2.run_ai_turn(true)
    check(a.cell == cell_after_move, "auto does not move a unit that already moved this turn")
    check(c2.turn_count == turns2 + 1, "auto finishes the part-played turn")

    # Without force the AI must still refuse to play the player's side.
    var c3 := BattleController.new()
    c3.setup(gd.battle_def("battle_01"), gd.as_db(), 99)
    c3.begin()
    guard = 0
    while c3.active_unit().team != "player" and guard < 20:
        c3.run_ai_turn()
        guard += 1
    var turns3: int = c3.turn_count
    c3.run_ai_turn()
    check(c3.turn_count == turns3, "run_ai_turn() without force leaves the player's unit alone")


## Milestone 2 (step 1): items, equipment, character sheets, EXP, promotion, the persistent party.
func _test_progression() -> void:
    print("[progression]")
    var db: Dictionary = gd.as_db()
    var items: Dictionary = db["items"]

    # --- data integrity
    var stat_keys: Array = ["hp", "mp", "str", "dex", "int", "vit", "spd", "lck", "acc", "eva", "ldr", "mor"]
    var item_slots: Array = ["weapon", "offhand", "armor", "helm", "accessory"]
    var rarities: Array = ["common", "fine", "masterwork", "heirloom"]
    var items_ok := items.size() >= 15
    for k in items.keys():
        var it: Dictionary = items[k]
        if not item_slots.has(str(it.get("slot", ""))) or not rarities.has(str(it.get("rarity", ""))):
            items_ok = false
        if str(it.get("slot", "")) == "weapon" and not gd.weapons.has(str(it.get("weapon_id", ""))):
            items_ok = false
        var bonus: Dictionary = it.get("bonus", {})
        for b in bonus.keys():
            if not stat_keys.has(str(b)):
                items_ok = false
    check(items_ok, "every item has a valid slot, rarity, weapon link and stat-bonus keys")
    var party: PartyState = PartyState.new_game(gd.start, gd.characters)
    check(party.roster.size() == 4 and party.gold == 150, "new game: 4 party members and 150 gold")
    var gear_ok := true
    for k in party.inventory.keys():
        if not items.has(k):
            gear_ok = false
    for cid in party.roster:
        var sh0: CharacterSheet = party.sheet(cid)
        for slot in CharacterSheet.SLOTS:
            if sh0.item_in(slot) != "" and not items.has(sh0.item_in(slot)):
                gear_ok = false
    check(gear_ok, "starting inventory and starting equipment only use known items")
    var same := true
    for k in gd.characters.keys():
        var raw: Dictionary = gd.characters[k]
        var res: Dictionary = db["characters"][k]
        if int(res["armor_def"]) != int(raw["armor_def"]) or int(res["armor_res"]) != int(raw["armor_res"]) or str(res["weapon_id"]) != str(raw["weapon_id"]):
            same = false
        var rs: Dictionary = res["stats"]
        var ws: Dictionary = raw["stats"]
        for sk in ws.keys():
            if int(rs.get(sk, 0)) != int(ws[sk]):
                same = false
    check(same, "equipment-resolved characters keep the exact v0.2 weapon, armor and stat numbers")

    # --- equipping
    var torren: CharacterSheet = party.sheet("torren")
    var atk0: float = float(torren.derived(db)["attack"])
    check(party.equip("torren", "weapon", "fine_arming_sword", db) == "", "Torren equips the Fine Arming Sword")
    check(float(torren.derived(db)["attack"]) > atk0, "a better sword raises attack")
    check(party.item_count("fine_arming_sword") == 0 and party.item_count("arming_sword") == 1, "the old sword returns to the inventory")
    check(party.equip("torren", "weapon", "fine_arming_sword", db) != "", "cannot equip an item that is not in the inventory")
    check(party.equip("bram", "accessory1", "dunmarrow_signet", db) != "", "an heirloom refuses another owner")
    var mor0: int = int(torren.total_stats(items)["mor"])
    check(party.equip("torren", "accessory1", "dunmarrow_signet", db) == "", "Torren may wear the Dunmarrow Signet")
    check(int(torren.total_stats(items)["mor"]) == mor0 + 5, "the signet adds +5 morale")
    check(party.equip("torren", "helm", "pilgrim_medal", db) != "", "an accessory does not fit the helm slot")
    check(party.equip("torren", "accessory2", "hawk_feather", db) == "", "second accessory slot works")
    check(party.equip("torren", "weapon", "greatsword", db) != "", "a two-handed weapon is refused while a buckler is held")
    check(party.unequip("torren", "offhand") == "" and party.item_count("buckler") == 1, "unequip returns the buckler")
    check(party.equip("torren", "weapon", "greatsword", db) == "", "greatsword equips with a free off-hand")
    check(party.equip("torren", "offhand", "kite_shield", db) != "", "the two-hander blocks the off-hand")
    var d: Dictionary = torren.derived(db)
    check(d.has("attack") and d.has("defense") and d.has("crit") and d.has("move"), "derived stats are produced for the sheet screen")
    check(party.equip("torren", "weapon", "fine_arming_sword", db) == "", "swap back to the Fine Arming Sword")
    var bdb: Dictionary = party.battle_db(db)
    var bc := BattleController.new()
    bc.setup(gd.battle_def("battle_01"), bdb, 5)
    var torren_unit: BattleUnit = null
    for o in bc.units:
        var u: BattleUnit = o
        if u.character_id == "torren":
            torren_unit = u
    check(torren_unit != null and torren_unit.weapon_id == "fine_arming_sword", "a battle built from the party uses Torren's current weapon")

    # --- experience and levels
    var rng := RandomNumberGenerator.new()
    rng.seed = 5
    var sela: CharacterSheet = CharacterSheet.from_def("sela", gd.characters["sela"])
    var mira0: CharacterSheet = CharacterSheet.from_def("sela", gd.characters["sela"])
    var archer: Dictionary = gd.classes["archer"]
    check(sela.exp_to_next() == 120, "level 2 needs 120 EXP (80 + 20 x level)")
    var rep: Dictionary = sela.add_exp(119, rng, archer)
    var lvls: Array = rep["levels"]
    check(sela.level == 2 and sela.xp == 119 and lvls.is_empty(), "119 EXP is not enough to level up")
    rep = sela.add_exp(1, rng, archer)
    lvls = rep["levels"]
    check(sela.level == 3 and sela.xp == 0 and lvls.size() == 1, "120 EXP reaches level 3 with nothing left over")
    var gains: Dictionary = (lvls[0] as Dictionary)["gains"]
    check(not gains.is_empty(), "a level-up always grants at least one stat point")
    rep = sela.add_exp(300, rng, archer)
    lvls = rep["levels"]
    check(sela.level == 5 and sela.xp == 0 and lvls.size() == 2, "300 EXP carries across two level-ups (140 + 160)")
    var grew := true
    for k in mira0.base_stats.keys():
        if int(sela.base_stats[k]) < int(mira0.base_stats[k]):
            grew = false
    check(grew and int(sela.base_stats["hp"]) > int(mira0.base_stats["hp"]), "stats never drop on level-up and HP grows")
    var ra := RandomNumberGenerator.new()
    var rb := RandomNumberGenerator.new()
    ra.seed = 9
    rb.seed = 9
    var sa: CharacterSheet = CharacterSheet.from_def("sela", gd.characters["sela"])
    var sb: CharacterSheet = CharacterSheet.from_def("sela", gd.characters["sela"])
    sa.add_exp(900, ra, archer)
    sb.add_exp(900, rb, archer)
    check(sa.level == sb.level and sa.base_stats == sb.base_stats, "level-up rolls are deterministic for a given seed")
    sa.level = CharacterSheet.MAX_LEVEL
    sa.add_exp(5000, ra, archer)
    check(sa.level == CharacterSheet.MAX_LEVEL and sa.xp == 0, "no EXP is stored at the level cap")
    var cal: CharacterSheet = CharacterSheet.from_def("brother_wystan", gd.characters["brother_wystan"])
    cal.add_exp(2500, rng, gd.classes["cleric"])
    check(cal.level > 5 and int(cal.base_stats["mp"]) > 14, "a cleric's MP grows with levels")

    # --- promotion
    var r2: CharacterSheet = CharacterSheet.from_def("torren", gd.characters["torren"])
    check(r2.promotion_options(gd.classes).is_empty(), "no promotion at level 2")
    r2.level = 10
    var opts: Array[String] = r2.promotion_options(gd.classes)
    check(opts.has("knight") and opts.has("duelist") and not opts.has("berserker"), "level 10 swordsman may become a knight or duelist; the locked berserker is not offered")
    check(not r2.promote("berserker", gd.classes), "a locked class cannot be taken")
    var fake: Dictionary = gd.classes.duplicate(true)
    var fake_sw: Dictionary = fake["swordsman"]
    var fake_targets: Array = fake_sw["promotes_to"]
    fake_targets.append("ghost_class")
    check(not r2.promotion_options(fake).has("ghost_class"), "classes missing from data are not offered")
    check(not r2.promote("ghost_class", gd.classes), "promotion to a class that does not exist is refused")
    check(r2.promote("knight", gd.classes) and r2.class_id == "knight", "promotion changes the class")
    r2.level = 19
    check(r2.promotion_options(gd.classes).is_empty(), "a knight needs level 20 for the next tier")
    r2.level = 20
    var knight_opts: Array[String] = r2.promotion_options(gd.classes)
    check(knight_opts.size() == 1 and knight_opts[0] == "heavy_knight", "a level 20 knight may become a heavy knight")

    # --- battle rewards (FF7 rules: fixed enemy rewards, EXP split among survivors, full AP each, gold to the party)
    var rules: Dictionary = {"classes": gd.classes, "items": gd.items, "sigils": gd.sigils}
    var p2: PartyState = PartyState.new_game(gd.start, gd.characters)
    p2.add_member("roadreaver", gd.characters["roadreaver"])        # an undeployed bench member
    var bc2 := BattleController.new()
    bc2.setup(gd.battle_def("battle_01"), p2.battle_db(db), 6)
    for o in bc2.units:
        var u2: BattleUnit = o
        if u2.team == "enemy":
            u2.hp = 0
        if u2.character_id == "bram":
            u2.hp = 0
    var rw: Dictionary = p2.battle_rewards(bc2.units, "victory", rules)
    var rexp: Dictionary = rw["exp"]
    var rap: Dictionary = rw["ap"]
    check(int(rw["total_exp"]) == 250 and int(rw["total_ap"]) == 44 and int(rw["gold"]) == 162 and int(rw["defeated"]) == 4, "four defeated enemies pay 250 EXP, 44 AP and 162 gold in total")
    check(int(rexp["torren"]) == 83 and int(rexp["sela"]) == 83 and int(rexp["brother_wystan"]) == 83, "EXP is split equally between the 3 survivors (250 / 3 = 83)")
    check(not rexp.has("bram") and not rap.has("bram"), "a fallen unit earns neither EXP nor AP")
    check(int(rap["torren"]) == 44 and int(rap["brother_wystan"]) == 44, "every survivor receives the full AP total")
    check(int(rexp["roadreaver"]) == 33 and not rap.has("roadreaver"), "bench member gets 40% of a survivor's EXP share and no AP")
    var lost: Dictionary = p2.battle_rewards(bc2.units, "defeat", rules)
    check((lost["exp"] as Dictionary).is_empty() and int(lost["gold"]) == 0, "a defeat pays nothing")
    for o in bc2.units:
        var u2b: BattleUnit = o
        if u2b.team == "enemy" and u2b.is_commander == false:
            u2b.hp = 1
    var part: Dictionary = p2.battle_rewards(bc2.units, "victory", rules)
    check(int(part["total_exp"]) == 120 and int(part["defeated"]) == 1, "enemies that are still alive pay nothing (only the chief was defeated)")
    var gold0: int = p2.gold
    var applied: Dictionary = p2.apply_battle_result(bc2.units, "victory", rng, rules)
    var reps: Array = applied["reports"]
    check(p2.gold == gold0 + int(applied["gold"]) and reps.size() == 4, "gold is paid and every rewarded member gets a report")
    var wy: CharacterSheet = p2.sheet("brother_wystan")
    var wsig: Dictionary = wy.sigil_at("weapon", 0)
    check(int(wsig.get("ap", 0)) == 20, "Brother Wystan's equipped Sigil of Mending gained the AP")
    var c3 := BattleController.new()
    c3.setup(gd.battle_def("battle_01"), gd.as_db(), 321)
    c3.begin()
    var guard := 0
    while c3.result == "" and guard < 800:
        c3.run_ai_turn(true)
        guard += 1
    var earned := 0
    var expected := 0
    for o in c3.units:
        var u3: BattleUnit = o
        if u3.team == "player":
            earned += u3.kill_exp
        elif not u3.is_alive():
            expected += CombatCalc.kill_exp(u3)
    check(earned == expected, "controller still tracks the EXP value of every kill (statistic)")

    # --- persistence
    var parsed: Dictionary = JSON.parse_string(JSON.stringify(party.to_dict()))
    var p3: PartyState = PartyState.from_dict(parsed)
    var s_old: CharacterSheet = party.sheet("torren")
    var s_new: CharacterSheet = p3.sheet("torren")
    check(p3.roster == party.roster and p3.gold == party.gold and p3.inventory == party.inventory, "party roster, gold and inventory survive a JSON round trip")
    check(p3.sigil_inv.size() == party.sigil_inv.size() and p3.sheet("brother_wystan").sigils == party.sheet("brother_wystan").sigils, "sigil inventory and socketed sigils survive a JSON round trip")
    check(s_new != null and s_new.equipment == s_old.equipment and s_new.base_stats == s_old.base_stats and s_new.level == s_old.level and s_new.xp == s_old.xp, "sheet equipment, stats, level and EXP survive a JSON round trip")


func _test_weapon_skills() -> void:
    print("[weapon skills]")
    var db: Dictionary = gd.as_db()
    check(gd.skills.has("power_strike") and gd.skills.has("aimed_shot") and str(gd.skills["power_strike"]["type"]) == "strike", "Power Strike and Aimed Shot exist as strike skills")
    var ps: PartyState = PartyState.new_game(gd.start, gd.characters)
    var bc := BattleController.new()
    bc.setup(gd.battle_def("battle_01"), ps.battle_db(db), 21)
    bc.begin()
    var hero: BattleUnit = null
    var foe: BattleUnit = null
    var archer: BattleUnit = null
    for o in bc.units:
        var u: BattleUnit = o
        if u.character_id == "torren":
            hero = u
        elif u.character_id == "sela":
            archer = u
        elif u.team == "enemy" and foe == null:
            foe = u
    check(hero != null and foe != null and archer != null, "hero, archer and a foe exist")
    if hero == null or foe == null or archer == null:
        return
    check(hero.skills.has("power_strike") and archer.skills.has("aimed_shot"), "Torren (Swordsman) knows Power Strike and Sela (Archer) knows Aimed Shot from their classes")
    check((gd.characters["torren"]["skills"] as Array).is_empty(), "the skill comes from the class, not from the character file")
    var tsheet: CharacterSheet = ps.sheet("torren")
    check(tsheet.all_skills(db["items"], db["sigils"]).is_empty() and tsheet.all_skills(db["items"], db["sigils"], db["classes"]).has("power_strike"), "class skills need the class table; all_skills without it grants none")
    var ok_cs := true
    for k in gd.classes.keys():
        for sid in ((gd.classes[k] as Dictionary).get("class_skills", {}) as Dictionary).keys():
            if not gd.skills.has(str(sid)):
                ok_cs = false
    check(ok_cs, "every class skill exists in skills.json")
    foe.cell = hero.cell + Vector2i(1, 0)
    bc.active_id = hero.id
    hero.has_acted = false
    hero.has_moved = false
    var sk: Dictionary = gd.skills["power_strike"]
    var plain: Dictionary = CombatCalc.preview(hero, foe, bc.weapon_of(hero), bc.map, bc.units)
    var prev: Dictionary = CombatCalc.skill_preview(hero, foe, sk, "power_strike", bc.weapon_of(hero))
    check(float(prev["normal"]) > 0.0 and int(prev["dmg_max"]) >= int(plain["dmg_min"]), "Power Strike previews more damage than the plain minimum hit")
    check(bc.skill_targets(hero, "power_strike").has(foe) and not bc.skill_targets(hero, "power_strike").has(archer), "Power Strike hits an adjacent enemy only")
    var hp0: int = foe.hp
    var mp0: int = hero.mp
    check(bc.try_skill(hero, "power_strike", foe), "Power Strike succeeds")
    var dealt: int = hp0 - foe.hp
    check(dealt >= int(prev["dmg_min"]) and dealt <= int(prev["dmg_max"]) and hero.mp == mp0 - 3 and hero.has_acted, "damage is inside the preview range, 3 MP spent, turn used")
    check(ItemInfo.skill_line("power_strike", gd.skills).contains("weapon attack"), "the skill line describes a weapon skill")


func _why(bad: PackedStringArray) -> String:
    return "" if bad.is_empty() else ": " + "; ".join(bad)


## Every tile reachable on foot from `start` (4 neighbours, one byte per tile: 1 = reachable).
func _flood(w: WorldMap, start: Vector2i) -> PackedByteArray:
    var seen := PackedByteArray()
    seen.resize(w.width * w.height)
    var queue := PackedInt32Array()
    var first: int = start.y * w.width + start.x
    seen[first] = 1
    queue.append(first)
    var head := 0
    while head < queue.size():
        var idx: int = queue[head]
        head += 1
        var cy: int = floori(float(idx) / float(w.width))
        var cx: int = idx - cy * w.width
        for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
            var n: Vector2i = Vector2i(cx, cy) + d
            if not w.walkable(n):
                continue
            var ni: int = n.y * w.width + n.x
            if seen[ni] == 0:
                seen[ni] = 1
                queue.append(ni)
    return seen


func _test_world() -> void:
    print("[overworld: procedural fallback for small test maps]")
    var small: Dictionary = {"width": 40, "height": 30, "seed": 7, "start": "a", "encounter_min": 900, "encounter_max": 1800,
        "places": [{"id": "a", "name": "A", "kind": "village", "cell": [6, 6]}, {"id": "b", "name": "B", "kind": "village", "cell": [32, 22]}],
        "roads": [["a", "b"]]}
    var s1: WorldMap = WorldMap.generate(small)
    var s2: WorldMap = WorldMap.generate(small)
    check(s1.width == 40 and s1.height == 30 and s1.tiles.size() == 1200, "a small procedural map has the configured size")
    check(s1.tiles == s2.tiles, "the same seed always gives the same land")
    var other: Dictionary = small.duplicate(true)
    other["seed"] = 8
    check(WorldMap.generate(other).tiles != s1.tiles, "a different seed gives different land")
    check(s1.walkable(s1.place_cell("a")) and s1.walkable(s1.place_cell("b")), "places stand on walkable ground")
    check(s1.connected(s1.place_cell("a"), s1.place_cell("b")), "a road in the config really connects its two places")
    check(s1.terrain_at(Vector2i(0, 0)) == WorldMap.MOUNTAIN and not s1.walkable(Vector2i(-5, -5)), "the map edge and anything outside it is blocked")
    check(WorldMap.SPEED[WorldMap.ROAD] > 1.0 and WorldMap.SPEED[WorldMap.FOREST] < 1.0 and WorldMap.SPEED[WorldMap.WATER] == 0.0 and WorldMap.SPEED[WorldMap.MOUNTAIN] == 0.0, "roads are fast, forests slow, deep water and mountains block")
    check(WorldMap.DANGER[WorldMap.FOREST] > WorldMap.DANGER[WorldMap.GRASS] and WorldMap.DANGER[WorldMap.ROAD] < WorldMap.DANGER[WorldMap.GRASS], "forests are more dangerous than grass and roads are safer")
    check(WorldMap.encounter_threshold(small, 0.0) == 900.0 and WorldMap.encounter_threshold(small, 1.0) == 1800.0, "the ambush threshold runs from encounter_min to encounter_max")
    check(WorldMap.NAMES.size() == WorldMap.SPEED.size() and WorldMap.NAMES.size() == WorldMap.DANGER.size() and WorldMap.NAMES.size() == WorldMap.BATTLE_CHAR.size(), "every terrain has a name, speed, danger and battle glyph")
    var skirmish: Dictionary = EncounterBuilder.build_skirmish(gd.encounters, gd.battles, rng_for_tests())
    check(not skirmish.is_empty() and str(skirmish.get("id", "")) == "skirmish", "the old skirmish builder still works")


func _test_world_data() -> void:
    print("[overworld: Eldrimar, the baked world]")
    var cfg: Dictionary = gd.world
    var w: WorldMap = WorldMap.generate(cfg, gd.world_map)
    wm = w
    check(w.width == int(cfg["width"]) and w.height == int(cfg["height"]) and w.tiles.size() == w.width * w.height and w.regions.size() == w.tiles.size(), "the baked map has the configured size and a region layer")
    check(w.width * w.height >= 50 * 64 * 48, "the world covers at least 50 times the area of the old 64 x 48 map (%d tiles)" % (w.width * w.height))
    var frac: float = w.walkable_fraction()
    check(frac > 0.6 and frac < 0.98, "most of the world is walkable but not all of it (%d%%)" % int(frac * 100.0))
    check(w.region_defs.size() >= 8 and w.places.size() >= 30, "at least eight regions and thirty places")
    var tiers := {}
    var tiers_ok := true
    for r in w.region_defs:
        var rd: Dictionary = r
        var t: int = int(rd.get("tier", 0))
        tiers[t] = true
        if t < 1 or t > 5:
            tiers_ok = false
    check(tiers_ok and tiers.size() == 5, "region danger tiers run from 1 to 5 and all five are used")
    check(w.tier_at(w.start_cell) == 1 and w.walkable(w.start_cell), "the story starts on walkable ground in a tier 1 region")
    var seen: PackedByteArray = _flood(w, w.start_cell)
    var lost := PackedStringArray()
    var wrong_region := PackedStringArray()
    for p in w.places:
        var d: Dictionary = p
        var id: String = str(d["id"])
        var c: Vector2i = w.place_cell(id)
        if not w.walkable(c) or seen[c.y * w.width + c.x] == 0:
            lost.append(id)
        if w.region_id_at(c) != str(d.get("region", "")):
            wrong_region.append(id)
    check(lost.is_empty(), "every place is on walkable ground and can be reached on foot from Kaer Sethorn" + _why(lost))
    check(wrong_region.is_empty(), "every place stands inside the region its data names" + _why(wrong_region))
    var reached := 0
    for i in range(seen.size()):
        reached += int(seen[i])
    check(float(reached) / float(maxi(1, w.tiles.size())) * 100.0 > 0.8 * frac * 100.0, "most walkable land is one connected landmass (%d of %d walkable tiles)" % [reached, int(frac * float(w.tiles.size()))])
    check(not w.walkable(Vector2i(-1, -1)) and not w.walkable(Vector2i(w.width, w.height)), "outside the map is blocked")
    var patch: Dictionary = w.battle_patch(w.start_cell, EncounterBuilder.PATCH_W, EncounterBuilder.PATCH_H)
    var rows: Array = patch["terrain"]
    check(rows.size() == EncounterBuilder.PATCH_H and str(rows[0]).length() == EncounterBuilder.PATCH_W, "a battle patch is %d x %d" % [EncounterBuilder.PATCH_W, EncounterBuilder.PATCH_H])
    var legend: Dictionary = patch["legend"]
    var terr_ok := true
    for k in legend.keys():
        if not gd.terrain.has(str(legend[k])):
            terr_ok = false
    check(terr_ok, "every terrain a world battle can use exists in terrain.json")


## Story-gate overlay: closed passes isolate the free opening regions; opening every pass reconnects every place.
func _test_world_gate_map() -> void:
    print("[overworld: story-gated boundary passability]")
    var closed := WorldMap.generate(gd.world, gd.world_map, gd.world_gates, {}, null)
    var closed_seen := _flood(closed, closed.start_cell)
    var allowed_regions := {"sethmarch": true, "orrowen": true}
    var closed_places_ok := true
    var unexpected_regions := PackedStringArray()
    for place_value in closed.places:
        var place: Dictionary = place_value
        var cell := closed.place_cell(str(place.get("id", "")))
        var reachable := closed_seen[cell.y * closed.width + cell.x] == 1
        var should_reach := allowed_regions.has(str(place.get("region", "")))
        if reachable != should_reach:
            closed_places_ok = false
            unexpected_regions.append(str(place.get("id", "")))
    check(closed_places_ok, "closed gates keep the starting Sethmarch/Orrowen regions reachable and seal the other regions" + _why(unexpected_regions))
    var all_flags: Dictionary = {}
    for gate_value in gd.world_gates.get("gates", []):
        var gate: Dictionary = gate_value
        for req_value in gate.get("requires", []):
            var req := str(req_value)
            if not req.begins_with("!") and not req.begins_with("item:") and not req.begins_with("gold:"):
                all_flags[req] = true
    var party_stub := {"gold": 999999, "inventory": {}}
    var opened := WorldMap.generate(gd.world, gd.world_map, gd.world_gates, all_flags, party_stub)
    var opened_seen := _flood(opened, opened.start_cell)
    var missing := PackedStringArray()
    for place_value in opened.places:
        var place: Dictionary = place_value
        var cell := opened.place_cell(str(place.get("id", "")))
        if opened_seen[cell.y * opened.width + cell.x] == 0:
            missing.append(str(place.get("id", "")))
    check(missing.is_empty(), "opening every story gate restores foot access to every place" + _why(missing))
    var first_gate: Dictionary = gd.world_gates.get("gates", [])[0]
    var first_cell_values: Array = first_gate.get("cells", [])[0]
    var first_cell := Vector2i(int(first_cell_values[0]), int(first_cell_values[1]))
    check(closed.terrain_at(first_cell) == WorldMap.MOUNTAIN and not closed.passable(first_cell), "a closed gate cell is physically impassable")
    check(opened.passable(first_cell) and opened.gate_open_at(first_cell), "an earned gate restores its underlying road tile")
    closed.set_story_state(all_flags, party_stub)
    check(closed.walkable(first_cell) and closed.connected_with(closed.start_cell, closed.place_cell("ironford")), "refreshing story state opens gates without rebuilding the world")


func _test_world_content() -> void:
    print("[overworld: content cross-references]")
    var w: WorldMap = wm
    var items: Dictionary = gd.party_db()["items"]
    var bad := PackedStringArray()
    var regs: Dictionary = gd.encounters.get("regions", {})
    for r in w.region_defs:
        var rid: String = str((r as Dictionary)["id"])
        var groups: Array = (regs.get(rid, {}) as Dictionary).get("groups", [])
        if groups.is_empty():
            bad.append("no groups in " + rid)
        for g in groups:
            var gdict: Dictionary = g
            if int(gdict.get("weight", 0)) <= 0:
                bad.append("zero weight in " + rid)
            for u in (gdict.get("units", []) as Array):
                if not gd.characters.has(str(u)):
                    bad.append("unknown unit %s in %s" % [str(u), rid])
        if str((regs.get(rid, {}) as Dictionary).get("ambush", "")) == "":
            bad.append("no ambush text in " + rid)
        if ((r as Dictionary).get("rumours", []) as Array).is_empty():
            bad.append("no rumours in " + rid)
    check(bad.is_empty(), "every region has ambush text, rumours and weighted groups of real characters" + _why(bad))
    bad = PackedStringArray()
    var camps: Dictionary = gd.encounters.get("camps", {})
    var n_camps := 0
    var n_ruins := 0
    for p in w.places:
        var d: Dictionary = p
        var id: String = str(d["id"])
        var kind: String = str(d.get("kind", ""))
        if kind == "camp":
            n_camps += 1
            var camp: Dictionary = camps.get(str(d.get("group", "")), {})
            if camp.is_empty():
                bad.append("camp %s has no group" % id)
                continue
            var units: Array = camp.get("units", [])
            for u in units:
                if not gd.characters.has(str(u)):
                    bad.append("unknown unit %s in camp %s" % [str(u), id])
            if not units.has(camp.get("commander", "")):
                bad.append("camp %s has no commander among its units" % id)
        elif kind == "ruin":
            n_ruins += 1
            if int(d.get("reward_gold", 0)) <= 0:
                bad.append("ruin %s pays no gold" % id)
            var item_id: String = str(d.get("reward_item", ""))
            if item_id != "" and not items.has(item_id):
                bad.append("ruin %s rewards unknown item %s" % [id, item_id])
    check(bad.is_empty() and n_camps >= 6 and n_ruins >= 8, "%d camps and %d ruins point at real fights and rewards" % [n_camps, n_ruins] + _why(bad))
    var unit_bad := PackedStringArray()
    for cid in gd.characters.keys():
        var cdef: Dictionary = gd.characters[cid]
        if not gd.classes.has(str(cdef.get("class_id", ""))):
            unit_bad.append(str(cid))
    check(unit_bad.is_empty(), "every character has a real class" + _why(unit_bad))


## Rough strength of one unit (HP x armour x attack): enough to check that danger tiers really rise, not a combat prediction.
func _unit_power(cid: String) -> float:
    var cdef: Dictionary = gd.characters.get(cid, {})
    var st: Dictionary = cdef.get("stats", {})
    var wpn: Dictionary = gd.weapons.get(str(cdef.get("weapon_id", "")), {})
    return float(st.get("hp", 1)) * (1.0 + float(cdef.get("armor_def", 0)) / 20.0) * (float(st.get("str", 0)) + float(wpn.get("power", 0)))


func _test_town_buildings() -> void:
    print("[town buildings]")
    var expected := 0
    var complete := true
    var valid := true
    for place_value in gd.world.get("places", []):
        var place: Dictionary = place_value
        var kind := str(place.get("kind", ""))
        if kind not in ["keep", "city", "town", "village"]:
            continue
        expected += 1
        var id := str(place.get("id", ""))
        var def: Dictionary = gd.town_buildings.get(id, {})
        if def.is_empty():
            complete = false
            continue
        var buildings: Array = def.get("buildings", [])
        if buildings.size() < 3 or buildings.size() > 7 or str(def.get("palette", "")) not in ["thatch", "stone", "sand", "slate"]:
            valid = false
        for building_value in buildings:
            if typeof(building_value) != TYPE_DICTIONARY:
                valid = false
                continue
            var building: Dictionary = building_value
            if str(building.get("sprite", "")) not in ["tiny", "small1", "small3", "small4", "large1", "tall1", "tall2", "tall3"]:
                valid = false
            if not building.has("x") or not building.has("y"):
                valid = false
    check(expected == 23, "all 23 settlements enumerated")
    check(complete, "every settlement has an authored building layout")
    check(valid, "settlement layouts use valid palettes and building definitions")


func _test_world_story() -> void:
    print("[overworld: story gates and journal]")
    var story := WorldStory.new(gd.world_gates)
    var ps: PartyState = PartyState.new_game(gd.start, gd.characters)
    var flags: Dictionary = {}
    check(story.gates_by_id.size() == 7 and story.quests_by_id.size() == 2, "story progression definitions load from world_gates.json")
    check(not story.gate_open("g_roadwolf", flags, ps), "an uncleared roadwolf barricade stays closed")
    flags["cleared_roadwolf_camp"] = true
    check(story.gate_open("g_roadwolf", flags, ps), "clearing the roadwolf camp opens its gate")
    check(not story.gate_open("missing_gate", flags, ps), "an unknown gate fails closed")
    check(story.met(["cleared_roadwolf_camp", "!toll_paid"], flags, ps), "flag and negated-flag requirements are both supported")
    check(not story.met(["cleared_roadwolf_camp", "toll_paid"], flags, ps), "all requirements must pass")
    ps.add_item("mace", 1)
    check(story.met(["item:mace", "gold:1"], flags, ps), "item and gold requirements read the live party")
    check(not story.met(["item:missing_item"], flags, ps), "missing inventory items fail requirements")
    ps.gold = 149
    check(not story.met(["gold:150"], flags, ps), "gold requirement rejects an insufficient balance")
    ps.gold = 150
    check(story.met(["gold:150"], flags, ps), "gold requirement accepts the exact required balance")
    var oak_before: Dictionary = story.quest_state("oak_oath", flags)
    check(not bool(oak_before["completed"]) and int(oak_before["current_step"]) == 0, "an untouched quest points to its first step")
    check(story.journal_lines(flags).is_empty(), "untouched quests do not clutter the journal")
    flags["looted_hollow_oak"] = true
    var oak_mid: Dictionary = story.quest_state("oak_oath", flags)
    check(int(oak_mid["current_step"]) == 1 and str(oak_mid["next_step"]).contains("Orrowen Hall"), "quest state advances to the next unmet flag")
    check(story.journal_lines(flags).size() == 1, "a started quest appears in the journal")
    flags["lucan_oath"] = true
    var oak_done: Dictionary = story.quest_state("oak_oath", flags)
    check(bool(oak_done["completed"]) and int(oak_done["current_step"]) == -1, "all quest flags complete the quest")
    check(story.journal_lines(flags)[0].ends_with("Complete"), "completed quests are labelled in the journal")
    check(str(story.place_action("pay_toll").get("place", "")) == "brinegate", "place-action definitions can be retrieved by id")
    var toll_action := story.place_action("pay_toll")
    ps.gold = 150
    check(story.met(toll_action.get("requires", []), flags, ps), "Brinegate toll action is enabled at 150 gold")
    ps.gold = 149
    check(not story.met(toll_action.get("requires", []), flags, ps), "Brinegate toll action is disabled below 150 gold")
    check(str(story.place_action("swear_lucan_oath").get("set", [""])[0]) == "lucan_oath", "Orrowen oath action sets its gate flag")
    check(str(story.place_action("claim_pilgrim_seal").get("set", [""])[0]) == "pilgrim_seal", "Kingsway seal action sets its gate flag")
    check(story.quest_state("unknown_quest", flags).is_empty(), "unknown quests return an empty state")


func _test_recruitment() -> void:
    print("[overworld: named recruitment]")
    check(gd.recruits.has("hask_gravelteeth"), "named recruit definitions load from recruits.json")
    var recruit: Dictionary = gd.recruits.get("hask_gravelteeth", {})
    check(str(recruit.get("character_id", "")) == "hask_gravelteeth" and gd.characters.has("hask_gravelteeth"), "Hask's recruitment definition resolves to a real character")
    var story := WorldStory.new({})
    var party: PartyState = PartyState.new_game(gd.start, gd.characters)
    var flags: Dictionary = {}
    check(not story.met(recruit.get("requires", []), flags, party), "Hask remains unavailable before the Sallow Road story victory")
    flags["defeated_hask"] = true
    check(story.met(recruit.get("requires", []), flags, party), "the Sallow Road victory unlocks Hask's personal recruitment lead")
    party.add_member("hask_gravelteeth", gd.characters["hask_gravelteeth"])
    party.add_member("hask_gravelteeth", gd.characters["hask_gravelteeth"])
    check(party.roster.count("hask_gravelteeth") == 1 and party.sheet("hask_gravelteeth") != null, "a named companion joins once and becomes a full party sheet")
    var saved: PartyState = PartyState.from_dict(party.to_dict())
    check(saved.roster.has("hask_gravelteeth") and saved.sheet("hask_gravelteeth") != null, "recruited companions persist through the existing party save")
    var edda: Dictionary = gd.recruits.get("edda_stonehand", {})
    var joss: Dictionary = gd.recruits.get("joss_harrow", {})
    check(not edda.is_empty() and gd.characters.has("edda_stonehand"), "Edda's town-contact recruitment resolves to a character")
    check(not joss.is_empty() and gd.characters.has("joss_harrow"), "Joss's hidden-location recruitment resolves to a character")
    check(str(edda.get("method", "")) == "town_contact" and str(joss.get("method", "")) == "hidden_location", "new recruits use distinct authored recruitment methods")
    for recruit_id in ["hask_gravelteeth", "edda_stonehand", "joss_harrow"]:
        var entry: Dictionary = gd.recruits.get(recruit_id, {})
        check(str(entry.get("origin", "")) != "" and str(entry.get("personal_quest", "")) != "", "%s has authored origin and personal quest metadata" % recruit_id)
        check(str(entry.get("condition_text", "")) != "", "%s has a readable recruitment condition" % recruit_id)
    check(ResourceLoader.exists("res://assets/portraits/edda_stonehand.png") and ResourceLoader.exists("res://assets/portraits/joss_harrow.png"), "new named recruits each have a distinct portrait asset")
    check(not story.met(edda.get("requires", []), flags, party), "Edda remains a rumour until Ironford is visited")
    flags["seen_ironford"] = true
    check(story.met(edda.get("requires", []), flags, party), "visiting Ironford reveals Edda's recruitment lead")
    check(not story.met(joss.get("requires", []), flags, party), "Joss remains hidden until the Gilded Hind is searched")
    flags["looted_gilded_hind"] = true
    check(story.met(joss.get("requires", []), flags, party), "searching the Gilded Hind reveals Joss's recruitment lead")
    party.add_member("edda_stonehand", gd.characters["edda_stonehand"])
    party.add_member("joss_harrow", gd.characters["joss_harrow"])
    var expanded: PartyState = PartyState.from_dict(party.to_dict())
    check(expanded.roster.has("edda_stonehand") and expanded.roster.has("joss_harrow"), "new recruits persist through the existing party save")


func _test_region_difficulty() -> void:
    print("[overworld: danger tiers really get harder]")
    var regs: Dictionary = gd.encounters.get("regions", {})
    var sum_by_tier := {}
    var n_by_tier := {}
    for r in wm.region_defs:
        var rd: Dictionary = r
        var tier: int = int(rd.get("tier", 1))
        var groups: Array = (regs.get(str(rd["id"]), {}) as Dictionary).get("groups", [])
        var total_w := 0.0
        var total_p := 0.0
        for g in groups:
            var gdict: Dictionary = g
            var power := 0.0
            for u in (gdict.get("units", []) as Array):
                power += _unit_power(str(u))
            total_w += float(gdict.get("weight", 1))
            total_p += float(gdict.get("weight", 1)) * power
        sum_by_tier[tier] = float(sum_by_tier.get(tier, 0.0)) + total_p / maxf(1.0, total_w)
        n_by_tier[tier] = int(n_by_tier.get(tier, 0)) + 1
    var rising := true
    var line := ""
    for t in range(1, 6):
        if not sum_by_tier.has(t):
            rising = false
            continue
        var avg_t: float = float(sum_by_tier[t]) / float(n_by_tier[t])
        line += "T%d %d  " % [t, int(avg_t)]
        if t > 1 and sum_by_tier.has(t - 1) and avg_t <= float(sum_by_tier[t - 1]) / float(n_by_tier[t - 1]):
            rising = false
    check(rising, "average ambush strength rises with every danger tier (" + line.strip_edges() + ")")


func _test_world_battles() -> void:
    print("[overworld: ambushes and camps on map-cut battlefields]")
    var w: WorldMap = wm
    var r := RandomNumberGenerator.new()
    r.seed = 11
    var defs: Array = []
    var region_cell := {}
    for p in w.places:
        var d: Dictionary = p
        var rid: String = str(d.get("region", ""))
        if not region_cell.has(rid):
            region_cell[rid] = w.place_cell(str(d["id"]))
        if str(d.get("kind", "")) == "camp":
            var camp_patch: Dictionary = w.battle_patch(w.place_cell(str(d["id"])), EncounterBuilder.PATCH_W, EncounterBuilder.PATCH_H)
            defs.append(["camp " + str(d["id"]), EncounterBuilder.build_camp(gd.encounters, gd.battles, str(d.get("group", "")), camp_patch)])
    for rid in region_cell.keys():
        var cell: Vector2i = region_cell[rid]
        var patch: Dictionary = w.battle_patch(cell, EncounterBuilder.PATCH_W, EncounterBuilder.PATCH_H)
        for i in range(3):
            defs.append(["ambush %s #%d" % [str(rid), i], EncounterBuilder.build_region_ambush(gd.encounters, gd.battles, str(rid), r, patch)])
    var bad := PackedStringArray()
    var finished := 0
    for entry in defs:
        var label: String = str(entry[0])
        var def: Dictionary = entry[1]
        if def.is_empty():
            bad.append(label + " is empty")
            continue
        var rows: Array = def["terrain"]
        var cells: Array[Vector2i] = []
        var first_player := Vector2i(-1, -1)
        var has_enemy := false
        var has_player := false
        for u in (def["units"] as Array):
            var ud: Dictionary = u
            var ca: Array = ud.get("cell", [0, 0])
            var c := Vector2i(int(ca[0]), int(ca[1]))
            if c.y < 0 or c.y >= rows.size() or c.x < 0 or c.x >= str(rows[c.y]).length():
                bad.append("%s: %s starts outside the map" % [label, str(ud.get("character_id", ""))])
                continue
            var ch: String = str(rows[c.y])[c.x]
            if ch == "~" or ch == "#":
                bad.append("%s: %s starts on impassable ground" % [label, str(ud.get("character_id", ""))])
            if str(ud.get("team", "")) == "player":
                has_player = true
                if first_player.x < 0:
                    first_player = c
            else:
                has_enemy = true
                cells.append(c)
        if not has_player or not has_enemy:
            bad.append(label + " lacks one side")
            continue
        for c in cells:
            if not EncounterBuilder._reachable(rows, first_player, c):
                bad.append("%s: enemy at %s cannot be reached" % [label, str(c)])
        var ctl := BattleController.new()
        ctl.setup(def, gd.as_db(), 500 + finished)
        ctl.begin()
        var guard := 0
        while ctl.result == "" and guard < 800:
            ctl.run_ai_turn(true)
            guard += 1
        if ctl.result == "":
            bad.append(label + " never ends")
        else:
            finished += 1
    check(bad.is_empty() and finished == defs.size() and defs.size() >= 20, "%d world battles (ambushes of every region and every camp) are well formed and play to a result" % defs.size() + _why(bad))


func _test_town_shops() -> void:
    print("[town shops]")
    var w: WorldMap = wm
    var db: Dictionary = gd.party_db()
    var towns: Array = ["keep", "city", "town", "village"]
    var bad := PackedStringArray()
    check(gd.shops.size() >= 30, "there are at least thirty shops (%d)" % gd.shops.size())
    var mult_by_tier := {}
    for sid in gd.shops.keys():
        var sd: Dictionary = gd.shop_def(str(sid))
        var place: Dictionary = w.place_by_id(str(sd.get("place", "")))
        if place.is_empty() or not towns.has(str(place.get("kind", ""))):
            bad.append("shop %s is not inside a town" % str(sid))
            continue
        var listed: int = (sd.get("items", []) as Array).size() + (sd.get("sigils", []) as Array).size()
        if listed == 0 or ShopSystem.stock(sd, db).size() != listed:
            bad.append("shop %s lists unknown, unpriced or no goods" % str(sid))
        var ratio: float = ShopSystem.sell_ratio(sd)
        if ratio <= 0.0 or ratio > 1.0:
            bad.append("shop %s has a bad sell ratio" % str(sid))
        var tier: int = w.tier_at(w.place_cell(str(place["id"])))
        if not mult_by_tier.has(tier):
            mult_by_tier[tier] = []
        (mult_by_tier[tier] as Array).append(ShopSystem.price_mult(sd))
    check(bad.is_empty(), "every shop stands inside a town and sells only real, priced goods" + _why(bad))
    var wild_ok := true
    var town_names := 0
    for p in w.places:
        var d: Dictionary = p
        var here: Array = gd.shops_at(str(d["id"]))
        if towns.has(str(d.get("kind", ""))):
            town_names += 1
        elif not here.is_empty():
            wild_ok = false
    check(wild_ok and town_names >= 20, "camps and ruins have no shop at all (%d towns)" % town_names)
    check(gd.shops_at("sethorn").has("sethorn_stores") and gd.shops_at("no_such_place").is_empty() and gd.shops_at("").is_empty(), "shops_at() finds the shops of a place and nothing for an unknown place")
    var two := 0
    for p in w.places:
        if gd.shops_at(str((p as Dictionary)["id"])).size() >= 2:
            two += 1
    check(two >= 1, "some towns have more than one shop (%d)" % two)
    var avg := {}
    for t in mult_by_tier.keys():
        var sum := 0.0
        for m in (mult_by_tier[t] as Array):
            sum += float(m)
        avg[t] = sum / float((mult_by_tier[t] as Array).size())
    check(avg.has(1) and avg.has(5) and float(avg[5]) > float(avg[1]), "shops in the deadliest region charge more than the home region on average")
    var frontier: Dictionary = {"items": ["arming_sword"], "sigils": [], "price_mult": 1.5, "sell_ratio": 0.5}
    var base: int = ShopSystem.item_price("arming_sword", db)
    var expect: int = int(round(float(base) * 1.5))
    check(ShopSystem.price_mult({}) == 1.0 and ShopSystem.price_mult(frontier) == 1.5 and ShopSystem.price_mult({"price_mult": 0.1}) == 0.5, "price_mult defaults to 1 and never drops below 0.5")
    check(ShopSystem.buy_price(base, frontier) == expect and ShopSystem.buy_price(0, {}) == 1, "buy_price scales the list price and is at least 1 gold")
    var ps: PartyState = PartyState.new_game(gd.start, gd.characters)
    ps.gold = expect - 1
    check(ShopSystem.buy_item(ps, "arming_sword", db, frontier) == "Not enough gold." and ps.gold == expect - 1, "a frontier shop refuses a buyer who has only the list price minus one")
    ps.gold = expect
    var n0: int = ps.item_count("arming_sword")
    check(ShopSystem.buy_item(ps, "arming_sword", db, frontier) == "" and ps.gold == 0 and ps.item_count("arming_sword") == n0 + 1, "the frontier price is what is paid")
    var g0: int = ps.gold
    ShopSystem.sell_item(ps, "arming_sword", db, frontier)
    check(ps.gold - g0 == ShopSystem.sell_price(base, frontier), "selling pays a share of the LIST price, not of the frontier price")


func _test_view_only_screen() -> void:
    print("[company screen: view-only outside towns]")
    var db: Dictionary = gd.party_db()
    var ps: PartyState = PartyState.new_game(gd.start, gd.characters)
    var shop: Dictionary = gd.shop_def("sethorn_stores")
    var screen := PartyScreen.new()
    root.add_child(screen)
    screen.setup(ps, db, shop, false)
    check(not screen.has_shop() and screen.tab_ids().size() == 2 and not screen.tab_ids().has(PartyScreen.TAB_SHOP), "outside a town the Shop tab is not offered, even if a shop is passed in")
    screen.open(PartyScreen.TAB_SHOP)
    check(screen.visible and screen.tab == PartyScreen.TAB_GEAR, "asking for the Shop tab where there is none opens Equipment")
    screen._on_tab(PartyScreen.TAB_SHOP)
    check(screen.tab == PartyScreen.TAB_GEAR, "tapping a hidden Shop tab does nothing")
    ps.add_item("fine_arming_sword")
    ps.gold = 500
    var weapon0: String = ps.sheet("torren").item_in("weapon")
    var bag0: int = ps.sigil_inv.size()
    var class0: String = ps.sheet("torren").class_id
    screen._on_select("torren")
    screen._on_slot("weapon")
    screen._on_equip("weapon", "fine_arming_sword")
    screen._on_unequip("weapon")
    screen._on_tab(PartyScreen.TAB_SIGILS)
    screen._on_socket_sigil("weapon", 0, 0)
    screen._on_unsocket("weapon", 0)
    screen._on_buy("item", "mace")
    screen._on_sell_item("fine_arming_sword")
    screen._on_promote("duelist")
    screen._on_shop_pick("buy:item:mace")
    check(screen.shop_pick == "", "view-only: a shop card cannot be opened")
    check(ps.sheet("torren").item_in("weapon") == weapon0 and ps.sigil_inv.size() == bag0 and ps.sheet("torren").class_id == class0 and ps.gold == 500 and ps.item_count("fine_arming_sword") == 1, "view-only: no gear, sigil, class, gold or bag change is possible")
    check(not screen.changed, "view-only: the screen never reports a change")
    var b0: int = screen.builds
    var calls := 0
    for id in ps.roster:
        screen._on_select(id)
        calls += 1
        for t in screen.tab_ids():
            screen._on_tab(t)
            calls += 1
    check(screen.builds - b0 == calls, "the view-only screen builds for every member and tab (%d builds)" % calls)
    screen.close()
    screen.setup(ps, db, {}, true)
    check(not screen.has_shop() and screen.tab_ids().size() == 2, "a town without a shop offers Equipment and Sigils only")
    screen.open()
    screen._on_select("torren")
    screen._on_equip("weapon", "fine_arming_sword")
    check(ps.sheet("torren").item_in("weapon") == "fine_arming_sword" and screen.changed, "in a town gear can be changed")
    screen.close()
    screen.setup(ps, db, shop, true)
    screen.open(PartyScreen.TAB_SHOP)
    check(screen.has_shop() and screen.tab_ids().size() == 3 and screen.tab == PartyScreen.TAB_SHOP, "a town with a shop offers the Shop tab and can open on it")
    screen._on_buy("item", "mace")
    check(screen.message.begins_with("Bought") and ps.gold < 500, "buying works in a town shop")
    screen.close()
    screen.queue_free()


func _test_world_save_format() -> void:
    print("[overworld: save format]")
    var ps: PartyState = PartyState.new_game(gd.start, gd.characters)
    ps.gold = 777
    ps.add_item("mace")
    var payload: Dictionary = {"kind": "world", "party": ps.to_dict(), "world": {"pos": [123.5, 456.0], "flags": {"seen_sethorn": true, "cleared_roadwolf_camp": true, "looted_watch": true}, "room": {"site": "hollow", "room": "reliquary", "cell": [24, 31]}}}
    ss.delete_slot("world_test")
    check(ss.save_slot("world_test", payload, "world test"), "a world payload saves")
    var res: Dictionary = ss.load_slot("world_test")
    check(bool(res["ok"]) and str(res["payload"]["kind"]) == "world", "a world payload loads")
    var back: PartyState = PartyState.from_dict(res["payload"]["party"])
    var wd: Dictionary = res["payload"]["world"]
    var pos: Array = wd["pos"]
    var flags: Dictionary = wd["flags"]
    check(back.gold == 777 and back.item_count("mace") == ps.item_count("mace") and back.roster.size() == ps.roster.size(), "gold, bag and roster survive a world save")
    check(absf(float(pos[0]) - 123.5) < 0.001 and bool(flags.get("cleared_roadwolf_camp", false)) and bool(flags.get("looted_watch", false)) and bool(flags.get("seen_sethorn", false)), "position and world flags survive a world save")
    var room: Dictionary = wd.get("room", {})
    var room_cell: Array = room.get("cell", [])
    check(str(room.get("site", "")) == "hollow" and str(room.get("room", "")) == "reliquary" and room_cell == [24, 31], "current room id and hero cell survive a world save")
    var legacy_world: Dictionary = {"pos": [1, 2], "flags": {}}
    check(not legacy_world.has("room"), "older world saves without a room field remain valid")
    ss.delete_slot("world_test")


func _test_sigils() -> void:
    print("[sigils]")
    var db: Dictionary = gd.as_db()
    var items: Dictionary = db["items"]
    var sdefs: Dictionary = db["sigils"]
    # --- data integrity
    var ok := sdefs.size() >= 8
    for k in sdefs.keys():
        var sd: Dictionary = sdefs[k]
        if (sd.get("levels", []) as Array).size() != (sd.get("ap", []) as Array).size() + 1:
            ok = false
        for lv in (sd.get("levels", []) as Array):
            for sid in ((lv as Dictionary).get("skills", []) as Array):
                if not gd.skills.has(str(sid)):
                    ok = false
    check(ok, "every sigil has one level per AP threshold + 1 and only grants known skills")
    var socket_ok := true
    for k in items.keys():
        var it: Dictionary = items[k]
        if it.has("sockets"):
            for pair in (it.get("links", []) as Array):
                if int((pair as Array)[0]) >= int(it["sockets"]) or int((pair as Array)[1]) >= int(it["sockets"]):
                    socket_ok = false
    check(socket_ok, "every socket link points at a real socket")
    # --- levels and AP thresholds
    var mend: Dictionary = sdefs["mend"]
    check(CharacterSheet.sigil_level({"id": "mend", "ap": 59}, mend) == 1 and CharacterSheet.sigil_level({"id": "mend", "ap": 60}, mend) == 2, "Mending reaches level 2 at exactly 60 AP")
    check(CharacterSheet.sigil_level({"id": "mend", "ap": 480}, mend) == 4 and CharacterSheet.sigil_is_mastered({"id": "mend", "ap": 480}, mend), "480 AP masters the Sigil of Mending")
    check(CharacterSheet.sigil_ap_to_next({"id": "mend", "ap": 50}, mend) == 10, "10 AP remain to the next level")
    check(CharacterSheet.sigil_skills_at(mend, 1).size() == 1 and CharacterSheet.sigil_skills_at(mend, 1).has("mend") and CharacterSheet.sigil_skills_at(mend, 3).has("mend_ii") and CharacterSheet.sigil_skills_at(mend, 3).has("mend"), "skills accumulate with sigil level")
    # --- skills come from sigils
    check((db["characters"]["brother_wystan"]["skills"] as Array).has("mend"), "Brother Wystan's Mend now comes from his socketed sigil")
    var ps: PartyState = PartyState.new_game(gd.start, gd.characters)
    var torren: CharacterSheet = ps.sheet("torren")
    check(ps.sigil_inv.size() == 5, "the party starts with 5 sigils in the bag")
    check(torren.socket_count("weapon", items) == 2 and torren.socket_count("armor", items) == 2, "Torren's sword and cuirass each have 2 linked sockets")
    var emb_i := _sigil_index(ps, "ember")
    check(ps.equip_sigil("torren", "weapon", 0, emb_i, db) == "", "equip the Sigil of Embers into socket 0")
    check((torren.to_battle_def(db)["skills"] as Array).has("ember_bolt"), "the sigil grants Ember Bolt")
    check(ps.equip_sigil("torren", "weapon", 5, 0, db) != "" and ps.equip_sigil("torren", "helm", 0, 0, db) != "", "bad socket or group is refused")
    var amp_i := _sigil_index(ps, "amp")
    check(ps.equip_sigil("torren", "weapon", 1, amp_i, db) == "", "equip the Sigil of Resonance into the linked socket")
    check(int((torren.to_battle_def(db)["skill_mods"] as Dictionary).get("ember_bolt", 0)) == 10, "a linked support adds +10% power to the linked magic skill")
    var tut_i := _sigil_index(ps, "tutor")
    check(ps.equip_sigil("torren", "weapon", 1, tut_i, db) == "" and _sigil_index(ps, "amp") >= 0, "swapping a sigil returns the old one to the bag")
    check((torren.to_battle_def(db)["skill_mods"] as Dictionary).is_empty(), "with Resonance removed the skill bonus is gone")
    # --- AP growth: weapon multiplier and linked Tutor
    var rep: Array = torren.award_ap(40, items, sdefs)
    var ember_ap: int = int(torren.sigil_at("weapon", 0)["ap"])
    var tutor_ap: int = int(torren.sigil_at("weapon", 1)["ap"])
    check(ember_ap == 50 and tutor_ap == 40 and rep.size() == 2, "Tutor linked to Embers: 40 AP becomes 50 (+25%) for the Embers, 40 for the Tutor itself")
    # --- stat sigils
    var fresh: CharacterSheet = CharacterSheet.from_def("torren", gd.characters["torren"])
    fresh.fit_sockets(items)
    var base_hp: int = int(fresh.total_stats(items, sdefs)["hp"])
    (fresh.sigils["weapon"] as Array)[0] = {"id": "vigor", "ap": 0}
    (fresh.sigils["weapon"] as Array)[1] = {"id": "might", "ap": 0}
    var st: Dictionary = fresh.total_stats(items, sdefs)
    check(int(st["hp"]) == base_hp + int(round(float(base_hp) * 0.05)) and int(st["str"]) == int(fresh.total_stats(items)["str"]) + 1 and int(st["int"]) == int(fresh.total_stats(items)["int"]) - 1, "Vigor adds 5% HP and Might adds +1 STR at the cost of -1 INT at level 1")
    (fresh.sigils["weapon"] as Array)[0] = {"id": "veteran", "ap": 0}
    check(fresh.reward_pct("exp_pct", items, sdefs) == 10, "Veteran's Mark gives +10% EXP at level 1")
    # --- greatsword: more sockets, double AP growth; a smaller weapon returns the extra sigils
    var ps2: PartyState = PartyState.new_game(gd.start, gd.characters)
    var t2: CharacterSheet = ps2.sheet("torren")
    ps2.equip_sigil("torren", "weapon", 0, _sigil_index(ps2, "ember"), db)
    ps2.equip_sigil("torren", "weapon", 1, _sigil_index(ps2, "tutor"), db)
    check(ps2.unequip("torren", "offhand", db) == "" and ps2.equip("torren", "weapon", "greatsword", db) == "", "swap to the two-handed Hearthbreaker")
    check(t2.socket_count("weapon", items) == 4 and (t2.sigils["weapon"] as Array).size() == 4, "socket array grows to 4")
    check(not t2.sigil_at("weapon", 0).is_empty() and not t2.sigil_at("weapon", 1).is_empty(), "sigils stay socketed when the new weapon has the sockets")
    t2.award_ap(10, items, sdefs)
    check(int(t2.sigil_at("weapon", 0)["ap"]) == 25, "weapon AP x2 with linked Tutor +25%: 10 AP becomes 25")
    ps2.add_item("short_bow")
    var bag_before: int = ps2.sigil_inv.size()
    check(ps2.equip("torren", "weapon", "short_bow", db) == "", "swap to the one-socket Reed Bow")
    check(ps2.sigil_inv.size() == bag_before + 1 and (t2.sigils["weapon"] as Array).size() == 1, "the sigil that lost its socket returns to the bag")
    # --- mastery spawns a fresh copy, once
    var ps3: PartyState = PartyState.new_game(gd.start, gd.characters)
    var wy: CharacterSheet = ps3.sheet("brother_wystan")
    (wy.sigils["weapon"] as Array)[0]["ap"] = 470
    var mrep: Array = wy.award_ap(20, items, sdefs)
    var m0: Dictionary = mrep[0]
    check(bool(m0["mastered"]) and bool(m0["spawn"]) and int(wy.sigil_at("weapon", 0)["ap"]) == 480, "mastery caps the AP and asks for a new copy")
    check(wy.award_ap(50, items, sdefs).is_empty(), "a mastered sigil stops gaining AP")
    (wy.sigils["weapon"] as Array)[0] = {"id": "mend", "ap": 470}
    var bag2: int = ps3.sigil_inv.size()
    var bcm := BattleController.new()
    bcm.setup(gd.battle_def("battle_01"), ps3.battle_db(db), 8)
    for o in bcm.units:
        var um: BattleUnit = o
        if um.team == "enemy":
            um.hp = 0
    var out: Dictionary = ps3.apply_battle_result(bcm.units, "victory", rng_for_tests(), {"classes": gd.classes, "items": items, "sigils": sdefs})
    check((out["spawned"] as Array).size() == 1 and ps3.sigil_inv.size() == bag2 + 1, "winning a battle that masters a sigil forges a fresh level-1 copy")
    check(bool(wy.sigil_at("weapon", 0).get("spawned", false)), "the mastered sigil is flagged so it spawns only once")
    # --- offensive magic in battle
    var ps4: PartyState = PartyState.new_game(gd.start, gd.characters)
    ps4.equip_sigil("torren", "weapon", 0, _sigil_index(ps4, "ember"), db)
    var bcd := BattleController.new()
    bcd.setup(gd.battle_def("battle_01"), ps4.battle_db(db), 12)
    bcd.begin()
    var caster: BattleUnit = null
    var victim: BattleUnit = null
    for o in bcd.units:
        var ud: BattleUnit = o
        if ud.character_id == "torren":
            caster = ud
        elif ud.character_id == "roadreaver" and victim == null:
            victim = ud
    check(caster != null and victim != null, "caster and victim exist")
    if caster == null or victim == null:
        return
    victim.cell = caster.cell + Vector2i(0, -3)
    bcd.active_id = caster.id
    caster.has_acted = false
    caster.has_moved = false
    check(bcd.skill_targets(caster, "ember_bolt").has(victim), "Ember Bolt can target an enemy 3 tiles away")
    var prev: Dictionary = CombatCalc.skill_preview(caster, victim, gd.skills["ember_bolt"], "ember_bolt")
    var hp_v: int = victim.hp
    var mp_c: int = caster.mp
    check(bcd.try_skill(caster, "ember_bolt", victim), "casting Ember Bolt succeeds")
    var dealt: int = hp_v - victim.hp
    check(dealt >= int(prev["dmg_min"]) and dealt <= int(prev["dmg_max"]) and caster.mp == mp_c - 4 and caster.has_acted, "damage is inside the preview range, MP is spent and the turn is used")
    var ally: BattleUnit = null
    for o in bcd.units:
        var ua: BattleUnit = o
        if ua.team == "player" and ua != caster:
            ally = ua
    check(not bcd.skill_targets(caster, "ember_bolt").has(ally), "an offensive skill never targets allies")
    # --- the AI uses offensive magic
    caster.has_acted = false
    victim.hp = victim.max_hp()
    caster.mp = 8
    var ai_plan: Dictionary = BattleAI.decide(caster, bcd)
    check(str(ai_plan["action"]) == "skill" or str(ai_plan["action"]) == "attack", "AI plans an action with a damage skill available")
    # --- skirmish encounters
    var seen: Dictionary = {}
    var rr := RandomNumberGenerator.new()
    var sk_ok := true
    for seed_v in range(1, 25):
        rr.seed = seed_v
        var sdef: Dictionary = EncounterBuilder.build_skirmish(gd.encounters, gd.battles, rr)
        var enemies := 0
        var players := 0
        for u in (sdef.get("units", []) as Array):
            var ud2: Dictionary = u
            if str(ud2["team"]) == "enemy":
                enemies += 1
                if not gd.characters.has(str(ud2["character_id"])):
                    sk_ok = false
            else:
                players += 1
        if str(sdef.get("id", "")) != "skirmish" or players != 4 or enemies < 3:
            sk_ok = false
        seen[enemies] = true
    check(sk_ok, "every generated skirmish has the 4 heroes, 3+ known enemies and the id 'skirmish'")
    check(seen.size() >= 2, "different seeds produce different enemy groups")
    var sdef2: Dictionary = EncounterBuilder.build_skirmish(gd.encounters, gd.battles, rr)
    var bcs := BattleController.new()
    bcs.setup(sdef2, gd.as_db(), 99)
    bcs.begin()
    var g2 := 0
    while bcs.result == "" and g2 < 800:
        bcs.run_ai_turn(true)
        g2 += 1
    check(bcs.result != "", "an AI-vs-AI skirmish finishes")


func _on_card_tapped() -> void:
    card_taps += 1


func _on_screen_closed() -> void:
    screen_closed += 1


func _on_chosen(lead_id: String, look: Dictionary) -> void:
    chosen_count += 1
    chosen_lead = lead_id
    chosen_look = look


func _test_looks_and_select() -> void:
    print("[character select and hero designs]")
    var looks: Dictionary = gd.looks
    var portrait_missing: Array[String] = []
    for cid in ["torren", "bram", "sela", "brother_wystan", "hask_gravelteeth"]:
        var portrait_path := "res://assets/portraits/%s.png" % cid
        if not FileAccess.file_exists(portrait_path):
            portrait_missing.append(portrait_path)
        else:
            var portrait_image: Image = Image.load_from_file(portrait_path)
            if portrait_image == null or portrait_image.get_width() != 512 or portrait_image.get_height() != 512:
                portrait_missing.append(portrait_path + " (wrong dimensions)")
    check(portrait_missing.is_empty(), "five original 512x512 character portraits are present")
    var def_look: Dictionary = HeroLooks.default_appearance(looks)
    var order: Array[String] = HeroLooks.select_order(looks, gd.start)
    check(order.size() == 4 and order[0] == "torren", "looks.json covers the four protagonists of the starting party, Torren first")
    var kinds: Dictionary = {}
    var accents: Dictionary = {}
    var all_kinds: Array[String] = []
    for cid in order:
        var k: String = HeroLooks.sheet_kind(cid, looks, def_look)
        kinds[k] = true
        accents[HeroLooks.accent(cid, looks).to_html()] = true
        if not bool((HeroLooks.heroes(looks)[cid] as Dictionary).get("customizable", false)):
            all_kinds.append(k)
    check(kinds.size() == order.size() and not kinds.has(HeroLooks.FALLBACK_KIND), "every protagonist has a different sprite kind and none is the plain Soldier")
    check(accents.size() == order.size(), "every protagonist has a different accent colour")
    var opts: Dictionary = looks.get("appearance_options", {})
    for hair in (opts.get("hair", []) as Array):
        for scarf in (opts.get("scarf", []) as Array):
            all_kinds.append("torren_%s_%s" % [str((hair as Dictionary)["id"]), str((scarf as Dictionary)["id"])])
    var frames: Dictionary = {"idle": 6, "walk": 8, "attack": 6, "hurt": 4, "death": 4}
    var missing: Array[String] = []
    var bad_size: Array[String] = []
    for k in all_kinds:
        for anim in frames.keys():
            var path: String = "res://assets/sprites/characters/heroes/%s_%s.png" % [k, str(anim)]
            if not FileAccess.file_exists(path):
                missing.append(path)
                continue
            var img: Image = Image.load_from_file(path)
            if img == null or img.get_width() != int(frames[anim]) * 100 or img.get_height() != 100:
                bad_size.append(path)
    for m in missing:
        print("        missing " + m)
    for b in bad_size:
        print("        wrong size " + b)
    check(missing.is_empty() and bad_size.is_empty(), "every hero sheet exists with the Soldier's frame layout (%d kinds x 5 animations)" % all_kinds.size())
    check(HeroLooks.sheet_kind("torren", looks, {"hair": "chestnut", "scarf": "gilt"}) == "torren_chestnut_gilt" and HeroLooks.sheet_kind("bram", looks, {"hair": "chestnut"}) == "bram", "Torren's kind follows his colours, the others are fixed")
    check(HeroLooks.sheet_kind("roadreaver", looks, def_look) == HeroLooks.FALLBACK_KIND and HeroLooks.draw_scale("roadreaver", looks) == 1.0, "unknown characters fall back to the Soldier at normal size")
    var bad: Dictionary = HeroLooks.normalize_appearance({"hair": "neon", "scarf": 7}, looks)
    check(str(bad["hair"]) == str(def_look["hair"]) and str(bad["scarf"]) == str(def_look["scarf"]), "unknown or broken appearance values fall back to the defaults")
    var stepped: Dictionary = HeroLooks.step_option(def_look, "hair", -1, looks)
    var wrapped: Dictionary = HeroLooks.step_option(stepped, "hair", 1, looks)
    check(str(stepped["hair"]) != str(def_look["hair"]) and str(wrapped["hair"]) == str(def_look["hair"]), "stepping an option wraps around in both directions")
    check(HeroLooks.valid_lead("bram", looks, ["torren", "bram"]) == "bram" and HeroLooks.valid_lead("roadreaver", looks, ["torren", "bram"]) == "torren" and HeroLooks.valid_lead("torren", looks, ["bram", "sela"]) == "bram", "a lead must be a protagonist in the roster, otherwise the default or the first member")
    var reordered: Array[String] = HeroLooks.roster_with_lead_first("sela", ["torren", "bram", "sela", "brother_wystan"])
    check(reordered.size() == 4 and reordered[0] == "sela" and reordered[1] == "torren" and reordered[2] == "bram" and reordered[3] == "brother_wystan", "the lead moves to the front of the roster, the rest keep their order")
    var party: PartyState = PartyState.new_game(gd.start, gd.characters)
    party.roster = HeroLooks.roster_with_lead_first("brother_wystan", party.roster)
    var back: PartyState = PartyState.from_dict(party.to_dict())
    check(back.roster.size() == 4 and back.roster[0] == "brother_wystan", "a lead-first roster survives the party save")
    check(HeroArt.frame_index("attack", 99.0) == 5 and HeroArt.frame_index("hurt", 99.0) == 3 and HeroArt.frame_index("idle", 0.0) == 0 and HeroArt.frame_index("walk", 100.0) < 8, "sprite frames: one-shots stop on their last frame, loops wrap")
    check(absf(HeroArt.duration("attack") - 6.0 / 14.0) < 0.001 and HeroArt.usable_kind("no_such_hero") == "soldier", "sprite timing and the Soldier fallback")
    # the screen itself
    chosen_count = 0
    var cs := CharacterSelect.new()
    cs.setup(gd.looks, gd.start, gd.characters, gd.classes)
    root.add_child(cs)
    cs.chosen.connect(_on_chosen)
    check(cs.builds == 1 and cs.selected == "torren" and cs.order.size() == 4 and cs.stage != null and cs.side != null, "character select builds with Torren selected")
    cs.select("nobody")
    check(cs.selected == "torren", "an unknown hero cannot be selected")
    cs.step_option("hair", 1)
    check(str(cs.appearance["hair"]) != str(def_look["hair"]), "Torren's hair colour can be changed")
    var chosen_hair: String = str(cs.appearance["hair"])
    cs.select("bram")
    cs.step_option("hair", 1)
    check(cs.selected == "bram" and str(cs.appearance["hair"]) == chosen_hair, "the other heroes' designs are fixed")
    cs.select("sela")
    cs.begin()
    cs.begin()
    check(chosen_count == 1 and chosen_lead == "sela" and str(chosen_look.get("hair", "")) == chosen_hair, "Begin fires once with the chosen lead and Torren's colours")
    cs.queue_free()


func _test_shop_and_screen() -> void:
    print("[shop, text helpers, gear preview, party screen]")
    var db: Dictionary = gd.party_db()
    var shop: Dictionary = gd.shop
    var items: Dictionary = db["items"]
    var sdefs: Dictionary = db["sigils"]
    # --- data
    var shop_ok: bool = not shop.is_empty() and ShopSystem.sell_ratio(shop) > 0.0 and ShopSystem.sell_ratio(shop) <= 1.0
    for id in (shop.get("items", []) as Array):
        if not items.has(str(id)) or int((items[str(id)] as Dictionary).get("price", 0)) <= 0:
            shop_ok = false
    for id in (shop.get("sigils", []) as Array):
        if not sdefs.has(str(id)) or int((sdefs[str(id)] as Dictionary).get("price", 0)) <= 0:
            shop_ok = false
    check(shop_ok, "shop stock only lists real items and sigils that have a price")
    check(ShopSystem.stock(shop, db).size() == (shop["items"] as Array).size() + (shop["sigils"] as Array).size(), "the stock list has one entry per shop line")
    check(gd.skills.has("frost_shard") and gd.skills.has("frost_lance") and str(gd.skills["frost_shard"]["type"]) == "damage", "Frost skills exist as damage spells")
    check(CharacterSheet.sigil_skills_at(sdefs["frost"], 1).has("frost_shard") and CharacterSheet.sigil_skills_at(sdefs["frost"], 3).has("frost_lance"), "the Sigil of Frost teaches Frost Shard at level 1 and Frost Lance at level 3")
    # --- text helpers
    check(ItemInfo.signed(3) == "+3" and ItemInfo.signed(-2) == "-2" and ItemInfo.signed(0) == "+0", "signed() formats numbers")
    check(ItemInfo.bonus_text({"ldr": 2, "mor": 5}) == "+2 LDR, +5 MOR", "bonus text is sorted and labelled")
    check(ItemInfo.mods_text({"hp_pct": 5, "mp_pct": -10}) == "+5% HP, -10% MP", "percentage mods read as +5% HP, -10% MP")
    var text_ok := true
    for k in items.keys():
        if ItemInfo.item_line(str(k), items, db["weapons"]).length() < 4:
            text_ok = false
    for k in sdefs.keys():
        var sd: Dictionary = sdefs[k]
        for lv in range(1, CharacterSheet.sigil_max_level(sd) + 1):
            if ItemInfo.sigil_effect(sd, lv, db["skills"]) == "" or ItemInfo.sigil_short({"id": str(k), "ap": 0}, sd) == "":
                text_ok = false
    check(text_ok, "every item and every sigil level has a description")
    check(ItemInfo.skill_line("mend", db["skills"]).begins_with("Mend") and ItemInfo.skill_line("ember_bolt", db["skills"]).contains("magic damage"), "skill lines describe heals and damage spells")
    var mend_def: Dictionary = sdefs["mend"]
    check(ItemInfo.sigil_ap_text({"id": "mend", "ap": 35}, mend_def) == "35/60 AP" and ItemInfo.sigil_ap_text({"id": "mend", "ap": 480}, mend_def) == "MAX", "AP text shows progress to the next level and MAX when mastered")
    check(ItemInfo.sigil_progress({"id": "mend", "ap": 50}, mend_def).contains("10 AP to next"), "sigil progress names the AP still needed")
    # --- shop rules
    var ps: PartyState = PartyState.new_game(gd.start, gd.characters)
    var arming_price: int = ShopSystem.item_price("arming_sword", db)
    check(arming_price > 0, "the Wayfarer Blade has a price")
    ps.gold = arming_price - 1
    check(ShopSystem.buy_item(ps, "arming_sword", db, shop) == "Not enough gold." and ps.gold == arming_price - 1, "a purchase without enough gold is refused and costs nothing")
    ps.gold = arming_price + 10
    var count0: int = ps.item_count("arming_sword")
    check(ShopSystem.buy_item(ps, "arming_sword", db, shop) == "" and ps.gold == 10 and ps.item_count("arming_sword") == count0 + 1, "buying pays the price and adds the item")
    check(ShopSystem.buy_item(ps, "dunmarrow_signet", db, shop) == "Not for sale.", "an item the stall does not stock cannot be bought")
    var gold1: int = ps.gold
    check(ShopSystem.sell_item(ps, "arming_sword", db, shop) == "" and ps.item_count("arming_sword") == count0, "selling takes the item out of the bag")
    check(ps.gold == gold1 + ShopSystem.sell_price(arming_price, shop), "selling pays the sell ratio of the price")
    check(ShopSystem.sell_item(ps, "arming_sword", db, shop) != "", "gear that is only equipped (not in the bag) cannot be sold")
    check(ShopSystem.sell_item(ps, "dunmarrow_signet", db, shop) == "That cannot be sold.", "heirlooms cannot be sold")
    ps.gold = ShopSystem.sigil_price("frost", db)
    var bag0: int = ps.sigil_inv.size()
    check(ShopSystem.buy_sigil(ps, "frost", db, shop) == "" and ps.gold == 0 and ps.sigil_inv.size() == bag0 + 1, "buying a sigil puts a fresh copy into the bag")
    check(CharacterSheet.sigil_level(ps.sigil_inv[bag0], sdefs["frost"]) == 1, "a bought sigil is level 1")
    check(ShopSystem.sell_sigil(ps, bag0, db, shop) == "" and ps.sigil_inv.size() == bag0 and ps.gold == ShopSystem.sell_price(ShopSystem.sigil_price("frost", db), shop), "selling a sigil removes it and pays the sell ratio")
    check(ShopSystem.sell_sigil(ps, 99, db, shop) != "" and ShopSystem.sell_sigil(ps, -1, db, shop) != "", "selling a sigil that is not in the bag is refused")
    # --- gear preview
    var torren: CharacterSheet = ps.sheet("torren")
    var worn: String = torren.item_in("weapon")
    var before: Dictionary = torren.derived(db)
    var preview: CharacterSheet = torren.with_item("weapon", "fine_arming_sword", items)
    var after: Dictionary = preview.derived(db)
    check(torren.item_in("weapon") == worn and preview.item_in("weapon") == "fine_arming_sword", "with_item() changes only the copy")
    check(roundi(float(after["attack"])) > roundi(float(before["attack"])), "the Moonforged Wayfarer hits harder than the Wayfarer Blade")
    check(ItemInfo.delta_text(before, after).contains("ATK +") and ItemInfo.delta_text(before, before) == "no change", "delta text lists changes and says 'no change' otherwise")
    # --- party screen (headless smoke test: it must build, react to every action and keep the rules intact)
    var screen := PartyScreen.new()
    root.add_child(screen)
    screen.closed.connect(_on_screen_closed)
    screen.setup(ps, db, shop)
    screen.open()
    check(screen.visible and screen.builds == 1 and screen.get_child_count() == 2, "the party screen builds its layout on open()")
    var b0: int = screen.builds
    var n_calls := 0
    for id in ps.roster:
        screen._on_select(id)
        n_calls += 1
        for t in range(PartyScreen.TAB_NAMES.size()):
            screen._on_tab(t)
            n_calls += 1
    check(screen.builds - b0 == n_calls and screen.get_child_count() == 2, "every roster member x every tab builds completely (%d builds)" % n_calls)
    ps.add_item("fine_arming_sword")
    screen._on_select("torren")
    screen._on_tab(PartyScreen.TAB_SIGILS)
    screen._on_socket("weapon", 0)
    check(screen.focus_group == "weapon" and screen.focus_index == 0, "tapping a socket opens its choices")
    var ember_i: int = _sigil_index(ps, "ember")
    var bag_before: int = ps.sigil_inv.size()
    screen._on_socket_sigil("weapon", 0, ember_i)
    check(str(ps.sheet("torren").sigil_at("weapon", 0).get("id", "")) == "ember" and ps.sigil_inv.size() == bag_before - 1 and screen.changed, "choosing a sigil sockets it and takes it out of the bag")
    check(screen.message.begins_with("Socketed"), "the screen confirms the socketing")
    screen._on_unsocket("weapon", 0)
    check(ps.sheet("torren").sigil_at("weapon", 0).is_empty() and ps.sigil_inv.size() == bag_before, "Remove sends the sigil back to the bag")
    screen._on_tab(PartyScreen.TAB_GEAR)
    screen._on_slot("weapon")
    check(screen.focus_slot == "weapon", "tapping a gear slot opens its choices")
    screen._on_equip("weapon", "fine_arming_sword")
    check(ps.sheet("torren").item_in("weapon") == "fine_arming_sword" and screen.message.begins_with("Equipped"), "choosing an item equips it")
    screen._on_equip("weapon", "greatsword")
    check(ps.sheet("torren").item_in("weapon") == "fine_arming_sword" or ps.sheet("torren").item_in("weapon") == "greatsword", "a refused or accepted swap never leaves the slot empty")
    screen._on_unequip("weapon")
    check(ps.sheet("torren").item_in("weapon") == "", "Unequip empties the slot")
    screen._on_tab(PartyScreen.TAB_SHOP)
    ps.gold = 1000
    var gold_before: int = ps.gold
    screen._on_buy("item", "mace")
    check(screen.message.begins_with("Bought") and ps.gold < gold_before, "buying in the shop tab spends gold")
    screen._on_shop_mode(true)
    screen._on_sell_item("mace")
    check(screen.message.begins_with("Sold") and screen.shop_selling, "selling in the shop tab pays gold")
    screen._on_sell_item("dunmarrow_signet")
    check(screen.message == "That cannot be sold.", "the shop tab explains why an heirloom cannot be sold")
    # --- compare before buying, confirm before buying or selling (feature party_ui)
    screen._on_shop_mode(false)
    ps.gold = 1000
    var picks: Array[String] = ["buy:item:mace", "buy:item:kettle_helm", "buy:item:buckler", "buy:sigil:ember"]
    var builds_before: int = screen.builds
    for pk in picks:
        screen._on_shop_pick(pk)
    check(screen.builds - builds_before == picks.size() and screen.get_child_count() == 2 and ps.gold == 1000, "opening shop cards (gear compare, sigil) builds completely and buys nothing")
    screen._on_shop_pick("buy:sigil:ember")
    check(screen.shop_pick == "", "tapping an open shop card again closes it")
    screen._on_shop_pick("buy:item:mace")
    screen._on_confirm_buy("item", "mace")
    check(screen.shop_pick == "" and ps.gold < 1000 and screen.message.begins_with("Bought"), "Confirm buys the opened item and closes the card")
    screen._on_shop_mode(true)
    screen._on_shop_pick("sell:item:mace")
    var gold_mid: int = ps.gold
    check(screen.shop_pick == "sell:item:mace" and ps.gold == gold_mid and ps.item_count("mace") > 0, "opening a sell card sells nothing")
    screen._on_confirm_sell_item("mace")
    check(screen.shop_pick == "" and ps.gold > gold_mid and screen.message.begins_with("Sold"), "Confirm sells the opened item")
    check(not ItemInfo.delta_parts(before, after).is_empty() and ItemInfo.delta_parts(before, before).is_empty(), "delta_parts lists changed stats and is empty when nothing changes")
    # --- TapCard: a tap fires, a drag does not (so lists of cards can be scrolled by touch)
    var tcard := TapCard.new()
    tcard.tapped.connect(_on_card_tapped)
    var press := InputEventMouseButton.new()
    press.button_index = MOUSE_BUTTON_LEFT
    press.pressed = true
    var release := InputEventMouseButton.new()
    release.button_index = MOUSE_BUTTON_LEFT
    release.pressed = false
    var drag := InputEventMouseMotion.new()
    drag.relative = Vector2(0.0, -40.0)
    tcard._gui_input(press)
    tcard._gui_input(release)
    check(card_taps == 1, "a short press and release taps a TapCard")
    tcard._gui_input(press)
    tcard._gui_input(drag)
    tcard._gui_input(release)
    check(card_taps == 1, "pressing and dragging a TapCard scrolls instead of tapping")
    tcard.set_disabled(true)
    tcard._gui_input(press)
    tcard._gui_input(release)
    check(card_taps == 1, "a disabled TapCard never taps")
    tcard.free()
    screen.close()
    check(not screen.visible and screen_closed == 1, "Close hides the screen and emits closed")
    screen.queue_free()


func _test_rooms() -> void:
    print("[pre-rendered rooms]")
    check(gd.rooms.size() >= 9 and gd.sites.has("keep") and gd.sites.has("hollow") and gd.sites.has("watchtower"), "rooms.json (9 room models) and sites.json (keep, barrow dungeon and Old Watchtower) load")
    var errs: Array[String] = RoomMap.validate(gd.sites, gd.rooms, gd.battles, gd.items)
    for e in errs:
        print("        " + e)
    check(errs.is_empty(), "every room is well formed: 50x50 grids, spawns, reachable exits that do not bounce back, reachable spots, real chest items and boss battle, every room reachable")
    var maps: Dictionary = RoomMap.load_site(gd.sites["hollow"], gd.rooms)
    var gate: RoomMap = maps["gate"]
    var p := Vector2(20.5, 30.5)
    check(gate.unproject(gate.project(p, 3.0), 3.0).distance_to(p) < 0.01, "screen projection and its inverse agree")
    check(gate.walkable(gate.spawn) and not gate.walkable(Vector2i(-1, 5)) and not gate.walkable(Vector2i(50, 5)), "the spawn is walkable and outside the room is blocked")
    var west: Dictionary = {}
    for e in gate.exits:
        if str((e as Dictionary).get("id", "")) == "west":
            west = e
    check(not west.is_empty() and gate.exit_at(gate.exit_rect(west).position + Vector2i(1, 1)).get("id", "") == "west" and gate.exit_at(gate.spawn).is_empty(), "exit_at finds the pad and the spawn stands outside every pad")
    var from: Vector2 = Vector2(float(gate.spawn.x) + 0.5, float(gate.spawn.y) + 0.5)
    var route: Array[Vector2] = gate.route(from, gate.nearest_walkable(gate.exit_rect(west).position + Vector2i(2, 6)))
    check(not route.is_empty(), "a tapped spot beside the west door has a route over the walk grid")
    check(gate.nearest_walkable(Vector2i(-3, -3), 3).x < 0 and gate.nearest_walkable(Vector2i(25, 25)).x >= 0, "nearest_walkable finds floor near the room and gives up far outside it")
    var stairs: RoomMap = maps["stairs"]
    var climb: bool = false
    for yy in range(stairs.height):
        for xx in range(stairs.width):
            if stairs.floor_dz(Vector2i(xx, yy)) > 0:
                climb = true
    check(climb or stairs.walkable(stairs.spawn), "floor heights are readable (base-36 digits)")
    var places_ok := true
    for pl in (gd.world.get("places", []) as Array):
        var sid: String = str((pl as Dictionary).get("site", ""))
        if sid != "" and not gd.sites.has(sid):
            places_ok = false
    check(places_ok, "every overworld place with a site points at a real site")
    var watchtower: Dictionary = gd.sites.get("watchtower", {})
    check(watchtower.get("start", "") == "lower" and (watchtower.get("rooms", {}) as Dictionary).size() == 2, "Old Watchtower has a two-room route from the lower watch to the upper signal brazier")
    var watch_place: Dictionary = {}
    for pl in (gd.world.get("places", []) as Array):
        if str((pl as Dictionary).get("id", "")) == "watch":
            watch_place = pl
            break
    check(str(watch_place.get("site", "")) == "watchtower", "Old Watchtower ruin opens the new explorable site")
    var table: Dictionary = EncounterBuilder.build_skirmish(gd.encounters, gd.battles, rng_for_tests(), "skirmish_hollow")
    var husks := 0
    for u in (table.get("units", []) as Array):
        if str((u as Dictionary).get("team", "")) == "enemy" and str((u as Dictionary).get("character_id", "")).begins_with("hollow_"):
            husks += 1
    check(husks >= 3, "the barrow encounter table builds a fight of barrow enemies (%d)" % husks)
    var boss: Dictionary = gd.battle_def("battle_02")
    var bm: BattleMap = BattleMap.from_battle_def(boss, gd.terrain)
    var spawns_ok := true
    for u in (boss.get("units", []) as Array):
        var cell: Array = (u as Dictionary).get("cell", [0, 0])
        if bm.move_cost(Vector2i(int(cell[0]), int(cell[1]))) < 0:
            spawns_ok = false
    check(spawns_ok and bm.width == 12 and bm.height == 10, "the Warden's Seal battle (battle_02) is 12x10 and nobody starts inside rock")
    check(gd.characters.has("hollow_warden") and int((gd.characters["hollow_warden"] as Dictionary).get("reward", {}).get("exp", 0)) > int((gd.characters["hask_gravelteeth"] as Dictionary).get("reward", {}).get("exp", 0)), "the Hollow Warden pays more than the Roadwolf chief")


func rng_for_tests() -> RandomNumberGenerator:
    var r := RandomNumberGenerator.new()
    r.seed = 4242
    return r


func _sigil_index(party: PartyState, sigil_id: String) -> int:
    for i in range(party.sigil_inv.size()):
        if str((party.sigil_inv[i] as Dictionary).get("id", "")) == sigil_id:
            return i
    return -1


func _test_settings_store() -> void:
    print("[settings]")
    var store: Node = load("res://scripts/core/settings_store.gd").new()
    store.config_path = "user://test_settings_store.cfg"
    store.load_settings()
    check(is_equal_approx(float(store.volume("master")), 1.0), "settings default master volume")
    check(store.set_volume("music", 0.35), "music volume persists")
    check(is_equal_approx(float(store.volume("music")), 0.35), "music volume is readable")
    check(store.set_setting("battle", "auto_battle", true), "battle setting persists through shared store")
    store.set_volume("sfx", 1.8)
    check(is_equal_approx(float(store.volume("sfx")), 1.0), "volume values are clamped")
    var reloaded: Node = load("res://scripts/core/settings_store.gd").new()
    reloaded.config_path = store.config_path
    reloaded.load_settings()
    check(is_equal_approx(float(reloaded.volume("music")), 0.35), "settings survive reload")
    check(bool(reloaded.get_setting("battle", "auto_battle", false)), "battle setting survives reload")
    DirAccess.remove_absolute(ProjectSettings.globalize_path(store.config_path))
    store.free()
    reloaded.free()


func _test_save_system() -> void:
    print("[save system]")
    var payload := {"hello": "world", "n": 5, "arr": [1, 2, 3]}
    ss.delete_slot("test")
    check(ss.save_slot("test", payload, "unit test"), "save succeeds")
    var res: Dictionary = ss.load_slot("test")
    check(bool(res["ok"]) and int(res["payload"]["n"]) == 5 and str(res["payload"]["hello"]) == "world", "load returns the saved payload")
    check(bool(ss.save_slot("test", {"hello": "again"}, "second")), "second save succeeds")
    check(FileAccess.file_exists(ss.slot_path("test") + ".bak"), "previous save kept as .bak")
    var f := FileAccess.open(ss.slot_path("test"), FileAccess.WRITE)
    f.store_string("{garbage")
    f.close()
    res = ss.load_slot("test")
    check(bool(res["ok"]) and bool(res["from_backup"]) and str(res["payload"]["hello"]) == "world", "corrupt save falls back to the backup")
    ss.delete_slot("test")
    check(not bool(ss.slot_info("test")["exists"]), "delete removes the slot")
    var manual_slots: Array[String] = ["world", "1", "2", "3"]
    var manual_ok := true
    for slot_id in manual_slots:
        manual_ok = ss.save_slot(slot_id, {"slot": slot_id}, "slot picker test") and manual_ok
        var slot_result: Dictionary = ss.load_slot(slot_id)
        manual_ok = bool(slot_result.get("ok", false)) and str(slot_result.get("payload", {}).get("slot", "")) == slot_id and manual_ok
        ss.delete_slot(slot_id)
    check(manual_ok, "world and three manual slot ids save and load independently")
    var env := {"meta": {"save_version": 1}, "payload": "{\"a\":1}", "checksum": "deadbeef"}
    ss.save_slot("tamper", {"a": 1}, "x")
    var tf := FileAccess.open(ss.slot_path("tamper"), FileAccess.WRITE)
    tf.store_string(JSON.stringify(env))
    tf.close()
    check(not bool(ss.load_slot("tamper")["ok"]), "wrong checksum is rejected")
    ss.delete_slot("tamper")
    var newer := {"meta": {"save_version": 99}, "payload": "{}", "checksum": ss.checksum_of("{}")}
    var nf := FileAccess.open(ss.slot_path("future"), FileAccess.WRITE)
    nf.store_string(JSON.stringify(newer))
    nf.close()
    check(not bool(ss.load_slot("future")["ok"]), "saves from a newer version are refused")
    ss.delete_slot("future")
    ss.delete_slot("auto_a")
    ss.delete_slot("auto_b")
    ss.autosave({"i": 1}, "first")
    ss.autosave({"i": 2}, "second")
    check(bool(ss.slot_info("auto_a")["exists"]) and bool(ss.slot_info("auto_b")["exists"]), "autosave rotates between two slots")
    ss.delete_slot("auto_a")
    ss.delete_slot("auto_b")


## AI controls BOTH sides here, so this is a smoke test (does every battle terminate?) and a rough balance probe.
func _simulate_battles(n: int) -> void:
    print("[simulation]")
    var wins := 0
    var total_turns := 0
    var unfinished := 0
    for i in range(n):
        var c := BattleController.new()
        c.setup(gd.battle_def("battle_01"), gd.as_db(), 1000 + i)
        c.begin()
        var guard := 0
        while c.result == "" and guard < 800:
            c.run_ai_turn(true)
            guard += 1
        if c.result == "":
            unfinished += 1
        elif c.result == "victory":
            wins += 1
        total_turns += c.turn_count
    check(unfinished == 0, "all %d simulated battles reach a result" % n)
    print("  info  AI vs AI: player side won %d/%d, average %.1f turns per battle" % [wins, n, float(total_turns) / float(n)])


func _test_home_navigation() -> void:
    print("[home navigation]")
    check(str(ProjectSettings.get_setting("application/run/main_scene", "")) == "res://Home.tscn", "Home is the configured application entry scene")
    check(ResourceLoader.exists("res://Home.tscn"), "Home scene resource exists")
    check(ResourceLoader.exists("res://World.tscn"), "World scene remains available after Home selection")
    var world_script := FileAccess.open("res://scripts/ui/world_scene.gd", FileAccess.READ)
    var world_source := world_script.get_as_text() if world_script != null else ""
    check(not world_source.contains("_show_boot") and not world_source.contains("boot_panel"), "World scene no longer contains the legacy boot overlay")


func _test_credits_and_audio() -> void:
    print("[credits and audio]")
    var credits: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/credits.json"))
    check(typeof(credits) == TYPE_DICTIONARY and str((credits as Dictionary).get("creator", "")) == "Jose Basinillo Jr.", "credits.json names the creator, Jose Basinillo Jr.")
    var packs: Array = (credits as Dictionary).get("packs", []) if typeof(credits) == TYPE_DICTIONARY else []
    var complete := packs.size() >= 20
    for p in packs:
        var pack: Dictionary = p
        for key in ["id", "title", "kind", "author", "license", "stored", "used"]:
            if not pack.has(key):
                complete = false
    check(complete, "every credits entry has id, title, kind, author, license, stored and used")
    check(HomeScene.credits_text().contains("Jose Basinillo Jr."), "the Credits dialog text starts with the creator")
    var audio: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/audio.json"))
    var table: Dictionary = (audio as Dictionary).get("music", {}) if typeof(audio) == TYPE_DICTIONARY else {}
    var contexts_ok := table.has("home") and table.has("world") and table.has("battle") and table.has("room")
    var files_ok := true
    for ctx in table:
        var path: String = str((table[ctx] as Dictionary).get("stream", ""))
        if not (FileAccess.file_exists(path) or ResourceLoader.exists(path)):
            files_ok = false
    check(contexts_ok and files_ok, "audio.json maps home, world, battle and room to music files that exist")
    check(FileAccess.file_exists("res://assets/library/.gdignore"), "the sprite library is hidden from the Godot importer (.gdignore)")
