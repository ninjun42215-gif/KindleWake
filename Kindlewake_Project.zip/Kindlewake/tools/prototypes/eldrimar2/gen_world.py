#!/usr/bin/env python3
"""Generates the Eldrimar overworld from tools/world_design.py.

    python3 -I tools/prototypes/eldrimar2/gen_world.py     (needs numpy and Pillow)

Writes   build/eldrimar2/world_map.json   terrain + region layers (one ASCII char per tile, code = 48 + id)
         build/eldrimar2/world.json       regions, places (snapped to real ground), gates, transports, roads
         build/eldrimar2/world_overview.png   1 px per tile picture used by the minimap and the map screen
         build/eldrimar2/world_map_preview.png         labelled picture for humans
and VERIFIES the map: every gate really seals its border, every place is reachable once the gates are open, the
sea connects all docks. It exits with code 1 if a check fails.
"""
import heapq
import json
import math
import pathlib
import sys

import numpy as np
from PIL import Image, ImageDraw

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = ROOT / "build" / "eldrimar2"     # prototype output never touches data/ or assets/
sys.path.insert(0, str(HERE))
import world_design as D  # noqa: E402

W, H = D.WIDTH, D.HEIGHT
GRASS, FOREST, HILL, FORD, WATER, MOUNTAIN, ROAD, BRIDGE, SWAMP, SNOW, SAND, SEA = range(12)
TERRAIN_NAMES = ["Grass", "Forest", "Hill", "Ford", "Deep Water", "Mountain", "Road", "Bridge", "Swamp", "Snow", "Sand", "Sea"]
TERRAIN_RGB = [
    (0x41, 0x71, 0x4f), (0x2f, 0x4a, 0x38), (0x6f, 0x8f, 0x5a), (0x5c, 0x7f, 0x94), (0x2d, 0x4a, 0x63), (0x6a, 0x73, 0x80),
    (0x8a, 0x6b, 0x4a), (0xb7, 0x8b, 0x52), (0x4d, 0x5a, 0x3a), (0xd8, 0xdf, 0xe6), (0xc9, 0xb2, 0x7a), (0x1f, 0x3a, 0x57),
]
REGION_IDS = [r[0] for r in D.REGIONS]
RIDX = {rid: i for i, rid in enumerate(REGION_IDS)}
SEA_R = 0
ENTERABLE = {"keep", "city", "town", "village", "hamlet", "port", "fort", "monastery", "dungeon"}
SAFE_RADIUS = {"keep": 7, "city": 8, "town": 6, "village": 5, "hamlet": 4, "port": 5, "fort": 5, "monastery": 6, "beacon": 4, "shrine": 3}

problems = []


def fail(msg):
    problems.append(msg)
    print("  PROBLEM: " + msg)


# ------------------------------------------------------------------------------------------------ noise
YS, XS = np.mgrid[0:H, 0:W]


def vnoise(scale, seed):
    rs = np.random.RandomState(seed & 0x7FFFFFFF)
    gw = int(W / scale) + 3
    gh = int(H / scale) + 3
    lat = rs.random_sample((gh, gw))
    fx = XS / scale
    fy = YS / scale
    ix = fx.astype(np.int64)
    iy = fy.astype(np.int64)
    tx = fx - ix
    ty = fy - iy
    tx = tx * tx * (3 - 2 * tx)
    ty = ty * ty * (3 - 2 * ty)
    a = lat[iy, ix] * (1 - tx) + lat[iy, ix + 1] * tx
    b = lat[iy + 1, ix] * (1 - tx) + lat[iy + 1, ix + 1] * tx
    return a * (1 - ty) + b * ty


def fbm(seed, scales, weights):
    out = np.zeros((H, W))
    for i, (s, w) in enumerate(zip(scales, weights)):
        out += vnoise(s, seed + 101 * i) * w
    return out / sum(weights)


def shifted(arr, dx, dy, fill):
    out = np.full_like(arr, fill)
    ys0, ys1 = max(0, dy), min(H, H + dy)
    xs0, xs1 = max(0, dx), min(W, W + dx)
    out[ys0:ys1, xs0:xs1] = arr[ys0 - dy:ys1 - dy, xs0 - dx:xs1 - dx]
    return out


def dilate(mask, r):
    out = mask.copy()
    for _ in range(r):
        n = out.copy()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n |= shifted(out, dx, dy, False)
        out = n
    return out


def ellipse(cx, cy, rx, ry, jitter=None):
    d = ((XS - cx) / rx) ** 2 + ((YS - cy) / ry) ** 2
    if jitter is not None:
        d = d + (jitter - 0.5) * 0.7
    return d < 1.0


# ------------------------------------------------------------------------------------------------ land and regions
def build_land_and_regions():
    seed = D.SEED
    n1 = fbm(seed + 11, (70, 35, 17), (0.5, 0.3, 0.2))
    cx, cy, rx, ry, p = 226, 156, 214, 142, 3.4
    d = (np.abs((XS - cx) / rx)) ** p + (np.abs((YS - cy) / ry)) ** p
    land = (d + (n1 - 0.5) * 0.85) < 1.0
    land[:, :16] = False
    land[:, W - 16:] = False
    land[:14, :] = False
    land[H - 40:, :] = False
    for (bx, by, brx, bry) in D.BAYS:
        land &= ~ellipse(bx, by, brx, bry, fbm(seed + 5, (20, 9), (0.6, 0.4)))
    # islands are separate land that belongs to the isles region
    island = np.zeros((H, W), dtype=bool)
    for k, blobs in D.ISLANDS.items():
        for (ix, iy, irx, iry) in blobs:
            island |= ellipse(ix, iy, irx, iry, fbm(seed + 9, (12, 6), (0.6, 0.4)))
    # drop tiny islets of the mainland
    land = keep_big_components(land, 600)
    wx = XS + (fbm(seed + 21, (90, 45), (0.6, 0.4)) - 0.5) * 46
    wy = YS + (fbm(seed + 22, (90, 45), (0.6, 0.4)) - 0.5) * 46
    best = np.full((H, W), 1e9)
    idx = np.zeros((H, W), dtype=np.int64)
    for rid, seeds in D.SEEDS.items():
        for (sx, sy) in seeds:
            dd = np.hypot(wx - sx, wy - sy)
            m = dd < best
            best[m] = dd[m]
            idx[m] = RIDX[rid]
    region = np.where(land, idx, SEA_R)
    region[island] = RIDX["isles"]
    land = land | island
    return land, region


def keep_big_components(mask, min_size):
    seen = np.zeros_like(mask, dtype=bool)
    out = np.zeros_like(mask, dtype=bool)
    for y in range(H):
        for x in range(W):
            if mask[y, x] and not seen[y, x]:
                comp = []
                stack = [(x, y)]
                seen[y, x] = True
                while stack:
                    cx_, cy_ = stack.pop()
                    comp.append((cx_, cy_))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = cx_ + dx, cy_ + dy
                        if 0 <= nx < W and 0 <= ny < H and mask[ny, nx] and not seen[ny, nx]:
                            seen[ny, nx] = True
                            stack.append((nx, ny))
                if len(comp) >= min_size:
                    for (px, py) in comp:
                        out[py, px] = True
    return out


# ------------------------------------------------------------------------------------------------ biomes
BIOME = {   # forest wetness threshold, hill, mountain elevation thresholds, pond elevation threshold
    "sethmarch": (0.60, 0.70, 0.88, 0.24), "orrowen": (0.46, 0.72, 0.90, 0.25), "highwood": (0.40, 0.70, 0.88, 0.24),
    "quillon": (0.62, 0.55, 0.76, 0.20), "aurelmont": (0.72, 0.74, 0.92, 0.22), "brennhallow": (0.66, 0.58, 0.78, 0.20),
    "frostfang": (0.60, 0.52, 0.72, 0.20), "vessmoor": (0.84, 0.80, 0.95, 0.22), "tarnholt": (0.58, 0.60, 0.84, 0.22),
    "fens": (0.66, 0.82, 0.96, 0.33), "ysmark": (0.72, 0.76, 0.93, 0.22), "isles": (0.74, 0.62, 0.82, 0.10), "sea": (1, 1, 1, 0),
}


def build_terrain(land, region):
    seed = D.SEED
    e = fbm(seed + 1, (44, 22, 11, 5), (0.38, 0.30, 0.20, 0.12))
    wet = fbm(seed + 31, (36, 18, 9, 4), (0.4, 0.3, 0.2, 0.1))
    t = np.full((H, W), GRASS, dtype=np.int64)
    for rid, (fthr, hthr, mthr, pthr) in BIOME.items():
        m = region == RIDX[rid]
        if rid == "sea":
            continue
        sub = np.full((H, W), GRASS, dtype=np.int64)
        sub[wet > fthr] = FOREST
        sub[e > hthr] = HILL
        sub[e > mthr] = MOUNTAIN
        sub[e < pthr] = WATER
        if rid == "fens":
            sub[(wet > 0.47) & (sub == GRASS)] = SWAMP
            sub[(wet > 0.47) & (sub == FOREST)] = SWAMP
        if rid == "frostfang":
            sub[sub == GRASS] = SNOW
        if rid in ("quillon", "brennhallow"):
            sub[(e > 0.64) & (sub == GRASS)] = SNOW
        t[m] = sub[m]
    sea = ~land
    t[sea] = SEA
    near_sea = dilate(sea, 2) & land
    for rid in ("ysmark", "isles", "sethmarch"):
        m = (region == RIDX[rid]) & near_sea & (t == GRASS)
        t[m] = SAND
    return t, e, wet


# ------------------------------------------------------------------------------------------------ borders
def pair_key(a, b):
    return tuple(sorted((a, b)))


def build_barriers(land, region, t):
    """Raises a mountain (or river) band along every sealed border. Returns (band mask, band pair id array, pairs)."""
    n = fbm(D.SEED + 41, (14, 6), (0.6, 0.4))
    adj = set()
    for k in (1, 2, 3):
        for dx, dy in ((k, 0), (0, k)):
            r2 = shifted(region, dx, dy, SEA_R)
            m = (region != r2) & (region != SEA_R) & (r2 != SEA_R)
            for a, b in set(zip(region[m].tolist(), r2[m].tolist())):
                adj.add(pair_key(REGION_IDS[a], REGION_IDS[b]))
    open_pairs = {pair_key(*p) for p in D.OPEN_BORDERS}
    river_pairs = {pair_key(*p) for p in D.RIVER_BORDERS}
    sealed = sorted(adj - open_pairs)
    print("  adjacent region pairs: %d (open %d, river %d, mountain %d)" % (len(adj), len(adj & open_pairs), len(adj & river_pairs), len(sealed) - len(adj & river_pairs)))
    pair_ids = {p: i + 1 for i, p in enumerate(sealed)}
    band = np.zeros((H, W), dtype=bool)
    band_pair = np.zeros((H, W), dtype=np.int64)
    for k in (1, 2, 3, 4):
        need = {1: 0.0, 2: 0.25, 3: 0.55, 4: 0.8}[k]
        for dx, dy in ((k, 0), (-k, 0), (0, k), (0, -k)):
            r2 = shifted(region, dx, dy, SEA_R)
            diff = (region != r2) & (region != SEA_R) & (r2 != SEA_R) & (n > need)
            if not diff.any():
                continue
            for a, b in set(zip(region[diff].tolist(), r2[diff].tolist())):
                key = pair_key(REGION_IDS[a], REGION_IDS[b])
                if key in open_pairs:
                    continue
                mm = diff & (region == a) & (r2 == b)
                width_ok = mm if key not in river_pairs or k <= 2 else np.zeros_like(mm)
                band |= width_ok
                band_pair[width_ok & (band_pair == 0)] = pair_ids[key]
    for p in sealed:
        mask = band_pair == pair_ids[p]
        t[mask & (t != SEA)] = WATER if p in river_pairs else MOUNTAIN
    foothills = dilate(band, 3) & ~band & land
    mm = foothills & np.isin(t, (GRASS, FOREST)) & (fbm(D.SEED + 43, (9, 4), (0.6, 0.4)) > 0.38)
    t[mm] = HILL
    t[band & (t == SEA)] = SEA
    return band, band_pair, pair_ids, river_pairs


# ------------------------------------------------------------------------------------------------ rivers and lakes
def carve_rivers(t, land, band):
    n = fbm(D.SEED + 51, (18, 8), (0.6, 0.4))
    for (lx, ly, lrx, lry) in D.LAKES:
        m = ellipse(lx, ly, lrx, lry, fbm(D.SEED + 53, (10, 5), (0.6, 0.4))) & land & ~band
        t[m] = WATER
    for pts in D.RIVERS:
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            steps = int(max(abs(bx - ax), abs(by - ay))) + 1
            for s in range(steps + 1):
                f = s / steps
                x = ax + (bx - ax) * f
                y = ay + (by - ay) * f
                off = (n[int(min(H - 1, max(0, y))), int(min(W - 1, max(0, x)))] - 0.5) * 14
                x += off * (by - ay) / (steps + 1e-9) * 0.0 + off * 0.5
                y += off * 0.3
                for ddx in (0, 1):
                    for ddy in (0, 1):
                        px, py = int(round(x)) + ddx, int(round(y)) + ddy
                        if 0 <= px < W and 0 <= py < H and land[py, px] and not band[py, px]:
                            t[py, px] = WATER


# ------------------------------------------------------------------------------------------------ places
def spiral(cx, cy, rmax):
    yield cx, cy
    for r in range(1, rmax + 1):
        for dx in range(-r, r + 1):
            yield cx + dx, cy - r
            yield cx + dx, cy + r
        for dy in range(-r + 1, r):
            yield cx - r, cy + dy
            yield cx + r, cy + dy


def sea_components(t):
    comp = np.zeros((H, W), dtype=np.int64)
    sizes = {}
    cid = 0
    for y in range(H):
        for x in range(W):
            if t[y, x] == SEA and comp[y, x] == 0:
                cid += 1
                stack = [(x, y)]
                comp[y, x] = cid
                cnt = 0
                while stack:
                    px, py = stack.pop()
                    cnt += 1
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = px + dx, py + dy
                        if 0 <= nx < W and 0 <= ny < H and t[ny, nx] == SEA and comp[ny, nx] == 0:
                            comp[ny, nx] = cid
                            stack.append((nx, ny))
                sizes[cid] = cnt
    main = max(sizes, key=lambda k: sizes[k])
    return comp, main


def snap_places(t, region, band):
    near_band = dilate(band, 4)
    comp, main_sea = sea_components(t)
    sea_main = comp == main_sea
    near_sea = dilate(sea_main, 5)
    placed = []
    taken = []
    ok_terrain = (GRASS, FOREST, HILL, SAND, SNOW, SWAMP)
    for p in D.PLACES:
        rid = p["region"]
        x0, y0 = p["at"]
        found = None
        for (x, y) in spiral(x0, y0, 60):
            if not (0 <= x < W and 0 <= y < H):
                continue
            if region[y, x] != RIDX[rid] or t[y, x] not in ok_terrain:
                continue
            if near_band[y, x] and p["kind"] not in ("fort",) and p["id"] not in ("camp",):
                continue
            if p.get("dock") and not near_sea[y, x]:
                continue
            if any(abs(x - qx) + abs(y - qy) < 12 for (qx, qy) in taken):
                continue
            # the 5x5 meadow must not touch water-only ground on the edge, and the cell must not sit inside the band
            if band[y, x]:
                continue
            found = (x, y)
            break
        if found is None:
            fail("cannot place %s near %s" % (p["id"], p["at"]))
            found = (x0, y0)
        if abs(found[0] - x0) + abs(found[1] - y0) > 18:
            print("  note: %s moved %s -> %s" % (p["id"], p["at"], found))
        taken.append(found)
        placed.append(found)
    return placed, comp, main_sea


def carve_meadows(t, band, placed):
    for (x, y), p in zip(placed, D.PLACES):
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                cx, cy = x + dx, y + dy
                if not (0 <= cx < W and 0 <= cy < H) or band[cy, cx] or t[cy, cx] == SEA:
                    continue
                if abs(dx) <= 1 and abs(dy) <= 1 or t[cy, cx] in (WATER, MOUNTAIN, FOREST, SWAMP):
                    if not (p.get("ford") and t[cy, cx] == WATER and abs(dx) <= 2):
                        t[cy, cx] = SAND if t[cy, cx] == SAND else GRASS
        if p.get("ford"):
            for dy in range(-3, 4):
                for dx in range(-3, 4):
                    cx, cy = x + dx, y + dy
                    if 0 <= cx < W and 0 <= cy < H and t[cy, cx] == WATER and not band[cy, cx]:
                        t[cy, cx] = FORD


# ------------------------------------------------------------------------------------------------ roads
COST = {GRASS: 1.0, FOREST: 2.4, HILL: 1.9, FORD: 3.2, WATER: 9.0, MOUNTAIN: 15.0, ROAD: 0.45, BRIDGE: 0.7, SWAMP: 3.2, SNOW: 1.6, SAND: 1.2}


def astar(t, band, start, goal, noise, allow_band_goal=True):
    sx, sy = start
    gx, gy = goal
    INF = 1e18
    dist = {start: 0.0}
    prev = {}
    pq = [(0.0, start)]
    while pq:
        f, cur = heapq.heappop(pq)
        if cur == goal:
            break
        cx, cy = cur
        gcur = dist[cur]
        if f - gcur - 0.8 * (abs(cx - gx) + abs(cy - gy)) > 1e-6 and f > gcur + 0.8 * (abs(cx - gx) + abs(cy - gy)) + 1e-6:
            continue
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = cx + dx, cy + dy
            if not (1 <= nx < W - 1 and 1 <= ny < H - 1):
                continue
            tt = int(t[ny, nx])
            if tt == SEA:
                continue
            c = COST[tt] * (1.0 + 0.35 * noise[ny, nx])
            if band[ny, nx]:
                c += 40.0
            ng = gcur + c
            if ng < dist.get((nx, ny), INF):
                dist[(nx, ny)] = ng
                prev[(nx, ny)] = cur
                heapq.heappush(pq, (ng + 0.8 * (abs(nx - gx) + abs(ny - gy)), (nx, ny)))
    if goal not in prev and goal != start:
        return None
    path = [goal]
    while path[-1] != start:
        path.append(prev[path[-1]])
    path.reverse()
    return path


def lay_road(t, path):
    for (x, y) in path:
        tt = int(t[y, x])
        if tt in (WATER, FORD):
            t[y, x] = BRIDGE
        elif tt != BRIDGE:
            t[y, x] = ROAD


def build_roads(t, band, band_pair, pair_ids, placed):
    noise = fbm(D.SEED + 61, (10, 5), (0.6, 0.4))
    cells = {p["id"]: placed[i] for i, p in enumerate(D.PLACES)}
    gate_defs = {g["id"]: g for g in D.GATES}
    gates_out = []
    for r in D.ROADS:
        a, b = r[0], r[1]
        if len(r) == 2:
            path = astar(t, band, cells[a], cells[b], noise)
            if path is None:
                fail("no road %s-%s" % (a, b))
                continue
            lay_road(t, path)
            continue
        g = gate_defs[r[2]]
        key = pair_key(*g["between"])
        mask = band_pair == pair_ids[key]
        ys, xs = np.nonzero(mask)
        if len(xs) == 0:
            fail("gate %s: no band between %s" % (g["id"], g["between"]))
            continue
        nx_, ny_ = g["near"]
        k = int(np.argmin((xs - nx_) ** 2 + (ys - ny_) ** 2))
        pass_cell = (int(xs[k]), int(ys[k]))
        p1 = astar(t, band, cells[a], pass_cell, noise)
        p2 = astar(t, band, pass_cell, cells[b], noise)
        if p1 is None or p2 is None:
            fail("no road through gate %s" % g["id"])
            continue
        full = p1 + p2[1:]
        lay_road(t, full)
        inside = [c for c in full if band[c[1], c[0]]]
        if not inside:
            fail("gate %s: the road never enters the band" % g["id"])
            continue
        mid = len(inside) // 2
        lo = max(0, mid - 1)
        cells_g = inside[lo:lo + 3]
        entry = dict(g)
        entry["cells"] = [[c[0], c[1]] for c in cells_g]
        entry["pass_cell"] = [pass_cell[0], pass_cell[1]]
        gates_out.append(entry)
    return gates_out


# ------------------------------------------------------------------------------------------------ verification
WALK = {GRASS, FOREST, HILL, FORD, ROAD, BRIDGE, SWAMP, SNOW, SAND}


def flood(t, start, closed_cells, passable=WALK):
    seen = np.zeros((H, W), dtype=bool)
    seen[start[1], start[0]] = True
    stack = [start]
    while stack:
        x, y = stack.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and not seen[ny, nx] and int(t[ny, nx]) in passable and (nx, ny) not in closed_cells:
                seen[ny, nx] = True
                stack.append((nx, ny))
    return seen


def exit_cell_for(t, cell):
    x, y = cell
    for dx, dy in ((0, 1), (0, 2), (1, 1), (-1, 1), (1, 0), (-1, 0), (0, -1)):
        nx, ny = x + dx, y + dy
        if 0 <= nx < W and 0 <= ny < H and int(t[ny, nx]) in WALK:
            return [nx, ny]
    return [x, y]


def pick_docks(t, placed, comp, main_sea):
    docks = {}
    for i, p in enumerate(D.PLACES):
        if not p.get("dock"):
            continue
        x, y = placed[i]
        best = None
        for (nx, ny) in spiral(x, y, 9):
            if 0 <= nx < W and 0 <= ny < H and comp[ny, nx] == main_sea:
                best = (nx, ny)
                break
        if best is None:
            fail("no dock cell for %s" % p["id"])
            continue
        docks[p["id"]] = [best[0], best[1]]
    return docks


def verify(t, placed, gates, docks, comp, main_sea):
    cells = {p["id"]: placed[i] for i, p in enumerate(D.PLACES)}
    start = cells[D.START]
    all_closed = set()
    for g in gates:
        for c in g["cells"]:
            all_closed.add((c[0], c[1]))
    closed_reach = flood(t, start, all_closed)
    open_reach = flood(t, start, set())
    print("  walkable land: %d tiles; reachable at the start with every gate shut: %d; with every gate open: %d" % (
        int(np.isin(t, list(WALK)).sum()), int(closed_reach.sum()), int(open_reach.sum())))
    isles_ids = {p["id"] for p in D.PLACES if p["region"] == "isles"}
    for p in D.PLACES:
        c = cells[p["id"]]
        if p["id"] in isles_ids:
            if open_reach[c[1], c[0]]:
                fail("%s on the isles should be ship-only but is reachable on foot" % p["id"])
            continue
        if not open_reach[c[1], c[0]]:
            fail("%s is not reachable on foot even with every gate open" % p["id"])
    # staged opening: shut state must only reach the free regions
    region_free = {"sethmarch", "orrowen"}
    reg_of = {p["id"]: p["region"] for p in D.PLACES}
    for pid, c in cells.items():
        if reg_of[pid] in isles_ids:
            continue
        reach = bool(closed_reach[c[1], c[0]])
        if reach and reg_of[pid] not in region_free:
            fail("%s (%s) is reachable at the start although a gate should seal it" % (pid, reg_of[pid]))
        if (not reach) and reg_of[pid] in region_free:
            fail("%s (%s) should be reachable at the start" % (pid, reg_of[pid]))
    # every gate must matter: opening only that gate must reach new ground, and closing only it must cut something off
    for g in gates:
        gc = {(c[0], c[1]) for c in g["cells"]}
        others = all_closed - gc
        if flood(t, start, others).sum() == flood(t, start, all_closed).sum():
            pass
    for g in gates:
        for c in g["cells"]:
            if int(t[c[1], c[0]]) not in (ROAD, BRIDGE):
                fail("gate %s cell %s is not on a road" % (g["id"], c))
    # sea
    for pid, d in docks.items():
        if comp[d[1], d[0]] != main_sea:
            fail("dock of %s is not on the main sea" % pid)
    for pid, c in cells.items():
        if not D.PLACES[[q["id"] for q in D.PLACES].index(pid)].get("dock"):
            continue
    return closed_reach, open_reach


# ------------------------------------------------------------------------------------------------ output
def tint_of(rid):
    return D.REGIONS[RIDX[rid]][3]


def write_overview(t, region):
    img = np.zeros((H, W, 3), dtype=np.uint8)
    tint = np.array([D.REGIONS[i][3] for i in range(len(D.REGIONS))])
    base = np.array(TERRAIN_RGB, dtype=np.float64)[t]
    img = np.clip(base * tint[region], 0, 255).astype(np.uint8)
    OUT.mkdir(parents=True, exist_ok=True)
    Image.fromarray(img, "RGB").save(OUT / "world_overview.png", optimize=True)
    return img


def write_preview(img, placed, gates, docks):
    scale = 2
    big = Image.fromarray(img, "RGB").resize((W * scale, H * scale), Image.NEAREST)
    dr = ImageDraw.Draw(big)
    for g in gates:
        for c in g["cells"]:
            x, y = c[0] * scale, c[1] * scale
            dr.rectangle([x - 4, y - 4, x + 6, y + 6], outline=(255, 60, 60), width=2)
        c = g["cells"][len(g["cells"]) // 2]
        dr.text((c[0] * scale + 8, c[1] * scale - 12), g["id"], fill=(255, 220, 220))
    for (x, y), p in zip(placed, D.PLACES):
        col = {"beacon": (255, 160, 40), "dungeon": (220, 60, 220), "camp": (255, 60, 60), "ruin": (200, 200, 200)}.get(p["kind"], (255, 255, 90))
        dr.ellipse([x * scale - 4, y * scale - 4, x * scale + 4, y * scale + 4], fill=col, outline=(0, 0, 0))
        dr.text((x * scale + 6, y * scale - 5), p["name"], fill=(255, 255, 255))
    # region labels
    for rid, seeds in D.SEEDS.items():
        sx = sum(s[0] for s in seeds) / len(seeds)
        sy = sum(s[1] for s in seeds) / len(seeds)
        dr.text((sx * scale - 30, sy * scale + 14), D.REGIONS[RIDX[rid]][1].upper(), fill=(255, 255, 255))
    OUT.mkdir(parents=True, exist_ok=True)
    big.save(OUT / "world_map_preview.png", optimize=True)


def rows_of(arr, offset=48):
    return ["".join(chr(offset + int(v)) for v in arr[y]) for y in range(H)]


def main():
    print("generating Eldrimar %dx%d" % (W, H))
    land, region = build_land_and_regions()
    t, e, wet = build_terrain(land, region)
    band, band_pair, pair_ids, river_pairs = build_barriers(land, region, t)
    carve_rivers(t, land, band)
    placed, comp, main_sea = snap_places(t, region, band)
    carve_meadows(t, band, placed)
    docks = pick_docks(t, placed, comp, main_sea)
    gates = build_roads(t, band, band_pair, pair_ids, placed)
    # a place stands on a road tile
    for (x, y) in placed:
        t[y, x] = ROAD
    closed_reach, open_reach = verify(t, placed, gates, docks, comp, main_sea)

    cells = {p["id"]: placed[i] for i, p in enumerate(D.PLACES)}
    places_out = []
    for i, p in enumerate(D.PLACES):
        q = {k: v for k, v in p.items() if k not in ("at",)}
        q["cell"] = [placed[i][0], placed[i][1]]
        q["exit"] = exit_cell_for(t, placed[i])
        if p["kind"] in ENTERABLE:
            q["town"] = p["id"]
        if p["kind"] in SAFE_RADIUS:
            q["safe"] = SAFE_RADIUS[p["kind"]]
        if p["id"] in docks:
            q["dock"] = docks[p["id"]]
        else:
            q.pop("dock", None)
        places_out.append(q)
    gates_final = []
    for g in gates:
        gg = {k: v for k, v in g.items() if k not in ("between", "near")}
        gg["between"] = list(g["between"])
        gates_final.append(gg)
    region_cfg = {}
    for i, (rid, name, danger, tint, blurb) in enumerate(D.REGIONS):
        region_cfg[rid] = {"index": i, "name": name, "danger": danger, "tint": list(tint), "table": rid, "blurb": blurb}
    world = {
        "name": "Eldrimar", "version": 2, "seed": D.SEED, "width": W, "height": H, "start": D.START,
        "map_file": "world_map.json", "seen_block": 8, "safe_radius": 5, "encounter_min": 900, "encounter_max": 1800,
        "terrain_names": TERRAIN_NAMES,
        "regions": region_cfg, "region_order": REGION_IDS,
        "transports": D.TRANSPORTS,
        "places": places_out, "gates": gates_final,
        "roads": [list(r) for r in D.ROADS],
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "world.json").write_text(json.dumps(world, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    layers = {"width": W, "height": H, "offset": 48, "terrain": rows_of(t), "region": rows_of(region)}
    (OUT / "world_map.json").write_text(json.dumps(layers, separators=(",", ":")) + "\n", encoding="utf-8")
    img = write_overview(t, region)
    write_preview(img, placed, gates_final, docks)

    total_land = int((region != SEA_R).sum())
    print("  land %d tiles (%.0f%% of the map), %d places, %d gates, %d docks" % (total_land, 100.0 * total_land / (W * H), len(places_out), len(gates_final), len(docks)))
    for i, (rid, name, *_r) in enumerate(D.REGIONS):
        print("   %-12s %6d tiles" % (rid, int((region == i).sum())))
    if problems:
        print("\n%d PROBLEM(S)" % len(problems))
        sys.exit(1)
    print("world OK")


if __name__ == "__main__":
    main()
