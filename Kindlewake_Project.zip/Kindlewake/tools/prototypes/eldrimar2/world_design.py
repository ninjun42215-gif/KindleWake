#!/usr/bin/env python3
"""Hand-authored design of the Eldrimar overworld (v0.8.0). DATA ONLY: gen_world.py turns it into
data/world.json + data/world_map.json (terrain, regions, roads, gates) and gen_content.py turns it into
towns, dungeons, enemies, encounter tables and quests. Edit this file, run both generators, run the tests.

Coordinates are tiles on a 452 x 340 map (x right, y down). The generator snaps every place to nearby
walkable ground of its own region and reports every move, so rough numbers are fine.
"""

WIDTH = 452
HEIGHT = 340
SEED = 1187
START = "sethorn"

# ---------------------------------------------------------------------------------------------------------------------
# Regions. index 0 is the open sea. danger multiplies the ambush meter, tint colours the ground (1.0 = neutral).
# ---------------------------------------------------------------------------------------------------------------------
REGIONS = [
    # id, name, danger, tint (r, g, b), blurb shown when you cross the border
    ("sea", "The Brinesea", 0.8, (1.0, 1.0, 1.0), "Grey water, white gulls and the smell of salt."),
    ("sethmarch", "Sethmarch", 1.0, (1.0, 1.0, 1.0), "Home. Dunmarrow roads, cracked and quiet."),
    ("orrowen", "Orrowen Weald", 1.1, (0.90, 1.0, 0.86), "Green oaks, yeoman farms and long shadows."),
    ("highwood", "Orrowen Highwood", 1.3, (0.86, 0.96, 0.88), "The old forest north of the Ashmere, where the paths forget you."),
    ("quillon", "Quillon Heights", 1.6, (0.90, 0.92, 1.05), "Wind, wards and towers that watch the roads."),
    ("aurelmont", "Aurelmont Reach", 2.0, (1.06, 1.0, 0.88), "The crown lands. Golden fields, iron law."),
    ("brennhallow", "Brennhallow Highlands", 1.8, (1.04, 0.90, 0.86), "Fortress marches. Every hill has a garrison."),
    ("frostfang", "Frostfang Peaks", 2.2, (0.94, 0.98, 1.08), "Snow to the knee and silence to the ear."),
    ("vessmoor", "Vessmoor Plains", 1.3, (1.08, 1.02, 0.80), "Wind-combed grass and the thunder of hooves."),
    ("tarnholt", "Tarnholt Cloisters", 1.4, (0.95, 0.94, 0.98), "Pilgrim roads, bell towers and sacred hills."),
    ("fens", "Ashen Fens", 1.6, (0.86, 0.95, 0.84), "Mist, reeds and lanterns that are not what they seem."),
    ("ysmark", "Ysmark Coast", 1.2, (1.0, 1.0, 1.04), "Harbours, ledgers and crossbows for hire."),
    ("isles", "The Cinder Isles", 1.8, (1.04, 0.98, 0.92), "Black rock and old fire, far from any road."),
]

# Voronoi seeds (several per region give an irregular shape). Distances are measured on a noise-warped plane.
SEEDS = {
    "sethmarch": [(70, 258), (118, 266), (92, 232)],
    "orrowen": [(62, 196), (112, 190)],
    "highwood": [(76, 132), (124, 124)],
    "quillon": [(70, 72), (124, 62)],
    "aurelmont": [(230, 62), (266, 84)],
    "brennhallow": [(326, 72), (352, 108)],
    "frostfang": [(392, 50), (388, 88)],
    "vessmoor": [(346, 174), (388, 196), (334, 216)],
    "tarnholt": [(226, 150), (252, 190)],
    "fens": [(200, 262), (246, 276), (170, 222)],
    "ysmark": [(358, 268), (396, 252), (332, 290)],
}

# Region pairs that touch. "open" = free border, anything else touching is sealed by a mountain range
# (or a river for "river") and can only be crossed where a pass is listed in PASSES.
OPEN_BORDERS = {("sethmarch", "orrowen"), ("ysmark", "vessmoor")}
RIVER_BORDERS = {("orrowen", "highwood")}

# Where the continent has bays, lakes and islands. (cx, cy, rx, ry)
BAYS = [(350, 312, 50, 30)]
LAKES = [(238, 176, 17, 10), (92, 172, 9, 6), (396, 62, 9, 6), (300, 238, 7, 5)]
ISLANDS = {"isles": [(205, 322, 24, 10), (60, 324, 10, 6)]}

# Rivers: lists of waypoints from the source to the sea or a lake. They meander and are 2 tiles wide.
RIVERS = [
    [(124, 214), (114, 236), (102, 258), (96, 282), (92, 304)],          # the Sallow
    [(252, 214), (270, 250), (300, 270), (330, 296)],                    # the Brine
    [(340, 140), (346, 190), (352, 240), (356, 290)],                    # the Redwater
]

# ---------------------------------------------------------------------------------------------------------------------
# Gates: a closed gate blocks its cells until every requirement is met (a flag, "!flag", "item:id", "gold:n").
# `pass_between` names the two regions whose sealed border the road pierces; `near` is a hint where.
# ---------------------------------------------------------------------------------------------------------------------
GATES = [
    {"id": "g_camp", "name": "Roadwolf Palisade", "kind": "barricade", "between": ("sethmarch", "fens"), "near": (150, 250),
     "requires": ["camp_cleared"],
     "hint": "Hask Gravelteeth's palisade bars the eastern road. Break the Roadwolf Camp.",
     "open_text": "The palisade is a heap of charred stakes. The eastern road is open."},
    {"id": "g_bridge", "name": "Ashford Bridge", "kind": "bridge", "between": ("orrowen", "highwood"), "near": (90, 160),
     "requires": ["bridge_mended"],
     "hint": "The bridge at Ashford is out. Carpenter Dunstan will rebuild it for 100 gold of timber.",
     "open_text": "New planks, still smelling of resin. Ashford Bridge holds."},
    {"id": "g_quillon", "name": "Warded Gate of Quillon", "kind": "ward", "between": ("highwood", "quillon"), "near": (100, 98),
     "requires": ["quillon_writ"],
     "hint": "A ward-sealed gate hums in the stone. Only a Quillon writ of passage will open it.",
     "open_text": "The wards flicker and sleep as your writ is read. The gate swings wide."},
    {"id": "g_toll", "name": "Brine Tollhouse Gate", "kind": "toll", "between": ("fens", "ysmark"), "near": (292, 280),
     "requires": ["ysmark_toll"],
     "hint": "The Brine Tollhouse bars the coast road until the 150 gold toll is paid.",
     "open_text": "The toll-keeper lifts the bar. Ysmark's roads are open."},
    {"id": "g_cloister", "name": "Pilgrim Gate", "kind": "ward", "between": ("fens", "tarnholt"), "near": (222, 216),
     "requires": ["pilgrim_token"],
     "hint": "The Pilgrim Gate admits only the penitent. Bring a pilgrim's token from the Sunken Chapel.",
     "open_text": "The gate-wardens bow at the token. The pilgrim road climbs on."},
    {"id": "g_brenn", "name": "Iron Gate of Brennhold", "kind": "iron", "between": ("vessmoor", "brennhallow"), "near": (350, 138),
     "requires": ["brennhallow_writ"],
     "hint": "The Iron Gate stays shut without a Brennhallow writ. The Regent's envoy at Cindermead issues them.",
     "open_text": "Pikes part. The Iron Gate grinds open for the Regent's writ."},
    {"id": "g_frost", "name": "Blizzard Wall", "kind": "blizzard", "between": ("brennhallow", "frostfang"), "near": (376, 76),
     "requires": ["frost_charm"],
     "hint": "A wall of blizzard blocks the northern pass. A charm kindled at Tarnholt might turn the wind.",
     "open_text": "The charm glows. The blizzard parts before you like a curtain."},
    {"id": "g_capital", "name": "Great Gate of Aurelmont", "kind": "iron", "between": ("tarnholt", "aurelmont"), "near": (240, 108),
     "requires": ["seal_quillon", "seal_tarnholt", "seal_brennhold"],
     "hint": "The Great Gate answers to three seals: Quillon's, Tarnholt's and Brennhold's.",
     "open_text": "Three seals burn in the gate-stone. The Great Gate of Aurelmont opens."},
]

# Roads (place, place). Roads that cross a sealed border listed in a gate go through that gate's pass.
ROADS = [
    ("sethorn", "crossing"), ("crossing", "watch"), ("sethorn", "thornby"), ("sethorn", "sethorn_landing"),
    ("sethorn", "barrow"), ("thornby", "flame_sethorn"), ("crossing", "camp"), ("crossing", "greenmoot"),
    ("greenmoot", "orrowen_hall"), ("greenmoot", "fletchers_hollow"), ("orrowen_hall", "ashford"),
    ("orrowen_hall", "flame_orrowen"),
    ("ashford", "highmoot", "g_bridge"), ("highmoot", "bowyers_rest"), ("highmoot", "barrow_oak"),
    ("highmoot", "scriptorium", "g_quillon"), ("scriptorium", "quillon_tower"), ("quillon_tower", "undercroft"),
    ("quillon_tower", "flame_quillon"),
    ("camp", "mirewatch", "g_camp"), ("mirewatch", "brackwater"), ("brackwater", "sunken_chapel"),
    ("brackwater", "fen_camp"),
    ("brackwater", "tollhouse"), ("tollhouse", "saltcote", "g_toll"), ("saltcote", "brinegate"),
    ("brinegate", "smugglers_cove"), ("brinegate", "flame_ysmark"),
    ("brinegate", "cindermead"), ("cindermead", "redfield"), ("cindermead", "duelling_green"),
    ("redfield", "steppe_camp"), ("cindermead", "flame_vessmoor"),
    ("steppe_camp", "ironhold", "g_brenn"), ("ironhold", "brennhold"), ("brennhold", "brennhold_vault"),
    ("brennhold", "flame_brennhallow"),
    ("brennhold", "winterwatch", "g_frost"), ("winterwatch", "rime_hollow"), ("winterwatch", "frostfang_cairn"),
    ("brackwater", "pilgrims_rest", "g_cloister"), ("pilgrims_rest", "tarnholt_cloister"),
    ("tarnholt_cloister", "reliquary"), ("tarnholt_cloister", "flame_tarnholt"),
    ("tarnholt_cloister", "goldfield", "g_capital"), ("goldfield", "aurelmont_city"), ("aurelmont_city", "kaer_aurel"),
]

# ---------------------------------------------------------------------------------------------------------------------
# Places. kind decides the picture, the safe zone and the town template:
#   keep, city, town, village, hamlet, port, fort, monastery  -> walkable town map (id = map id)
#   dungeon -> multi-room dungeon map with random fights and a boss     ruin, camp, beacon, shrine -> actions only
# `fast` places can be fast-travelled to once visited. `dock` places have a sea cell for the ship.
# ---------------------------------------------------------------------------------------------------------------------
PLACES = [
    # ---- Sethmarch ------------------------------------------------------------------------------------------------
    {"id": "sethorn", "name": "Kaer Sethorn", "kind": "keep", "region": "sethmarch", "at": (66, 254), "fast": True,
     "text": "The broken keep of House Dunmarrow. Torren's company rests here, sorts its gear and counts its coin."},
    {"id": "crossing", "name": "Sallow Crossing", "kind": "village", "region": "sethmarch", "at": (100, 258), "ford": True,
     "text": "A ford village where carters, peddlers and rumours meet. The market sells gear and sigils."},
    {"id": "watch", "name": "Old Watchtower", "kind": "ruin", "region": "sethmarch", "at": (98, 210), "reward_gold": 60,
     "text": "A fallen border tower. Someone hid a purse in the cellar long ago."},
    {"id": "camp", "name": "Roadwolf Camp", "kind": "camp", "region": "sethmarch", "at": (140, 252),
     "text": "Hask Gravelteeth's raiders hold the road to Eldrimar from this palisade.",
     "actions": [{"label": "Attack the camp", "requires": ["!camp_cleared"], "battle": "battle_01",
                  "on_win": {"set": ["camp_cleared"]}}],
     "done_text": "The palisade burns. The raiders are gone.", "done_if": ["camp_cleared"]},
    {"id": "thornby", "name": "Thornby", "kind": "hamlet", "region": "sethmarch", "at": (62, 224),
     "text": "A handful of thatched roofs and a very old well. The villagers still leave out bread for Dunmarrow."},
    {"id": "barrow", "name": "Dunmarrow Barrow", "kind": "dungeon", "region": "sethmarch", "at": (38, 258),
     "text": "The family barrow of House Dunmarrow, sealed since Lord Edmer's death. The door has a hollow shaped like a signet.",
     "enter_requires": ["item:dunmarrow_signet"],
     "enter_hint": "The barrow door is sealed. Its lock is shaped like the Dunmarrow signet."},
    {"id": "sethorn_landing", "name": "Sethorn Landing", "kind": "port", "region": "sethmarch", "at": (72, 292), "dock": True,
     "text": "A fishing landing below the keep. Boats rot on the shingle; the gulls do not mind."},
    {"id": "flame_sethorn", "name": "Flame of Dunmarrow", "kind": "beacon", "region": "sethmarch", "at": (104, 286), "fast": True,
     "flame": "flame_sethorn",
     "text": "The first of the Seven Flames: the Dunmarrow brazier, cold since the family fell."},
    # ---- Orrowen Weald (south) ------------------------------------------------------------------------------------
    {"id": "greenmoot", "name": "Greenmoot", "kind": "village", "region": "orrowen", "at": (96, 190),
     "text": "Orrowen's meeting-ground. Yeomen settle disputes here under an ancient oak, and nobody lies beneath it."},
    {"id": "orrowen_hall", "name": "Orrowen Hall", "kind": "town", "region": "orrowen", "at": (62, 166), "fast": True,
     "text": "The long timber hall of House Orrowen, ringed by archery butts and orchards."},
    {"id": "fletchers_hollow", "name": "Fletcher's Hollow", "kind": "hamlet", "region": "orrowen", "at": (122, 172),
     "text": "Arrow-makers live here. The whole hamlet smells of pine pitch and goose feathers."},
    {"id": "ashford", "name": "Ashford", "kind": "village", "region": "orrowen", "at": (96, 148),
     "text": "A river village that lost its bridge in the spring floods. The planks lie in the shallows like fallen teeth."},
    {"id": "flame_orrowen", "name": "Flame of the Weald", "kind": "beacon", "region": "orrowen", "at": (40, 190), "fast": True,
     "flame": "flame_orrowen", "text": "A brazier carved in the shape of an oak, cold and moss-grown."},
    # ---- Orrowen Highwood (north) ---------------------------------------------------------------------------------
    {"id": "highmoot", "name": "Highmoot", "kind": "village", "region": "highwood", "at": (100, 128),
     "text": "A timber village at the edge of the high forest. Strangers are fed first, questioned second."},
    {"id": "bowyers_rest", "name": "Bowyer's Rest", "kind": "hamlet", "region": "highwood", "at": (58, 116),
     "text": "Hunters' cabins around a smoking pit. They sell yew staves to anyone who can draw them."},
    {"id": "barrow_oak", "name": "Hollow Oak Barrow", "kind": "dungeon", "region": "highwood", "at": (140, 120),
     "text": "A barrow grown through with the roots of a gigantic oak. Moss-hunters say a lamp burns in it at night."},
    # ---- Quillon Heights ------------------------------------------------------------------------------------------
    {"id": "scriptorium", "name": "Inkwell", "kind": "village", "region": "quillon", "at": (104, 86),
     "text": "A village of scribes and book-binders below the tower. Even the signposts are footnoted."},
    {"id": "quillon_tower", "name": "Quillon Tower", "kind": "city", "region": "quillon", "at": (84, 52), "fast": True,
     "text": "The tower-city of House Quillon: spiral streets, star-charts on every wall and wards on every door."},
    {"id": "undercroft", "name": "Quillon Undercroft", "kind": "dungeon", "region": "quillon", "at": (128, 50),
     "text": "The sealed vaults under the tower, where the house keeps what it will not teach."},
    {"id": "flame_quillon", "name": "Flame of the Tower", "kind": "beacon", "region": "quillon", "at": (50, 80), "fast": True,
     "flame": "flame_quillon", "text": "A violet flame-bowl on a stone pillar, scratched with tiny star-charts."},
    # ---- Ashen Fens -----------------------------------------------------------------------------------------------
    {"id": "mirewatch", "name": "Mirewatch", "kind": "village", "region": "fens", "at": (176, 252),
     "text": "A village on stilts. Planks link the huts; step off them and the fen takes your boot."},
    {"id": "brackwater", "name": "Brackwater", "kind": "town", "region": "fens", "at": (222, 270), "fast": True,
     "text": "The only dry town in the fens, built on a gravel spit. Pilgrims, peat-cutters and smugglers share its inns."},
    {"id": "sunken_chapel", "name": "Sunken Chapel", "kind": "dungeon", "region": "fens", "at": (236, 304),
     "text": "A drowned chapel whose bell still tolls on windless nights. Pilgrims go in with a lamp; fewer come out."},
    {"id": "fen_camp", "name": "Bogwater Camp", "kind": "camp", "region": "fens", "at": (192, 296),
     "text": "Cutthroats hide their plunder on a reed island in the fen.",
     "actions": [{"label": "Raid the camp", "requires": ["!fen_camp_cleared"], "battle": "bogwater_gang",
                  "on_win": {"set": ["fen_camp_cleared"], "gold": 120}}],
     "done_text": "The reed island is empty and the cooking fires are cold.", "done_if": ["fen_camp_cleared"]},
    {"id": "tollhouse", "name": "Brine Tollhouse", "kind": "fort", "region": "fens", "at": (276, 272), "fast": False,
     "text": "A squat stone fort across the coast road. Ysmark's tax-men collect here, and the bar does not rise for free."},
    # ---- Ysmark Coast ---------------------------------------------------------------------------------------------
    {"id": "saltcote", "name": "Saltcote", "kind": "port", "region": "ysmark", "at": (318, 262), "dock": True,
     "text": "Salt-pans and a small quay. Ysmark's first harbour for travellers from the fens."},
    {"id": "brinegate", "name": "Brinegate", "kind": "city", "region": "ysmark", "at": (376, 284), "dock": True, "fast": True,
     "text": "The silver-scale city of House Ysmark: ledgers, quays and crossbows for hire."},
    {"id": "smugglers_cove", "name": "Redsalt Cove", "kind": "dungeon", "region": "ysmark", "at": (396, 262),
     "text": "A sea-cave where Captain Redsalt's smugglers land cargo the harbour office never sees."},
    {"id": "flame_ysmark", "name": "Flame of the Quay", "kind": "beacon", "region": "ysmark", "at": (338, 286), "fast": True,
     "flame": "flame_ysmark", "text": "A brazier in the shape of a scale-pan, blackened by salt spray."},
    # ---- Vessmoor Plains ------------------------------------------------------------------------------------------
    {"id": "cindermead", "name": "Cindermead", "kind": "town", "region": "vessmoor", "at": (352, 214), "fast": True,
     "text": "The red-horse town of House Vessmoor. Duels, horse fairs and a great deal of dust."},
    {"id": "redfield", "name": "Redfield", "kind": "village", "region": "vessmoor", "at": (390, 180),
     "text": "A horse-breeders' village on the open plain. Wind never stops here."},
    {"id": "duelling_green", "name": "The Duelling Green", "kind": "shrine", "region": "vessmoor", "at": (330, 238),
     "text": "A ring of trampled turf and a champion's bench. Vessmoor settles insults here.",
     "actions": [{"label": "Challenge the champion", "requires": ["!duel_won"], "battle": "duel_alaric",
                  "on_win": {"set": ["duel_won"], "gold": 150}}],
     "done_text": "Ser Alaric salutes you from the bench. The Green is yours to cross.", "done_if": ["duel_won"]},
    {"id": "steppe_camp", "name": "Redhand Camp", "kind": "camp", "region": "vessmoor", "at": (384, 146),
     "text": "Steppe raiders under Karga Redhand prey on Brennhallow's supply wagons from this camp.",
     "actions": [{"label": "Attack the camp", "requires": ["!caravan_safe"], "battle": "steppe_raiders",
                  "on_win": {"set": ["caravan_safe"], "gold": 140}}],
     "done_text": "The tents are torn down. The wagons can pass.", "done_if": ["caravan_safe"]},
    {"id": "flame_vessmoor", "name": "Flame of the Plains", "kind": "beacon", "region": "vessmoor", "at": (320, 190), "fast": True,
     "flame": "flame_vessmoor", "text": "A brazier shaped like a rearing horse, the paint chipped by hoof-thrown stones."},
    # ---- Brennhallow Highlands ------------------------------------------------------------------------------------
    {"id": "ironhold", "name": "Ironhold", "kind": "village", "region": "brennhallow", "at": (350, 118),
     "text": "A garrison village at the foot of the pass. Everyone here has served, or will."},
    {"id": "brennhold", "name": "Brennhold", "kind": "city", "region": "brennhallow", "at": (330, 74), "fast": True,
     "text": "The iron-tower fortress of House Brennhallow, seat of the Lord Regent's power."},
    {"id": "brennhold_vault", "name": "Regent's Vault", "kind": "dungeon", "region": "brennhallow", "at": (300, 56),
     "text": "The sealed armoury beneath the old keep, where the Regent stores the seal of Brennhold."},
    {"id": "flame_brennhallow", "name": "Flame of the Marches", "kind": "beacon", "region": "brennhallow", "at": (310, 96), "fast": True,
     "flame": "flame_brennhallow", "text": "An iron cresset on a watch-hill, kept lit by a bored sentry."},
    # ---- Frostfang Peaks ------------------------------------------------------------------------------------------
    {"id": "winterwatch", "name": "Winterwatch", "kind": "fort", "region": "frostfang", "at": (392, 60), "fast": True,
     "text": "A snowbound garrison at the end of the world, held by volunteers and the very stubborn."},
    {"id": "rime_hollow", "name": "Rime Hollow", "kind": "hamlet", "region": "frostfang", "at": (410, 90),
     "text": "Trappers' huts under a frozen overhang. They trade pelts and ghost stories."},
    {"id": "frostfang_cairn", "name": "Frostfang Cairn", "kind": "dungeon", "region": "frostfang", "at": (370, 36),
     "text": "A burial cairn older than the Covenant. Something in it still keeps watch."},
    # ---- Tarnholt Cloisters ---------------------------------------------------------------------------------------
    {"id": "pilgrims_rest", "name": "Pilgrim's Rest", "kind": "village", "region": "tarnholt", "at": (222, 202),
     "text": "A hostel village at the first steps of the pilgrim road. Bells ring the hours from every direction."},
    {"id": "tarnholt_cloister", "name": "St. Wyn's Cloister", "kind": "monastery", "region": "tarnholt", "at": (240, 160), "fast": True,
     "text": "The white-flame cloister of House Tarnholt: cloisters, infirmaries and a very large library of relics."},
    {"id": "reliquary", "name": "Reliquary Crypt", "kind": "dungeon", "region": "tarnholt", "at": (270, 190),
     "text": "The crypt beneath the cloister where relics too dangerous to show are kept."},
    {"id": "flame_tarnholt", "name": "Flame of the Cloisters", "kind": "beacon", "region": "tarnholt", "at": (214, 168), "fast": True,
     "flame": "flame_tarnholt", "text": "A white-stone brazier in a hillside shrine. The pilgrims keep it swept."},
    # ---- Aurelmont Reach ------------------------------------------------------------------------------------------
    {"id": "goldfield", "name": "Goldfield", "kind": "village", "region": "aurelmont", "at": (238, 100),
     "text": "Crown farmland, harvested by people who do not look up when soldiers pass."},
    {"id": "aurelmont_city", "name": "Aurelmont", "kind": "city", "region": "aurelmont", "at": (246, 66), "fast": True,
     "text": "The capital of Eldrimar. Golden roofs, grey faces, and a throne with no one on it."},
    {"id": "kaer_aurel", "name": "Palace of Kaer Aurel", "kind": "dungeon", "region": "aurelmont", "at": (270, 40),
     "text": "The royal palace. Somewhere inside, the Hidden Codicil is waiting for someone to read it."},
    # ---- The Cinder Isles (ship only) -----------------------------------------------------------------------------
    {"id": "embercay", "name": "Embercay", "kind": "dungeon", "region": "isles", "at": (205, 322), "dock": True,
     "text": "A black island that still smokes. Smugglers say the old Flame-keepers buried their treasure here."},
    {"id": "gull_rock", "name": "Gull Rock", "kind": "hamlet", "region": "isles", "at": (60, 324), "dock": True,
     "text": "A hermit's rock with one house, one dog and a great many opinions."},
]

# Quests shown in the journal. A quest appears once `show` is satisfied; the first step whose flag is unset is the objective.
QUESTS = [
    {"id": "q_camp", "name": "Break the Roadwolves", "region": "sethmarch", "show": [],
     "summary": "Hask Gravelteeth's raiders hold the road east of Sallow Crossing.",
     "steps": [{"flag": "camp_cleared", "text": "Defeat Hask Gravelteeth at the Roadwolf Camp."}]},
    {"id": "q_barrow", "name": "The Barrow Door", "region": "sethmarch", "show": ["seen_barrow"],
     "summary": "Edmer Dunmarrow's barrow still answers to the family signet.",
     "steps": [{"flag": "barrow_cleared", "text": "Open Dunmarrow Barrow with the signet and face its warden."}]},
    {"id": "q_bridge", "name": "The Broken Bridge", "region": "orrowen", "show": ["seen_ashford"],
     "summary": "Ashford's bridge fell in the spring floods. The Highwood lies beyond it.",
     "steps": [{"flag": "bridge_mended", "text": "Pay Carpenter Dunstan 100 gold for timber."}]},
    {"id": "q_satchel", "name": "The Apprentice's Satchel", "region": "highwood", "show": ["q_satchel"],
     "summary": "A Quillon scholar needs his apprentice's satchel. It holds the writ that opens Quillon's gate.",
     "steps": [{"flag": "satchel_found", "text": "Find Pell's satchel in Hollow Oak Barrow."},
               {"flag": "quillon_writ", "text": "Bring the satchel to Scholar Edrin in Highmoot."}]},
    {"id": "q_toll", "name": "Toll of the Brine", "region": "fens", "show": ["seen_tollhouse"],
     "summary": "Ysmark taxes the coast road.",
     "steps": [{"flag": "ysmark_toll", "text": "Pay the 150 gold toll at the Brine Tollhouse."}]},
    {"id": "q_lamp", "name": "The Penitent's Lamp", "region": "fens", "show": ["q_lamp"],
     "summary": "Friar Osk will vouch for pilgrims who bring back a token from the Sunken Chapel.",
     "steps": [{"flag": "pilgrim_token", "text": "Recover a pilgrim's token from the Sunken Chapel."}]},
    {"id": "q_ship", "name": "Salt and Smugglers", "region": "ysmark", "show": ["q_ship"],
     "summary": "The harbourmaster will lend you a ship if Redsalt's smugglers are broken.",
     "steps": [{"flag": "smugglers_broken", "text": "Defeat Captain Redsalt in Redsalt Cove."},
               {"flag": "has_ship", "text": "Report to Harbourmaster Corvin Salt in Brinegate."}]},
    {"id": "q_horse", "name": "A Horse of Vessmoor", "region": "vessmoor", "show": ["q_horse"],
     "summary": "A Vessmoor warhorse is fast and hard to ambush. You may buy one or win one.",
     "steps": [{"flag": "has_horse", "text": "Buy a warhorse at Cindermead's stables (800 gold), or win the duel at the Green."}]},
    {"id": "q_courier", "name": "The Regent's Courier", "region": "vessmoor", "show": ["q_courier"],
     "summary": "Brennhallow's envoy wants his supply wagons safe before he issues a writ.",
     "steps": [{"flag": "caravan_safe", "text": "Break Karga Redhand's camp."},
               {"flag": "brennhallow_writ", "text": "Collect the writ from the Brennhallow envoy in Cindermead."}]},
    {"id": "q_charm", "name": "Ember for the Cold", "region": "tarnholt", "show": ["q_charm"],
     "summary": "The hearth-keeper of St. Wyn's can forge a charm against the blizzard.",
     "steps": [{"flag": "flame_tarnholt", "text": "Kindle the Flame of the Cloisters."},
               {"flag": "frost_charm", "text": "Return to the hearth-keeper at St. Wyn's Cloister."}]},
    {"id": "q_seals", "name": "The Three Seals", "region": "aurelmont", "show": ["seen_goldfield"],
     "summary": "The Great Gate of Aurelmont answers only to Quillon, Tarnholt and Brennhold together.",
     "steps": [{"flag": "seal_quillon", "text": "Win Quillon's seal in the Undercroft."},
               {"flag": "seal_tarnholt", "text": "Win Tarnholt's seal in the Reliquary Crypt."},
               {"flag": "seal_brennhold", "text": "Win Brennhold's seal in the Regent's Vault."}]},
    {"id": "q_flames", "name": "The Seven Flames", "region": "eldrimar", "show": ["flame_any"],
     "summary": "Seven houses, seven beacons. Rekindle them all and tell Steward Brannoch.",
     "steps": [{"flag": "flame_sethorn", "text": "Flame of Dunmarrow (Sethmarch)."},
               {"flag": "flame_orrowen", "text": "Flame of the Weald (Orrowen)."},
               {"flag": "flame_ysmark", "text": "Flame of the Quay (Ysmark)."},
               {"flag": "flame_vessmoor", "text": "Flame of the Plains (Vessmoor)."},
               {"flag": "flame_quillon", "text": "Flame of the Tower (Quillon)."},
               {"flag": "flame_tarnholt", "text": "Flame of the Cloisters (Tarnholt)."},
               {"flag": "flame_brennhallow", "text": "Flame of the Marches (Brennhallow)."},
               {"flag": "seven_flames", "text": "Report the Seven Flames to Steward Brannoch at Kaer Sethorn."}]},
    {"id": "q_ember", "name": "Ashes on Embercay", "region": "isles", "show": ["seen_embercay"],
     "summary": "The old Flame-keepers buried something on a black island.",
     "steps": [{"flag": "embercay_cleared", "text": "Cross the Brinesea by ship and clear the Ember Vault."}]},
    {"id": "q_cairn", "name": "Winter's Heart", "region": "frostfang", "show": ["seen_frostfang_cairn"],
     "summary": "A watcher sleeps in Frostfang Cairn.",
     "steps": [{"flag": "frost_cairn_cleared", "text": "Defeat the Rimebound Jarl."}]},
]

# Transport modes. blocked = terrain names the mode cannot enter. water_only modes sail on the open sea only.
TRANSPORTS = {
    "foot": {"name": "On foot", "speed": 1.0, "danger": 1.0, "requires": ""},
    "horse": {"name": "Mounted", "speed": 1.55, "danger": 0.55, "requires": "has_horse",
              "blocked": ["Forest", "Swamp"]},
    "ship": {"name": "Sailing", "speed": 1.35, "danger": 0.6, "requires": "has_ship", "water_only": True},
}
