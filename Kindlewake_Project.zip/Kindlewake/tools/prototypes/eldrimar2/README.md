# Eldrimar v2 world prototype (REFERENCE ONLY, not used by the game)

An alternative 13-region continent design with **sealed borders and 8 quest gates**, written in the v0.7.3-line chat before the v0.7.1 project arrived.
It is kept because it already proves the hard parts offline (run it and read the checks):

    python3 -I tools/prototypes/eldrimar2/gen_world.py      # needs numpy + Pillow; writes only into build/eldrimar2/

* `world_design.py`: regions, Voronoi seeds, which borders are open / river / mountain, rivers, lakes, 50 places, 8 gates
  (`requires` = flags, `!flag`, `item:id`), road list with gate passes, 14 quests (flag steps), transports (foot, horse, ship).
* `gen_world.py`: land mask, regions, biomes, **barrier bands along every sealed border**, rivers, snapped places, A* roads that
  pierce a band only at the listed gate pass, then VERIFIES: every gate seals its border, every place is reachable with all
  gates open, only the free regions are reachable with all gates shut, the ship's sea connects all docks.
* `preview.png`: what it produces (452 x 340).

The live game uses `tools/make_world.py` (8 regions). The plan to bring the same gate idea to the live world is
`docs/features/story_gates.md`; reuse `build_barriers`, `astar`, `flood` and the checks from here.
