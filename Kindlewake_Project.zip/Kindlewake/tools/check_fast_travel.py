#!/usr/bin/env python3
"""Offline check of the waystone fast-travel rules (feature fast_travel). Needs NO Godot and NO packages.

    python3 -I tools/check_fast_travel.py            # from the project folder (exit code 0 = all good)
    python3 -I tools/check_fast_travel.py --table    # also print the price from every settlement to every other

What it proves (it mirrors scripts/world/fast_travel.gd and the gate overlay of scripts/world/world_map.gd in Python):
  * data/travel.json is complete and sane (numbers, kinds, texts, origin_radius == world safe_radius);
  * with every gate shut, a walker starting at Kaer Sethorn can reach on foot exactly the settlements of the free regions;
  * opening gates one by one makes exactly the settlements of the newly joined region reachable;
  * with every gate open, all settlements are reachable;
  * prices are multiples of 5 inside [min_gold, max_gold], symmetric, and grow with distance.
It cannot see engine mistakes: the GDScript twin of these checks is _test_fast_travel() in tests/run_tests.gd.
"""
import base64
import json
import math
import pathlib
import sys
from collections import deque

ROOT = pathlib.Path(__file__).resolve().parent.parent
SPEED = [1.0, 0.6, 0.7, 0.5, 0.0, 0.0, 1.4, 1.2, 0.9, 0.75, 0.55]
ROAD = 6
MOUNTAIN = 5
failures = []
checks = 0


def check(cond, label):
    global checks
    checks += 1
    if not cond:
        failures.append(label)
        print("  FAIL  " + label)


def load(rel):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def cost_for(a, b, cfg):
    tiles = math.hypot(b[0] - a[0], b[1] - a[1])
    raw = tiles / 10.0 * float(cfg.get("gold_per_10_tiles", 3))
    gold = int(math.floor(raw / 5.0 + 0.5)) * 5          # GDScript roundf: half away from zero (values are >= 0)
    return max(int(cfg.get("min_gold", 10)), min(int(cfg.get("max_gold", 120)), gold))


class Live:
    """The overworld with the quest gates in a given state (mirror of WorldMap.configure_story_gates / _apply_story_overlay)."""

    def __init__(self, world, raw, gates):
        self.w = int(raw["width"])
        self.h = int(raw["height"])
        self.base = bytearray(base64.b64decode(raw["tiles_b64"]))
        self.regions = bytearray(base64.b64decode(raw["regions_b64"]))
        self.rids = {r["id"]: i for i, r in enumerate(world["regions"])}
        self.gates = gates["gates"]
        self.band = set()
        for y, x0, x1 in gates["bands"]:
            for x in range(x0, x1 + 1):
                self.band.add((x, y))
        self.cells = {}                               # (x, y) -> gate id
        for g in self.gates:
            for x, y in g["cells"]:
                self.cells[(x, y)] = g["id"]
            for c in self.corridor(g):
                self.cells[c] = g["id"]

    def adjacent_to(self, cell, ridx):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (cell[0] + dx, cell[1] + dy)
            if 0 <= n[0] < self.w and 0 <= n[1] < self.h and n not in self.band:
                i = n[1] * self.w + n[0]
                if self.regions[i] == ridx and SPEED[self.base[i]] > 0.0:
                    return True
        return False

    def corridor(self, g):
        ra, rb = self.rids[g["between"][0]], self.rids[g["between"][1]]
        starts = sorted((c for c in self.band if self.adjacent_to(c, ra)), key=lambda c: c[1] * self.w + c[0])
        prev = {c: None for c in starts}
        queue = deque(starts)
        finish = None
        while queue:
            c = queue.popleft()
            if self.adjacent_to(c, rb):
                finish = c
                break
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (c[0] + dx, c[1] + dy)
                if n in self.band and n not in prev:
                    prev[n] = c
                    queue.append(n)
        path = []
        while finish is not None:
            path.append(finish)
            finish = prev[finish]
        return path

    def tiles_for(self, open_gates):
        t = bytearray(self.base)
        for x, y in self.band:
            t[y * self.w + x] = MOUNTAIN
        for (x, y), gid in self.cells.items():
            if gid in open_gates:
                orig = self.base[y * self.w + x]
                t[y * self.w + x] = orig if SPEED[orig] > 0.0 else ROAD
        return t

    def flood(self, tiles, start):
        w, h = self.w, self.h
        seen = bytearray(w * h)
        if SPEED[tiles[start[1] * w + start[0]]] <= 0.0:
            return seen
        first = start[1] * w + start[0]
        seen[first] = 1
        queue = deque([first])
        while queue:
            i = queue.popleft()
            x = i % w
            for n, ok in ((i - 1, x > 0), (i + 1, x < w - 1), (i - w, i - w >= 0), (i + w, i + w < w * h)):
                if ok and not seen[n] and SPEED[tiles[n]] > 0.0:
                    seen[n] = 1
                    queue.append(n)
        return seen


def main():
    table = "--table" in sys.argv
    cfg = load("data/travel.json")
    world = load("data/world.json")
    raw = load("data/world_map.json")
    gates = load("data/world_gates.json")

    print("[travel.json]")
    kinds = set(p["kind"] for p in world["places"])
    check(bool(cfg.get("enabled", False)), "fast travel is enabled")
    check(0 < int(cfg["gold_per_10_tiles"]) <= 20, "gold_per_10_tiles is between 1 and 20")
    check(0 < int(cfg["min_gold"]) <= int(cfg["max_gold"]) <= 500, "min_gold <= max_gold <= 500")
    check(set(cfg["kinds"]) <= kinds and "village" in cfg["kinds"], "kinds are real place kinds")
    check(int(cfg["origin_radius"]) == int(world["safe_radius"]), "origin_radius equals the world's safe_radius (%d)" % int(world["safe_radius"]))
    for key in ("intro", "need_stone", "arrive", "cut_off", "too_poor", "here"):
        check(isinstance(cfg.get(key), str) and cfg[key] != "", "text '%s' exists" % key)
    check("%s" in cfg["arrive"], "the arrive text has a %s for the town name")

    settlements = [p for p in world["places"] if p["kind"] in cfg["kinds"]]
    print("[prices: %d settlements]" % len(settlements))
    costs = {}
    bad_mult, bad_range, bad_sym = [], [], []
    for a in settlements:
        for b in settlements:
            if a is b:
                continue
            c = cost_for(a["cell"], b["cell"], cfg)
            costs[(a["id"], b["id"])] = c
            if c % 5 != 0 and c not in (cfg["min_gold"], cfg["max_gold"]):
                bad_mult.append((a["id"], b["id"], c))
            if not (cfg["min_gold"] <= c <= cfg["max_gold"]):
                bad_range.append((a["id"], b["id"], c))
    for (x, y), c in costs.items():
        if costs[(y, x)] != c:
            bad_sym.append((x, y))
    check(not bad_mult, "every price is a multiple of 5 (or a clamp value)")
    check(not bad_range, "every price is inside [min_gold, max_gold]")
    check(not bad_sym, "the price A to B equals B to A")
    sethorn = next(p for p in settlements if p["id"] == "sethorn")
    near = min((p for p in settlements if p is not sethorn), key=lambda p: math.hypot(p["cell"][0] - sethorn["cell"][0], p["cell"][1] - sethorn["cell"][1]))
    far = max((p for p in settlements if p is not sethorn), key=lambda p: math.hypot(p["cell"][0] - sethorn["cell"][0], p["cell"][1] - sethorn["cell"][1]))
    check(costs[("sethorn", near["id"])] <= costs[("sethorn", far["id"])], "a nearer town never costs more than a farther one (%s %dg, %s %dg)" % (near["id"], costs[("sethorn", near["id"])], far["id"], costs[("sethorn", far["id"])]))
    start_gold = int(load("data/campaign_start.json").get("gold", 0))
    check(costs[("sethorn", near["id"])] <= start_gold, "the first trip is affordable with the starting %d gold" % start_gold)
    if table:
        for a in settlements:
            print("  %-14s" % a["id"] + " ".join("%4d" % costs[(a["id"], b["id"])] if a is not b else "   -" for b in settlements))

    print("[reachability with the quest gates]")
    live = Live(world, raw, gates)
    start = tuple(next(p for p in world["places"] if p["id"] == world["start"])["cell"])
    region_of = {p["id"]: p["region"] for p in settlements}
    gate_ids = [g["id"] for g in gates["gates"]]
    free = {"sethmarch", "orrowen"}

    def reach(open_gates):
        tiles = live.tiles_for(open_gates)
        seen = live.flood(tiles, start)
        got = set()
        for p in settlements:
            x, y = p["cell"]
            if seen[y * live.w + x]:
                got.add(p["id"])
        return got

    def expected(open_gates):
        regs = set(free)
        changed = True
        while changed:
            changed = False
            for g in gates["gates"]:
                if g["id"] in open_gates:
                    a, b = g["between"]
                    if (a in regs) != (b in regs):
                        regs |= {a, b}
                        changed = True
        return set(pid for pid, r in region_of.items() if r in regs)

    shut = reach(set())
    check(shut == expected(set()) and len(shut) > 0, "all gates shut: only the free regions are reachable (%d settlements)" % len(shut))
    check(all(region_of[i] in free for i in shut), "all gates shut: nothing outside Sethmarch and Orrowen is reachable")
    opened = set()
    for gid in gate_ids:
        # open the gates in ladder order of the data, but only one that touches the reachable area makes a difference
        opened.add(gid)
        got, want = reach(opened), expected(opened)
        check(got == want, "gates open %s: flood fill equals the region graph (%d settlements)" % (sorted(opened), len(got)))
    all_open = reach(set(gate_ids))
    check(len(all_open) == len(settlements), "all gates open: all %d settlements are reachable (%d)" % (len(settlements), len(all_open)))
    # one gate open at a time, from the full-closed state: never reaches a region it does not border
    for g in gates["gates"]:
        got = reach({g["id"]})
        want = expected({g["id"]})
        check(got == want, "only %s open: reach equals the region graph" % g["id"])
    tiles_shut = live.tiles_for(set())
    check(all(SPEED[tiles_shut[p["cell"][1] * live.w + p["cell"][0]]] > 0.0 for p in settlements), "every settlement stands on walkable ground even with all gates shut")

    print("")
    print("Checks: %d   Failures: %d" % (checks, len(failures)))
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
