#!/usr/bin/env python3
"""Kindlewake content generator (v0.7.0): more weapons, armour, shops and enemies, all as plain JSON data.

Adds to data/weapons.json, data/items.json, data/characters.json, data/encounters.json and rewrites data/shops.json.
Existing hand-written entries are never changed; only ids defined below are (re)written, so you can edit the numbers
here and re-run. Order of the generators:  make_world.py (places) -> make_content.py (shops need the place list).
Run:  python3 tools/make_content.py
"""
import json
import os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
D = lambda name: os.path.join(ROOT, "data", name)


def load(name):
    with open(D(name)) as f:
        return json.load(f)


def dump_lines(name, data, line_keys):
    """Writes JSON with one entry per line for the dictionaries listed in line_keys (keeps the files readable)."""
    parts = []
    for k, v in data.items():
        if k in line_keys and isinstance(v, dict):
            rows = ",\n".join("    %s: %s" % (json.dumps(i), json.dumps(e, ensure_ascii=False)) for i, e in v.items())
            parts.append('  %s: {\n%s\n  }' % (json.dumps(k), rows))
        else:
            parts.append("  %s: %s" % (json.dumps(k), json.dumps(v, ensure_ascii=False)))
    with open(D(name), "w") as f:
        f.write("{\n" + ",\n".join(parts) + "\n}\n")


# ------------------------------------------------------------------ weapons: id -> (weapon def, item def, tier, regions)
def W(name, wtype, power, rmin=1, rmax=1, acc=0, crit=0, ranged=False, dex=False):
    d = {"name": name, "type": wtype, "damage_type": "physical", "power": power, "range_min": rmin, "range_max": rmax,
         "ranged": ranged, "acc": acc, "crit": crit}
    if dex:
        d["uses_dex"] = True
    return d


def WI(name, wid, sockets, links, ap, rarity, price, two=False, bonus=None):
    d = {"name": name, "slot": "weapon", "sockets": sockets, "links": links, "ap_mult": ap, "rarity": rarity,
         "weapon_id": wid, "price": price}
    if two:
        d["two_handed"] = True
    if bonus:
        d["bonus"] = bonus
    return d


WEAPONS = {
    #  id: (weapon, item, tier, where)
    "dirk": (W("Alley Dirk", "dagger", 4, acc=8, crit=8), WI("Alley Dirk", "dirk", 1, [], 1, "common", 35), 1, "*"),
    "spear": (W("Hedgerow Spear", "spear", 7, acc=2), WI("Hedgerow Spear", "spear", 2, [], 1, "common", 75), 1, "*"),
    "ash_staff": (W("Ash Staff", "staff", 3), WI("Ash Staff", "ash_staff", 1, [], 1, "common", 55, bonus={"int": 2}), 1, "*"),
    "crossbow": (W("Winch Crossbow", "crossbow", 9, 2, 5, acc=-2, crit=3, ranged=True, dex=True), WI("Winch Crossbow", "crossbow", 2, [[0, 1]], 1, "common", 150), 2, "*"),
    "war_hammer": (W("Parish Hammer", "mace", 8, crit=1), WI("Parish Hammer", "war_hammer", 2, [], 1, "common", 115), 2, ["tarnholt", "aurelmont", "brennhallow", "ysmark"]),
    "falchion": (W("Cindermead Falchion", "sword", 9, acc=4, crit=4), WI("Cindermead Falchion", "falchion", 2, [[0, 1]], 1, "common", 185), 2, ["vessmoor", "aurelmont", "ysmark"]),
    "bearded_axe": (W("Brennhold Axe", "axe", 10, acc=-1, crit=6), WI("Brennhold Axe", "bearded_axe", 2, [[0, 1]], 1, "common", 200), 3, ["brennhallow", "orrowen", "aurelmont"]),
    "longbow": (W("Greenwood Longbow", "bow", 9, 2, 5, acc=2, crit=5, ranged=True, dex=True), WI("Greenwood Longbow", "longbow", 3, [[0, 1]], 2, "fine", 210), 3, ["orrowen", "aurelmont", "quillon"]),
    "bastard_sword": (W("Roan Bastard Blade", "sword", 11, acc=4, crit=4), WI("Roan Bastard Blade", "bastard_sword", 3, [[0, 1]], 2, "fine", 270), 3, "*"),
    "lance": (W("Outrider Lance", "spear", 11, acc=0, crit=3), WI("Outrider Lance", "lance", 3, [[0, 1]], 2, "fine", 290), 3, ["vessmoor", "aurelmont", "brennhallow"]),
    "yew_staff": (W("Yewheart Staff", "staff", 4), WI("Yewheart Staff", "yew_staff", 2, [[0, 1]], 2, "fine", 230, bonus={"int": 4}), 3, ["quillon", "tarnholt", "aurelmont"]),
    "stiletto": (W("Stiletto", "dagger", 8, acc=10, crit=10), WI("Stiletto", "stiletto", 2, [], 1, "fine", 220), 3, ["ysmark", "aurelmont", "quillon"]),
    "heavy_crossbow": (W("Ironwinch", "crossbow", 12, 2, 5, acc=-4, crit=4, ranged=True, dex=True), WI("Ironwinch", "heavy_crossbow", 3, [[0, 1]], 2, "fine", 330), 4, ["brennhallow", "ysmark", "tarnholt", "aurelmont"]),
    "war_pick": (W("Crowbeak", "mace", 12, acc=-2, crit=6), WI("Crowbeak", "war_pick", 3, [[0, 1]], 2, "fine", 350), 4, ["brennhallow", "tarnholt", "vessmoor"]),
    "runed_blade": (W("Runed Spellblade", "sword", 13, acc=6, crit=5), WI("Runed Spellblade", "runed_blade", 3, [[0, 1]], 2, "fine", 430, bonus={"int": 2}), 4, ["quillon", "tarnholt"]),
    "halberd": (W("Wardens' Halberd", "spear", 13, acc=-1, crit=4), WI("Wardens' Halberd", "halberd", 3, [[0, 1]], 2, "fine", 410), 4, ["brennhallow", "aurelmont", "tarnholt"]),
    "ironwood_bow": (W("Ironwood Bow", "bow", 12, 2, 5, acc=3, crit=6, ranged=True, dex=True), WI("Ironwood Bow", "ironwood_bow", 4, [[0, 1], [2, 3]], 3, "masterwork", 520), 4, ["orrowen", "quillon", "brennhallow"]),
    "star_staff": (W("Starglass Staff", "staff", 5), WI("Starglass Staff", "star_staff", 3, [[0, 1]], 2, "fine", 420, bonus={"int": 6}), 4, ["quillon", "tarnholt"]),
    "oathkeeper": (W("Oathkeeper", "sword", 15, acc=6, crit=6), WI("Oathkeeper", "oathkeeper", 4, [[0, 1], [2, 3]], 3, "masterwork", 820), 5, ["brennhallow", "aurelmont"]),
    "regent_crossbow": (W("Regent's Bolt-Thrower", "crossbow", 14, 2, 5, acc=-2, crit=6, ranged=True, dex=True), WI("Regent's Bolt-Thrower", "regent_crossbow", 4, [[0, 1], [2, 3]], 3, "masterwork", 780), 5, ["brennhallow", "aurelmont"]),
}


# ------------------------------------------------------------------ armour, helms, shields, accessories
def A(name, slot, df, res=0, sockets=0, links=None, ap=1, rarity="common", price=50, bonus=None):
    d = {"name": name, "slot": slot, "rarity": rarity, "price": price}
    if df:
        d["armor_def"] = df
    if res:
        d["armor_res"] = res
    if slot == "armor":
        d.update({"sockets": sockets, "links": links or [], "ap_mult": ap})
    if bonus:
        d["bonus"] = bonus
    return d


GEAR = {
    # armour
    "brigandine": (A("Rivet Brigandine", "armor", 5, 0, 2, [], 1, "common", 115), 2, "*"),
    "scale_coat": (A("Scalewrought Coat", "armor", 6, 1, 2, [[0, 1]], 1, "common", 170), 2, ["ysmark", "orrowen", "aurelmont"]),
    "chain_surcoat": (A("Chain Surcoat", "armor", 6, 2, 3, [[0, 1]], 2, "fine", 210), 3, ["aurelmont", "tarnholt", "brennhallow"]),
    "lamellar": (A("Steppe Lamellar", "armor", 7, 1, 3, [[0, 1]], 2, "fine", 250), 3, ["vessmoor", "aurelmont"]),
    "mage_robe": (A("Candlemage Robe", "armor", 3, 5, 3, [[0, 1]], 2, "fine", 230, {"int": 2}), 3, ["quillon", "tarnholt", "aurelmont"]),
    "scholar_robe": (A("Scholar's Warded Robe", "armor", 4, 7, 3, [[0, 1]], 3, "fine", 370, {"int": 3}), 4, ["quillon", "tarnholt"]),
    "plate_cuirass": (A("Greyiron Cuirass", "armor", 9, 2, 4, [[0, 1], [2, 3]], 3, "masterwork", 540, {"spd": -1}), 4, ["brennhallow", "aurelmont", "ysmark"]),
    "warden_coat": (A("Warden's Coat", "armor", 9, 4, 4, [[0, 1], [2, 3]], 3, "masterwork", 600), 4, ["brennhallow", "tarnholt"]),
    "regent_plate": (A("Regent's Plate", "armor", 11, 3, 4, [[0, 1], [2, 3]], 3, "masterwork", 820, {"spd": -2}), 5, ["brennhallow", "aurelmont"]),
    # helms
    "sallet": (A("Wolfjaw Sallet", "helm", 3, 0, price=95), 2, "*"),
    "circlet": (A("Scholar's Circlet", "helm", 1, 3, price=150, bonus={"int": 1}), 3, ["quillon", "tarnholt"]),
    "great_helm": (A("Crowned Great-Helm", "helm", 4, 1, price=170, bonus={"spd": -1}), 3, ["brennhallow", "aurelmont", "vessmoor"]),
    "warden_helm": (A("Warden's Helm", "helm", 5, 2, rarity="fine", price=310), 4, ["brennhallow", "tarnholt"]),
    # shields
    "heater_shield": (A("Banner Heater", "offhand", 4, 0, price=125), 2, "*"),
    "tower_shield": (A("Rampart Tower Shield", "offhand", 6, 0, price=240, bonus={"spd": -2}), 3, ["brennhallow", "aurelmont", "ysmark"]),
    "ward_shield": (A("Candle-Ward Shield", "offhand", 3, 3, rarity="fine", price=330), 4, ["tarnholt", "quillon"]),
    # accessories
    "iron_ring": (A("Dunmarrow Iron Ring", "accessory", 0, price=90, bonus={"vit": 2}), 1, "*"),
    "lucky_knot": (A("Weaver's Lucky Knot", "accessory", 0, price=110, bonus={"lck": 3}), 1, "*"),
    "wolf_fang": (A("Wolf-Fang Charm", "accessory", 0, price=160, bonus={"str": 2}), 2, ["sethmarch", "orrowen", "brennhallow"]),
    "swift_boots": (A("Courier's Boots", "accessory", 0, price=170, bonus={"spd": 2}), 2, "*"),
    "scholar_ring": (A("Inkwell Ring", "accessory", 0, price=200, bonus={"int": 3}), 3, ["quillon", "tarnholt"]),
    "banner_token": (A("Banner Token", "accessory", 0, price=240, bonus={"ldr": 3, "mor": 5}), 3, ["aurelmont", "vessmoor", "brennhallow"]),
    "keen_eye": (A("Hawkseye Lens", "accessory", 0, price=260, bonus={"acc": 4, "dex": 2}), 3, ["quillon", "orrowen", "ysmark"]),
    "iron_will": (A("Iron-Will Brooch", "accessory", 0, price=330, bonus={"vit": 3, "mor": 8}), 4, ["brennhallow", "tarnholt"]),
}

# sigils: id -> tier (data/sigils.json already defines them)
SIGIL_TIER = {"mend": 1, "ember": 1, "vigor": 1, "frost": 2, "amp": 2, "tutor": 2, "might": 2, "bulwark": 2, "fleet": 2,
              "veteran": 3, "coin_eye": 3}

# ------------------------------------------------------------------ enemies
TIER_STAT = {
    "hp": [28, 40, 52, 64, 76], "str": [9, 12, 15, 18, 21], "dex": [6, 8, 10, 12, 14], "vit": [6, 8, 10, 12, 14],
    "spd": [7, 8, 9, 10, 11], "acc": [78, 80, 82, 84, 86], "eva": [10, 12, 14, 16, 18], "df": [3, 5, 7, 9, 11],
    "res": [0, 1, 2, 3, 4], "lvl": [2, 5, 9, 14, 19], "mor": [50, 55, 60, 65, 70], "ldr": [4, 5, 6, 7, 8],
    "int": [4, 6, 8, 10, 12], "mp": [8, 12, 16, 22, 28],
    "exp": [45, 70, 100, 140, 190], "ap": [8, 12, 16, 20, 26], "gold": [22, 34, 52, 78, 110],
}
ARCH = {  # multipliers: hp, str, dex, vit, spd, eva, df, int
    "brute": (1.15, 1.10, 0.9, 1.0, 0.9, 0.9, 1.0, 1.0),
    "archer": (0.80, 0.60, 1.3, 0.8, 1.1, 1.3, 0.6, 1.0),
    "skirm": (0.75, 0.85, 1.3, 0.7, 1.4, 1.8, 0.6, 1.0),
    "guard": (1.25, 1.00, 0.8, 1.4, 0.7, 0.6, 1.4, 1.0),
    "rider": (1.00, 1.05, 1.0, 0.95, 1.3, 1.0, 0.9, 1.0),
    "caster": (0.70, 0.40, 1.0, 0.7, 1.0, 1.0, 0.5, 2.2),
    "healer": (0.80, 0.45, 0.9, 0.8, 0.9, 0.9, 0.6, 1.8),
}
ARCH_CLASS = {
    "brute": ["roadreaver", "swordsman", "berserker", "berserker", "berserker"],
    "archer": ["archer", "crossbowman", "longbow_master", "longbow_master", "sniper"],
    "skirm": ["thief", "thief", "assassin", "assassin", "assassin"],
    "guard": ["swordsman", "knight", "knight", "heavy_knight", "heavy_knight"],
    "rider": ["cavalier", "cavalier", "lancer", "lancer", "royal_cavalier"],
    "caster": ["apprentice_mage", "apprentice_mage", "fire_mage", "battle_mage", "battle_mage"],
    "healer": ["priest", "priest", "cleric", "cleric", "battle_medic"],
}
ARCH_WEAPON = {
    "brute": ["hand_axe", "falchion", "bearded_axe", "bastard_sword", "war_pick"],
    "archer": ["short_bow", "crossbow", "longbow", "heavy_crossbow", "ironwood_bow"],
    "skirm": ["dirk", "dirk", "stiletto", "stiletto", "stiletto"],
    "guard": ["arming_sword", "longsword", "bastard_sword", "runed_blade", "oathkeeper"],
    "rider": ["spear", "spear", "lance", "lance", "halberd"],
    "caster": ["ash_staff", "ash_staff", "yew_staff", "yew_staff", "star_staff"],
    "healer": ["mace", "war_hammer", "war_hammer", "war_pick", "war_pick"],
}
WEAPON_POWER = {}  # filled below for armour estimates

# id, display name, archetype, tier, extra
ENEMIES = [
    ("e_marsh_cutpurse", "Marsh Cutpurse", "skirm", 1, {}),
    ("e_mire_raider", "Mire Raider", "brute", 1, {}),
    ("e_green_poacher", "Greenhood Poacher", "archer", 2, {}),
    ("e_green_scout", "Greenhood Scout", "skirm", 2, {}),
    ("e_weald_brawler", "Weald Brawler", "brute", 2, {}),
    ("e_dock_cutthroat", "Harbour Cutthroat", "skirm", 2, {}),
    ("e_hired_crossbow", "Hired Crossbowman", "archer", 2, {}),
    ("e_wharf_brute", "Wharf Brute", "brute", 2, {}),
    ("e_tide_hexer", "Tide Hexer", "caster", 2, {"skills": ["frost_shard"]}),
    ("e_regency_pike", "Regency Pikeman", "guard", 3, {}),
    ("e_crown_crossbow", "Crown Crossbowman", "archer", 3, {}),
    ("e_regency_outrider", "Regency Outrider", "rider", 3, {}),
    ("e_field_chaplain", "Field Chaplain", "healer", 3, {"skills": ["mend"]}),
    ("e_dust_rider", "Dust Rider", "rider", 3, {}),
    ("e_jackal_raider", "Sandjackal Raider", "brute", 3, {}),
    ("e_horse_archer", "Horse-Lord Archer", "archer", 3, {}),
    ("e_ash_mage", "Ash Mage", "caster", 3, {"skills": ["ember_bolt"]}),
    ("e_lamp_warden", "Lamp Warden", "healer", 4, {"skills": ["mend", "mend_ii"]}),
    ("e_zealot_guard", "Zealot Guard", "guard", 4, {}),
    ("e_inquisitor", "Inquisitor", "skirm", 4, {}),
    ("e_pilgrim_archer", "Pilgrim Archer", "archer", 4, {}),
    ("e_rogue_mage", "Rogue Mage", "caster", 4, {"skills": ["ember_bolt", "ember_storm"]}),
    ("e_frost_scholar", "Frost Scholar", "caster", 4, {"skills": ["frost_shard", "frost_lance"], "class": "ice_mage"}),
    ("e_cult_acolyte", "Flame Acolyte", "skirm", 4, {}),
    ("e_book_ward", "Bookbound Ward", "guard", 4, {}),
    ("e_iron_knight", "Iron Knight", "guard", 5, {}),
    ("e_black_lancer", "Black Lancer", "rider", 5, {}),
    ("e_regent_crossbow", "Regent's Crossbowman", "archer", 5, {}),
    ("e_iron_priest", "Iron Confessor", "healer", 5, {"skills": ["mend", "mend_ii"]}),
    ("e_war_engineer", "War Engineer", "caster", 5, {"skills": ["ember_bolt", "ember_storm"]}),
    # bosses (commanders): hp x1.5, reward x3
    ("e_red_hallam", "Red Hallam", "archer", 2, {"boss": True, "class": "longbow_master"}),
    ("e_marl_tidewick", "Marl Tidewick", "skirm", 2, {"boss": True, "class": "assassin"}),
    ("e_odo_vell", "Sergeant Odo Vell", "guard", 3, {"boss": True}),
    ("e_rukh_dustmane", "Rukh Dustmane", "rider", 3, {"boss": True, "class": "lancer"}),
    ("e_ismay_cinder", "Cinder Prophet Ismay", "caster", 4, {"boss": True, "skills": ["ember_bolt", "ember_storm"]}),
    ("e_brask_hollin", "Castellan Brask Hollin", "guard", 5, {"boss": True}),
]


def enemy_def(eid, name, arch, tier, extra):
    t = tier - 1
    m = ARCH[arch]
    boss = bool(extra.get("boss"))
    s = TIER_STAT
    hp = round(s["hp"][t] * m[0] * (1.5 if boss else 1.0))
    mp = s["mp"][t] if arch in ("caster", "healer") else 0
    d = {
        "name": name,
        "reward": {"exp": round(s["exp"][t] * (3 if boss else 1)), "ap": round(s["ap"][t] * (3 if boss else 1)),
                   "gold": round(s["gold"][t] * (3 if boss else 1))},
        "class_id": extra.get("class", ARCH_CLASS[arch][t]),
        "level": s["lvl"][t] + (2 if boss else 0),
        "house": "none",
        "weapon_id": ARCH_WEAPON[arch][t],
        "armor_def": round(s["df"][t] * m[6]),
        "armor_res": s["res"][t] + (3 if arch in ("caster", "healer") else 0),
        "skills": extra.get("skills", []),
        "stats": {
            "hp": hp, "mp": mp, "str": round(s["str"][t] * m[1] * (1.1 if boss else 1.0)), "dex": round(s["dex"][t] * m[2]),
            "int": round(s["int"][t] * m[7]), "vit": round(s["vit"][t] * m[3]), "spd": round(s["spd"][t] * m[4]),
            "lck": 4 + t, "acc": s["acc"][t], "eva": round(s["eva"][t] * m[5]), "ldr": s["ldr"][t] + (6 if boss else 0),
            "mor": s["mor"][t] + (15 if boss else 0),
        },
    }
    return d


# ------------------------------------------------------------------ encounter groups per region (ids of characters.json)
REGION_GROUPS = {
    "sethmarch": [
        (5, ["roadreaver", "roadreaver", "roadbowman"]), (3, ["roadreaver", "roadbowman", "roadbowman"]),
        (3, ["e_marsh_cutpurse", "e_marsh_cutpurse", "roadreaver"]), (2, ["e_mire_raider", "roadreaver", "roadbowman", "e_marsh_cutpurse"]),
    ],
    "orrowen": [
        (4, ["e_green_poacher", "e_green_poacher", "e_weald_brawler"]), (3, ["e_green_scout", "e_green_poacher", "e_green_poacher", "e_weald_brawler"]),
        (3, ["e_weald_brawler", "e_weald_brawler", "e_green_poacher"]), (2, ["e_green_scout", "e_green_scout", "e_green_poacher", "e_green_poacher", "e_weald_brawler"]),
    ],
    "ysmark": [
        (4, ["e_dock_cutthroat", "e_dock_cutthroat", "e_hired_crossbow"]), (3, ["e_wharf_brute", "e_wharf_brute", "e_hired_crossbow"]),
        (3, ["e_tide_hexer", "e_dock_cutthroat", "e_wharf_brute", "e_hired_crossbow"]), (2, ["e_wharf_brute", "e_dock_cutthroat", "e_hired_crossbow", "e_hired_crossbow", "e_tide_hexer"]),
    ],
    "aurelmont": [
        (4, ["e_regency_pike", "e_regency_pike", "e_crown_crossbow"]), (3, ["e_regency_outrider", "e_regency_pike", "e_crown_crossbow", "e_crown_crossbow"]),
        (3, ["e_regency_pike", "e_field_chaplain", "e_crown_crossbow", "e_regency_outrider"]), (2, ["e_regency_outrider", "e_regency_outrider", "e_regency_pike", "e_field_chaplain", "e_crown_crossbow"]),
    ],
    "vessmoor": [
        (4, ["e_dust_rider", "e_dust_rider", "e_horse_archer"]), (3, ["e_jackal_raider", "e_jackal_raider", "e_horse_archer", "e_ash_mage"]),
        (3, ["e_dust_rider", "e_jackal_raider", "e_horse_archer", "e_horse_archer"]), (2, ["e_dust_rider", "e_dust_rider", "e_jackal_raider", "e_ash_mage", "e_horse_archer"]),
    ],
    "tarnholt": [
        (4, ["e_zealot_guard", "e_zealot_guard", "e_pilgrim_archer", "e_lamp_warden"]), (3, ["e_inquisitor", "e_inquisitor", "e_pilgrim_archer", "e_pilgrim_archer"]),
        (3, ["e_zealot_guard", "e_lamp_warden", "e_inquisitor", "e_pilgrim_archer"]), (2, ["e_zealot_guard", "e_zealot_guard", "e_inquisitor", "e_lamp_warden", "e_pilgrim_archer"]),
    ],
    "quillon": [
        (4, ["e_rogue_mage", "e_book_ward", "e_cult_acolyte"]), (3, ["e_frost_scholar", "e_rogue_mage", "e_book_ward", "e_book_ward"]),
        (3, ["e_cult_acolyte", "e_cult_acolyte", "e_rogue_mage", "e_frost_scholar"]), (2, ["e_book_ward", "e_book_ward", "e_rogue_mage", "e_frost_scholar", "e_cult_acolyte"]),
    ],
    "brennhallow": [
        (4, ["e_iron_knight", "e_iron_knight", "e_regent_crossbow", "e_regent_crossbow"]), (3, ["e_black_lancer", "e_black_lancer", "e_iron_knight", "e_iron_priest"]),
        (3, ["e_iron_knight", "e_war_engineer", "e_regent_crossbow", "e_iron_priest"]), (2, ["e_iron_knight", "e_iron_knight", "e_black_lancer", "e_war_engineer", "e_iron_priest"]),
    ],
}
AMBUSH_TEXT = {
    "sethmarch": "Roadwolves leap from the reeds!", "orrowen": "Arrows hiss out of the weald!", "ysmark": "Cutthroats spill out of the salt grass!",
    "aurelmont": "A Regency patrol bars the road!", "vessmoor": "Dust-riders thunder out of the haze!", "tarnholt": "Zealots step out of the shrine-shadows!",
    "quillon": "Robed figures raise their hands. The air burns!", "brennhallow": "Iron-clad riders charge down the pass!",
}
CAMPS = {
    "hask_band": {"title": "Roadwolf Camp", "briefing": "Hask Gravelteeth's raiders hold the road to Eldrimar. Break the palisade and take their chief.",
                  "units": ["hask_gravelteeth", "roadreaver", "roadreaver", "roadbowman", "roadbowman"], "commander": "hask_gravelteeth"},
    "greenhood_band": {"title": "Greenhood Camp", "briefing": "Red Hallam's outlaw archers shoot from every bramble. Close the distance and take their captain.",
                       "units": ["e_red_hallam", "e_green_poacher", "e_green_poacher", "e_green_scout", "e_weald_brawler"], "commander": "e_red_hallam"},
    "smuggler_band": {"title": "Smugglers' Cove", "briefing": "Marl Tidewick's crew runs contraband through the cliff cave. Take the cove and its captain.",
                      "units": ["e_marl_tidewick", "e_dock_cutthroat", "e_dock_cutthroat", "e_hired_crossbow", "e_tide_hexer"], "commander": "e_marl_tidewick"},
    "deserter_band": {"title": "Deserters' Camp", "briefing": "Sergeant Odo Vell led his company off the field and into banditry. End it.",
                      "units": ["e_odo_vell", "e_regency_pike", "e_regency_pike", "e_crown_crossbow", "e_field_chaplain"], "commander": "e_odo_vell"},
    "sandjackal_band": {"title": "Sandjackal Camp", "briefing": "Rukh Dustmane's riders raid the caravan road. Break the dust-lancers.",
                        "units": ["e_rukh_dustmane", "e_dust_rider", "e_dust_rider", "e_horse_archer", "e_ash_mage"], "commander": "e_rukh_dustmane"},
    "flame_cult": {"title": "Flamebearer Camp", "briefing": "Cinder Prophet Ismay's fire gives no heat and no mercy. Douse it.",
                   "units": ["e_ismay_cinder", "e_cult_acolyte", "e_cult_acolyte", "e_rogue_mage", "e_book_ward"], "commander": "e_ismay_cinder"},
    "blackcrag_garrison": {"title": "Blackcrag Fastness", "briefing": "Castellan Hollin's garrison answers only to the Regent. Storm the gate.",
                           "units": ["e_brask_hollin", "e_iron_knight", "e_iron_knight", "e_regent_crossbow", "e_iron_priest"], "commander": "e_brask_hollin"},
}

# ------------------------------------------------------------------ shops
REGION_MULT = {"sethmarch": 1.0, "orrowen": 1.0, "ysmark": 0.92, "aurelmont": 1.05, "vessmoor": 1.0, "tarnholt": 1.05, "quillon": 1.1, "brennhallow": 1.15}
REGION_TIER = {"sethmarch": 1, "orrowen": 2, "ysmark": 2, "aurelmont": 3, "vessmoor": 3, "tarnholt": 4, "quillon": 4, "brennhallow": 5}


def main():
    weapons = load("weapons.json")
    items = load("items.json")
    chars = load("characters.json")
    enc = load("encounters.json")
    world = load("world.json")

    item_tier = {}   # item id -> (tier, where)
    for wid, (wdef, idef, tier, where) in WEAPONS.items():
        weapons["weapons"][wid] = wdef
        items["items"][wid] = idef
        item_tier[wid] = (tier, where)
    for iid, (idef, tier, where) in GEAR.items():
        items["items"][iid] = idef
        item_tier[iid] = (tier, where)
    # hand-written items from before also take part in the shops
    legacy = {
        "arming_sword": (1, "*"), "hunting_bow": (1, "*"), "short_bow": (1, "*"), "mace": (1, "*"), "hand_axe": (1, "*"),
        "longsword": (1, "*"), "battle_axe": (2, "*"), "fine_arming_sword": (2, "*"), "hardwood_bow": (2, ["orrowen", "ysmark"]),
        "greatsword": (3, ["brennhallow", "aurelmont", "vessmoor"]),
        "buckler": (1, "*"), "kite_shield": (2, "*"), "padded_jerkin": (1, "*"), "leather_cuirass": (1, "*"), "pilgrim_robe": (1, "*"),
        "mail_hauberk": (2, "*"), "plate_harness": (4, ["brennhallow", "aurelmont", "ysmark"]),
        "iron_cap": (1, "*"), "kettle_helm": (1, "*"), "pilgrim_medal": (2, "*"), "hawk_feather": (2, "*"),
    }
    for k, v in legacy.items():
        item_tier[k] = v
    dump_lines("weapons.json", weapons, {"weapons"})
    dump_lines("items.json", items, {"items"})

    # enemies
    for (eid, name, arch, tier, extra) in ENEMIES:
        chars["characters"][eid] = enemy_def(eid, name, arch, tier, extra)
    dump_lines("characters.json", chars, {"characters"})

    # encounters
    enc["regions"] = {}
    for rid, groups in REGION_GROUPS.items():
        enc["regions"][rid] = {"ambush": AMBUSH_TEXT[rid], "groups": [{"weight": w, "units": u} for (w, u) in groups]}
    enc["camps"] = CAMPS
    with open(D("encounters.json"), "w") as f:
        json.dump(enc, f, indent=1)

    # shops: one shop entry per shop, tagged with its place
    sigils = load("sigils.json")["sigils"]
    shops = {}
    weapon_slots = ("weapon", "offhand")
    for p in world["places"]:
        kind = p["kind"]
        if kind not in ("keep", "city", "town", "village"):
            continue
        rid = p["region"]
        T = REGION_TIER[rid]
        mult = REGION_MULT[rid]

        def pick(cats, lo, hi):
            out = []
            for iid, (tier, where) in item_tier.items():
                slot = items["items"][iid]["slot"]
                if slot not in cats or tier < lo or tier > hi:
                    continue
                if where != "*" and rid not in where:
                    continue
                out.append(iid)
            order = {"weapon": 0, "offhand": 1, "armor": 2, "helm": 3, "accessory": 4}
            out.sort(key=lambda i: (order.get(items["items"][i]["slot"], 9), items["items"][i].get("price", 0)))
            return out

        def sig(maxtier):
            return [s for s in sigils.keys() if SIGIL_TIER.get(s, 2) <= maxtier]

        pid = p["id"]
        if kind == "keep":
            shops[pid + "_stores"] = {"place": pid, "name": "Sethorn Quartermaster", "sell_ratio": 0.5, "price_mult": 1.0,
                                      "items": ["arming_sword", "hunting_bow", "short_bow", "mace", "hand_axe", "dirk", "ash_staff", "buckler", "padded_jerkin", "leather_cuirass", "iron_cap", "kettle_helm"],
                                      "sigils": ["mend", "ember", "vigor"]}
        elif kind == "village":
            lo = max(1, T - 1)
            stock = pick(("weapon", "offhand", "armor", "helm"), lo, T)
            # a village stocks a hand-picked slice: every second line, at most 9 items
            stock = stock[::2][:9] if len(stock) > 9 else stock
            for must in ("padded_jerkin",):
                if must not in stock and T == 1:
                    stock.append(must)
            shops[pid + "_store"] = {"place": pid, "name": p["name"] + " General Store", "sell_ratio": 0.5, "price_mult": round(mult + 0.04, 2),
                                     "items": stock, "sigils": sig(1) if T <= 2 else []}
        elif kind == "town":
            shops[pid + "_smithy"] = {"place": pid, "name": p["name"] + " Smithy", "sell_ratio": 0.5, "price_mult": mult,
                                      "items": pick(weapon_slots, max(1, T - 1), T + 1), "sigils": []}
            shops[pid + "_outfitter"] = {"place": pid, "name": p["name"] + " Outfitter", "sell_ratio": 0.5, "price_mult": mult,
                                         "items": pick(("armor", "helm", "accessory"), max(1, T - 1), T + 1), "sigils": sig(T)}
        else:  # city
            shops[pid + "_smithy"] = {"place": pid, "name": p["name"] + " Armoury", "sell_ratio": 0.55, "price_mult": mult,
                                      "items": pick(weapon_slots, max(1, T - 2), T + 1), "sigils": []}
            shops[pid + "_outfitter"] = {"place": pid, "name": p["name"] + " Outfitters", "sell_ratio": 0.55, "price_mult": mult,
                                         "items": pick(("armor", "helm", "accessory"), max(1, T - 2), T + 1), "sigils": []}
            shops[pid + "_arcanum"] = {"place": pid, "name": p["name"] + " Arcanum", "sell_ratio": 0.6, "price_mult": mult,
                                       "items": [i for i in pick(("weapon", "armor", "accessory"), 1, T + 1) if items["items"][i].get("bonus", {}).get("int")],
                                       "sigils": sig(T + 1)}
    with open(D("shops.json"), "w") as f:
        f.write('{\n "shops": {\n' + ",\n".join("  %s: %s" % (json.dumps(k), json.dumps(v, ensure_ascii=False)) for k, v in shops.items()) + "\n }\n}\n")
    print("weapons:", len(weapons["weapons"]), "items:", len(items["items"]), "characters:", len(chars["characters"]), "shops:", len(shops))
    for k, v in shops.items():
        print("  %-26s %2d items %2d sigils x%.2f" % (k, len(v["items"]), len(v["sigils"]), v["price_mult"]))


if __name__ == "__main__":
    main()
