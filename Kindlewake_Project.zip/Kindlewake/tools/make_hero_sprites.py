#!/usr/bin/env python3
"""Builds the hero sprite sheets of Kindlewake from the Tiny RPG Soldier sheets (v0.8.0).

  python3 tools/make_hero_sprites.py            # writes assets/sprites/characters/heroes/<kind>_<anim>.png
  python3 tools/make_hero_sprites.py --preview  # also writes docs/hero_designs.png (zoomed contact sheet)

Each hero gets a unique silhouette and one signature accent colour (design rules: black-shape test, 2-3 colours, one accent):
  torren   bare head, ember scarf with a trailing tail, charcoal gambeson (hair and scarf colour are selectable)
  bram     plumed great helm, grey beard, broad pauldrons, bone-white tabard, drawn 12% larger
  sela     green hood with a point, auburn braid, leather jerkin, long bow (own draw animation), drawn 4% smaller
  wystan   bare tonsured head, ivory robe, lantern staff taller than the head (own flare animation)
Source art: tools/sprite_src/soldier_*.png (copies of the Tiny RPG Soldier sheets) (Tiny RPG Character Asset Pack by Zerie; licence allows editing, no resale of the asset).
The frame layout (100x100 cells, 6/8/6/4/4 frames) is unchanged, so the sprite code needs no new rules (scripts/core/hero_art.gd).
"""
import math
import os
import sys
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "tools", "sprite_src")
UNITS = os.path.join(ROOT, "assets", "sprites", "characters", "heroes")
FR = 100
ANIMS = {"idle": 6, "walk": 8, "attack": 6, "hurt": 4, "death": 4}


def hx(s):
    s = s.lstrip("#")
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


# Source palette of the Soldier, dark -> light.
STEEL = [(66, 92, 107), (96, 117, 129), (111, 130, 141), (127, 144, 154), (155, 173, 183), (197, 208, 213)]
RED = [(45, 7, 4), (76, 26, 26), (98, 25, 20), (103, 32, 32), (143, 56, 56)]
BROWN = [(67, 26, 11), (123, 78, 22), (141, 101, 52), (148, 104, 53), (183, 140, 97)]
SKIN = (242, 218, 210, 255)

REF_AY = 39       # top row of the helmet in idle frame 0
REF_AX = 50.0     # mean column of the helmet in idle frame 0 (measured once, see anchor())

# ---------------------------------------------------------------- colour ramps (dark -> light, same length as the source family)
HAIR = {
    "raven": [hx(c) for c in ("#1b1618", "#2a2124", "#3b2f33", "#52434a", "#6d5a60", "#8c7a80")],
    "chestnut": [hx(c) for c in ("#2b1a12", "#4a2c1c", "#6b4128", "#8a5a38", "#a8764a", "#c79a6e")],
    "ashblond": [hx(c) for c in ("#5a4e3c", "#7d6d52", "#a08d68", "#bfae86", "#d9ca9f", "#efe2bd")],
}
SCARF = {  # dark, mid, light (+ deep)
    "ember": [hx(c) for c in ("#5e2012", "#9e3b1f", "#d9622b", "#f2994a")],
    "gilt": [hx(c) for c in ("#4f3b12", "#8a6a1c", "#c9a233", "#ecd277")],
    "ash": [hx(c) for c in ("#2c3036", "#555d66", "#8b95a0", "#c4ccd4")],
}
CHARCOAL = [hx(c) for c in ("#14151a", "#1f2128", "#2a2d36", "#333743", "#4a5060")]
BONE = [hx(c) for c in ("#6b6458", "#8d8576", "#a39b8a", "#b8b09e", "#d9d2bf")]
PLATE = [hx(c) for c in ("#5a6a76", "#7b8c99", "#94a4b0", "#aebbc5", "#cdd8df", "#f1f5f7")]
OXBLOOD = [hx(c) for c in ("#5a1a1a", "#7d2424", "#a33030")]
GREY_BEARD = [hx(c) for c in ("#8a8d92", "#b4b7bb", "#d8dadd")]
HOOD = [hx(c) for c in ("#1f3a27", "#2e5237", "#3f6b48", "#4f8159", "#6a9b6e", "#8dbb8a")]
LEATHER = [hx(c) for c in ("#33210f", "#4a3320", "#6b4a2e", "#7a5634", "#9c7348")]
BRAID = [hx(c) for c in ("#8a3d1e", "#b2542a", "#d07a3c")]
MOUSE = [hx(c) for c in ("#4a3a2c", "#6a5340", "#8a6c52", "#a98a68", "#c6a883", "#e0c9a6")]
ROBE = [hx(c) for c in ("#23263d", "#2f3350", "#43486b", "#5a6088", "#7e86ad")]   # vesper indigo
CORD = [hx(c) for c in ("#2e2218", "#4a3828", "#5b4636", "#6e5642", "#8a6f55")]
WOOD = hx("#6b4a2a")
WOOD_L = hx("#8e6a40")
IRON = hx("#2a2a2e")
GLOW_A = hx("#ffd36a")
GLOW_B = hx("#ffb347")
SKIN_SH = hx("#cfa890")
STRING = hx("#d8d0b8")
FLETCH = hx("#efe6cf")
OUT = (0, 0, 0, 255)


class Fr:
    """One 100x100 RGBA frame with the few drawing helpers the hero designs need."""

    def __init__(self, arr, dx=0, dy=0):
        self.a = arr.copy()
        self.dx = dx
        self.dy = dy

    def opaque(self):
        return self.a[:, :, 3] > 0

    def family(self, src, dst, y0=0, y1=FR):
        """Replace every pixel of the source colours by the same-rank colour of dst (rows y0..y1-1 only)."""
        for i, c in enumerate(src):
            m = (self.a[:, :, 0] == c[0]) & (self.a[:, :, 1] == c[1]) & (self.a[:, :, 2] == c[2]) & self.opaque()
            m[:y0, :] = False
            m[y1:, :] = False
            self.a[m] = dst[min(i, len(dst) - 1)]

    def put(self, x, y, col, behind=False):
        x += self.dx
        y += self.dy
        if 0 <= x < FR and 0 <= y < FR:
            if behind and self.a[y, x, 3] > 0:
                return
            self.a[y, x] = col

    def rect(self, x, y, w, h, col, behind=False):
        for j in range(h):
            for i in range(w):
                self.put(x + i, y + j, col, behind)

    def row_pixels(self, y, x0, x1, col):
        for x in range(x0, x1 + 1):
            self.put(x, y, col)


def anchor(a):
    """(ay, ax) of the helmet (steel pixels in the head columns) or None when the head is not upright (fallen body)."""
    m = np.zeros(a.shape[:2], dtype=bool)
    for c in STEEL:
        m |= (a[:, :, 0] == c[0]) & (a[:, :, 1] == c[1]) & (a[:, :, 2] == c[2]) & (a[:, :, 3] > 0)
    m[:, :44] = False
    m[:, 57:] = False
    ys, xs = np.where(m)
    if len(ys) == 0:
        return None
    return int(ys.min()), float(xs.mean())


def load_sheet(kind, anim):
    im = Image.open(os.path.join(SRC if kind == "soldier" else UNITS, "%s_%s.png" % (kind, anim))).convert("RGBA")
    arr = np.array(im)
    return [arr[:, i * FR:(i + 1) * FR] for i in range(ANIMS[anim])]


def save_sheet(kind, anim, frames):
    out = np.concatenate([f.a for f in frames], axis=1)
    Image.fromarray(out, "RGBA").save(os.path.join(UNITS, "%s_%s.png" % (kind, anim)))


def sway(i, n=6):
    return [0, 0, 1, 1, 0, 0, -1, -1][i % 8]


# ---------------------------------------------------------------- the four designs
def design_torren(f, anim, i, hair, scarf):
    hr = HAIR[hair]
    sc = SCARF[scarf]
    ay = REF_AY
    f.family(STEEL, hr, y0=0, y1=ay + f.dy + 9)               # helmet -> hair
    f.family(RED, CHARCOAL)                                     # tunic -> charcoal gambeson
    if anim == "death" and i >= 2:
        return
    s = sway(i)
    # windswept hair tuft above and behind the head
    f.put(48, 38, hr[3], behind=True)
    f.put(47, 39, hr[2], behind=True)
    f.put(46, 40, hr[1], behind=True)
    # scarf band over the gorget and knot
    f.row_pixels(49, 48, 52, sc[2])
    f.put(48, 49, sc[1])
    f.put(52, 49, sc[3])
    f.put(47, 50, sc[1])
    f.put(47, 49, sc[2])
    # trailing tail (behind, flows left and sways)
    tail = [(43, 50, sc[2]), (42, 50, sc[3]), (41, 51 + s, sc[2]), (40, 51 + s, sc[2]), (39, 52 + s, sc[1]),
            (38, 52 + s, sc[1]), (42, 51, sc[1]), (41, 52 + s, sc[1]), (40, 53 + s, sc[0]), (39, 53 + s, sc[0])]
    for x, y, c in tail:
        f.put(x, y, c, behind=True)
    # ember badge on the chest
    f.put(51, 52, hx("#f2c14e"))
    f.put(51, 53, hx("#d9962b"))


def design_bram(f, anim, i):
    f.family(STEEL, PLATE)
    f.family(RED, BONE)
    if anim == "death" and i >= 2:
        return
    s = sway(i)
    # oxblood plume rising from the crest and hanging back
    for x, y, c in [(50, 38, OXBLOOD[2]), (50, 37, OXBLOOD[1]), (49, 37, OXBLOOD[2]), (49, 38, OXBLOOD[1]),
                    (48, 38 + s, OXBLOOD[1]), (47, 39 + s, OXBLOOD[0]), (47, 40 + s, OXBLOOD[0]), (51, 37, OXBLOOD[1])]:
        f.put(x, y, c, behind=True)
    # grey beard on the lower face
    for x in range(49, 54):
        if tuple(f.a[48 + f.dy, x + f.dx, :3]) in [(242, 218, 210), (190, 155, 151)]:
            f.put(x, 48, GREY_BEARD[1])
    f.put(50, 48, GREY_BEARD[2])
    f.put(51, 49, GREY_BEARD[0], behind=False)
    # broad pauldrons
    for x, y, c in [(42, 49, OUT), (43, 49, PLATE[3]), (44, 49, PLATE[4]), (42, 50, PLATE[2]), (43, 50, PLATE[3]), (42, 51, OUT),
                    (43, 51, PLATE[1]), (56, 50, PLATE[3]), (57, 50, PLATE[4]), (58, 50, OUT), (56, 51, PLATE[2]), (57, 51, PLATE[3]), (58, 51, OUT), (57, 52, OUT)]:
        f.put(x, y, c)
    # tarnished gold trim on the chest
    f.put(50, 52, hx("#c9a233"))
    f.put(51, 52, hx("#8a6a1c"))


def design_sela(f, anim, i, body_from_idle=False):
    f.family(STEEL, HOOD)
    f.family(RED, LEATHER)
    f.family(BROWN, [CORD[0], CORD[1], CORD[2], CORD[3], CORD[4]])
    if anim == "death" and i >= 2:
        return
    s = sway(i)
    # hood point rising behind the head
    for x, y, c in [(47, 38, HOOD[3]), (46, 38, HOOD[2]), (46, 39, HOOD[2]), (45, 39, HOOD[1]), (45, 40, HOOD[1]), (44, 40, HOOD[0])]:
        f.put(x, y, c, behind=True)
    # auburn braid hanging behind
    for k, (x, y) in enumerate([(44, 47), (43, 48), (43, 49), (43, 50 + s), (42, 51 + s), (42, 52 + s), (42, 53 + s), (43, 54 + s)]):
        f.put(x, y, BRAID[1 if k % 2 == 0 else 0], behind=True)
    f.put(43, 55 + s, BRAID[2], behind=True)
    # fletching of the arrows over the shoulder
    f.put(45, 43, FLETCH, behind=True)
    f.put(44, 42, FLETCH, behind=True)
    f.put(46, 42, FLETCH, behind=True)
    # green mantle edge over the shoulder
    f.put(55, 50, HOOD[4])
    f.put(55, 51, HOOD[3])


def draw_bow(f, x, y0, y1, bulge, string_back):
    """Vertical bow: tips at (x, y0) and (x, y1), belly bulges to x+bulge, string at x - string_back."""
    h = y1 - y0
    for k in range(h + 1):
        t = k / float(h)
        d = 4.0 * t * (1.0 - t)
        f.put(int(round(x + bulge * d)), y0 + k, WOOD if k % 3 else WOOD_L)
    ym = (y0 + y1) // 2
    xs = int(x - string_back)
    for k in range(h + 1):
        t = k / float(h)
        d = 1.0 - abs(2.0 * t - 1.0)
        f.put(int(round(x - string_back * d)) if string_back > 0 else x, y0 + k, STRING)
    return xs, ym


def sela_extras(f, anim, i):
    if anim == "attack":
        # synthesised draw-and-loose: the body is the idle pose, the bow moves to the front
        sched = [(57, 0, 0), (55, 2, 1), (54, 3, 1), (58, 0, 0), (57, 0, 0), (56, 0, 0)]
        sx, back, arrow = sched[i]
        draw_bow(f, 58, 41, 58, 2, back)
        if arrow:
            ay = 50
            for x in range(sx - 1, 63):
                f.put(x, ay, hx("#cfc7a8"))
            f.put(63, ay, hx("#dfe3e6"))
            f.put(62, ay - 1, hx("#dfe3e6"))
            f.put(62, ay + 1, hx("#dfe3e6"))
            f.put(sx - 1, ay - 1, FLETCH)
            f.put(sx - 1, ay + 1, FLETCH)
        f.put(56, 50, SKIN)
        f.put(56, 51, SKIN_SH)
    else:
        draw_bow(f, 40, 43, 58, -2, 0)                           # resting bow carried at the back


def design_wystan(f, anim, i):
    f.family(STEEL, MOUSE, y0=0, y1=REF_AY + f.dy + 9)         # helmet -> short hair
    f.family(STEEL, ROBE, y0=REF_AY + f.dy + 9)                # chest armour -> robe
    f.family(RED, ROBE)
    f.family(BROWN, CORD)
    if anim == "death" and i >= 2:
        return
    # tonsure: bare crown
    for x, y in [(49, 41), (50, 41), (51, 41), (49, 42), (50, 42), (51, 42), (50, 40), (49, 40)]:
        f.put(x, y, SKIN if (x + y) % 2 == 0 else SKIN_SH)
    f.put(48, 42, MOUSE[4])
    f.put(52, 42, MOUSE[4])
    # lantern staff on the right, taller than the head
    lifts = {"attack": [0, -1, -3, -4, -2, 0]}.get(anim, [0] * 8)
    lift = lifts[i % len(lifts)]
    top = 35 + lift
    for y in range(top + 6, 59):
        f.put(58, y, WOOD if y % 2 else WOOD_L)
    f.put(57, 52 + lift // 2, SKIN)
    f.put(57, 53 + lift // 2, SKIN_SH)
    flick = GLOW_A if (i % 2 == 0) else GLOW_B
    for x, y, c in [(57, top, IRON), (58, top, IRON), (59, top, IRON), (57, top + 1, IRON), (58, top + 1, flick), (59, top + 1, IRON),
                    (57, top + 2, IRON), (58, top + 2, GLOW_A), (59, top + 2, IRON), (57, top + 3, IRON), (58, top + 3, flick), (59, top + 3, IRON),
                    (57, top + 4, IRON), (58, top + 4, IRON), (59, top + 4, IRON), (58, top - 1, IRON)]:
        f.put(x, y, c)
    if anim == "attack" and i in (2, 3, 4):
        r = [3, 5, 4][i - 2]
        for ang in range(0, 360, 30):
            f.put(58 + int(round(math.cos(math.radians(ang)) * r)), top + 2 + int(round(math.sin(math.radians(ang)) * r)), GLOW_A if ang % 60 == 0 else GLOW_B)
    # rope belt knot
    f.put(50, 53, CORD[4])


# ---------------------------------------------------------------- pipeline
def build(kind, designer, synth_attack=False):
    for anim, n in ANIMS.items():
        src = load_sheet("soldier", anim)
        out = []
        for i in range(n):
            base = src[0 if (synth_attack and anim == "attack") else i]
            anc = anchor(base)
            dx = dy = 0
            if anc is not None:
                dy = anc[0] - REF_AY
                dx = int(round(anc[1] - REF_AX))
            f = Fr(base, dx, dy)
            if anim == "death" and i >= 2:
                f.dx = f.dy = 0
            designer(f, anim, i)
            out.append(f)
        save_sheet(kind, anim, out)


def torren_build(hair, scarf):
    kind = "torren_%s_%s" % (hair, scarf)
    build(kind, lambda f, a, i: design_torren(f, a, i, hair, scarf))
    return kind


def sela_designer(f, anim, i):
    design_sela(f, anim, i)
    sela_extras(f, anim, i)


def reference_anchor():
    a = load_sheet("soldier", "idle")[0]
    ay, ax = anchor(a)
    return ay, ax


def preview(kinds, path):
    zoom = 6
    cells = []
    for kind in kinds:
        row = []
        for anim, idx in [("idle", 0), ("idle", 2), ("walk", 3), ("attack", 1), ("attack", 3), ("hurt", 0), ("death", 1)]:
            sheet = Image.open(os.path.join(UNITS, "%s_%s.png" % (kind, anim))).convert("RGBA")
            fr = sheet.crop((idx * FR + 28, 28, idx * FR + 76, 64))
            row.append(fr)
        cells.append(row)
    w, h = 48, 36
    img = Image.new("RGBA", (w * 7 * zoom, h * len(kinds) * zoom), (46, 56, 50, 255))
    for r, row in enumerate(cells):
        for c, fr in enumerate(row):
            big = fr.resize((w * zoom, h * zoom), Image.NEAREST)
            img.alpha_composite(big, (c * w * zoom, r * h * zoom))
    img.save(path)


def colourways(kinds, path):
    """3x3 contact sheet of Torren's hair x scarf colourways (idle frame 0)."""
    zoom = 6
    w, h = 40, 34
    img = Image.new("RGBA", (w * 3 * zoom, h * 3 * zoom), (46, 56, 50, 255))
    for n, kind in enumerate(kinds):
        sheet = Image.open(os.path.join(UNITS, "%s_idle.png" % kind)).convert("RGBA")
        fr = sheet.crop((30, 30, 30 + w, 30 + h)).resize((w * zoom, h * zoom), Image.NEAREST)
        img.alpha_composite(fr, ((n % 3) * w * zoom, (n // 3) * h * zoom))
    img.save(path)


def main():
    global REF_AY, REF_AX
    REF_AY, REF_AX = reference_anchor()
    kinds = []
    for hair in HAIR:
        for scarf in SCARF:
            kinds.append(torren_build(hair, scarf))
    build("bram", design_bram)
    build("sela", sela_designer, synth_attack=True)
    build("wystan", design_wystan, synth_attack=True)
    if "--preview" in sys.argv:
        preview(["torren_raven_ember", "bram", "sela", "wystan"], os.path.join(ROOT, "docs", "hero_designs.png"))
        colourways(kinds, os.path.join(ROOT, "docs", "torren_colourways.png"))
    print("wrote %d torren colourways + bram, sela, wystan (anchor %d, %.1f)" % (len(kinds), REF_AY, REF_AX))


if __name__ == "__main__":
    main()
