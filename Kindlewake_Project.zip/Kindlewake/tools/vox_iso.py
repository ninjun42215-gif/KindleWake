#!/usr/bin/env python3
"""MagicaVoxel (.vox) reader + isometric (2:1 dimetric) voxel renderer. Pure numpy + Pillow.
Used by tools/build_scenes.py to pre-render dungeon rooms, interiors and town props (the FF7 'pre-rendered background' look).
Coordinates: voxel (x, y, z) with z up. View rotation 0..3 turns the model by 90 degrees around the vertical axis."""
import struct
import numpy as np
from PIL import Image, ImageDraw

SHADE = {"top": 1.0, "left": 0.78, "right": 0.58}      # light from the top-left


def read_vox(path):
    """Returns (list of (size, voxels ndarray Nx4 [x,y,z,colour index]), palette ndarray 256x4)."""
    d = open(path, "rb").read()
    if d[:4] != b"VOX ":
        raise ValueError("not a .vox file: " + path)
    pos = 8
    models, pal, cur = [], None, None
    # MAIN chunk header
    n, c = struct.unpack("<ii", d[pos + 4:pos + 12])
    pos += 12 + n
    while pos < len(d):
        cid = d[pos:pos + 4]
        n, c = struct.unpack("<ii", d[pos + 4:pos + 12])
        p = pos + 12
        if cid == b"SIZE":
            cur = struct.unpack("<iii", d[p:p + 12])
        elif cid == b"XYZI":
            cnt = struct.unpack("<i", d[p:p + 4])[0]
            arr = np.frombuffer(d[p + 4:p + 4 + cnt * 4], dtype=np.uint8).reshape(cnt, 4).astype(np.int32)
            models.append((cur, arr))
        elif cid == b"RGBA":
            pal = np.frombuffer(d[p:p + 1024], dtype=np.uint8).reshape(256, 4).copy()
        pos = p + n + c
    if pal is None:
        pal = np.full((256, 4), 200, dtype=np.uint8)
    return models, pal


def colour(pal, idx):
    """vox colour index (1..255) -> (r, g, b)."""
    r, g, b, _ = pal[(idx - 1) % 256]
    return int(r), int(g), int(b)


def to_grid(size, vox):
    """Dense colour-index grid [x, y, z] (0 = empty)."""
    g = np.zeros(size, dtype=np.uint8)
    g[vox[:, 0], vox[:, 1], vox[:, 2]] = vox[:, 3]
    return g


def rotate_grid(g, rot):
    """Rotate a grid by rot * 90 degrees around z."""
    for _ in range(rot % 4):
        g = np.rot90(g, 1, axes=(0, 1)).copy()
    return g


class Projector:
    """Screen position of a voxel-space point. a = pixels per half voxel width (the 2:1 diamond half width)."""

    def __init__(self, nx, ny, nz, a):
        self.nx, self.ny, self.nz, self.a = nx, ny, nz, a
        self.kz = 1.2247 * a                     # vertical edge of a cube, true 2:1 dimetric
        self.ox = ny * a + 2                      # screen x of the grid's x=0,y=ny corner
        self.oy = nz * self.kz + 2
        self.w = int((nx + ny) * a + 4)
        self.h = int((nx + ny) * a * 0.5 + nz * self.kz + 4)

    def pt(self, x, y, z):
        return (self.ox + (x - y) * self.a, self.oy + (x + y) * self.a * 0.5 - z * self.kz)


def render_grid(g, pal, a=4, only=None, z_min=None, band=None, outline=True):
    """Painter's-algorithm render of a colour grid. Returns (RGBA image, Projector).
    only: optional boolean mask [x,y,z] limiting which voxels are drawn (neighbour tests still use the full grid).
    band: optional (d0, d1): draw only voxels whose x+y lies in [d0, d1)."""
    nx, ny, nz = g.shape
    pr = Projector(nx, ny, nz, a)
    im = Image.new("RGBA", (pr.w, pr.h), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    solid = g > 0
    # visible faces: top (z+1 empty), left face (towards +y), right face (towards +x)
    pad = np.pad(solid, 1, constant_values=False)
    top = solid & ~pad[1:-1, 1:-1, 2:]
    lef = solid & ~pad[1:-1, 2:, 1:-1]
    rig = solid & ~pad[2:, 1:-1, 1:-1]
    vis = top | lef | rig
    # cheap ambient occlusion: a top face darkens by 6% per solid neighbour standing one voxel higher (4-neighbourhood)
    nb = (pad[0:-2, 1:-1, 2:].astype(np.int8) + pad[2:, 1:-1, 2:] + pad[1:-1, 0:-2, 2:] + pad[1:-1, 2:, 2:])
    if only is not None:
        vis &= only
    if band is not None:
        xs = np.arange(nx)[:, None, None]
        ys = np.arange(ny)[None, :, None]
        s = xs + ys
        vis &= (s >= band[0]) & (s < band[1])
    idx = np.argwhere(vis)
    # draw order: back to front = small x+y first, then low z first
    order = np.lexsort((idx[:, 2], idx[:, 0] + idx[:, 1]))
    idx = idx[order]
    for x, y, z in idx:
        c = colour(pal, int(g[x, y, z]))
        p0 = pr.pt(x, y, z + 1)          # top face corners: (x,y) (x+1,y) (x+1,y+1) (x,y+1) at height z+1
        p1 = pr.pt(x + 1, y, z + 1)
        p2 = pr.pt(x + 1, y + 1, z + 1)
        p3 = pr.pt(x, y + 1, z + 1)
        if top[x, y, z]:
            dr.polygon([p0, p1, p2, p3], fill=_sh(c, SHADE["top"] - 0.06 * float(nb[x, y, z]), x, y, z))
        if lef[x, y, z]:                 # face at y+1, spans x..x+1
            q0, q1 = pr.pt(x, y + 1, z + 1), pr.pt(x + 1, y + 1, z + 1)
            q2, q3 = pr.pt(x + 1, y + 1, z), pr.pt(x, y + 1, z)
            dr.polygon([q0, q1, q2, q3], fill=_sh(c, SHADE["left"], x, y, z))
        if rig[x, y, z]:                 # face at x+1, spans y..y+1
            q0, q1 = pr.pt(x + 1, y, z + 1), pr.pt(x + 1, y + 1, z + 1)
            q2, q3 = pr.pt(x + 1, y + 1, z), pr.pt(x + 1, y, z)
            dr.polygon([q0, q1, q2, q3], fill=_sh(c, SHADE["right"], x, y, z))
    return im, pr


def _sh(c, k, x, y, z):
    j = 1.0 + (((x * 7 + y * 13 + z * 5) % 5) - 2) * 0.012      # tiny per-voxel variation, keeps flat colour from looking dead
    return (int(min(255, c[0] * k * j)), int(min(255, c[1] * k * j)), int(min(255, c[2] * k * j)), 255)


def heightmap(g):
    """Top solid z+1 per (x, y) column; 0 where the column is empty."""
    nx, ny, nz = g.shape
    solid = g > 0
    h = np.zeros((nx, ny), dtype=np.int32)
    for z in range(nz):
        h[solid[:, :, z]] = z + 1
    return h
