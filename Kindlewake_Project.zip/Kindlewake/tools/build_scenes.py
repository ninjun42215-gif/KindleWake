#!/usr/bin/env python3
"""Builds the FF7-style pre-rendered rooms from the voxel room packs (see CREDITS).
For every room model it writes:
  assets/art/rooms/<id>.png          background (fixed 2:1 isometric camera, the whole room)
  assets/art/rooms/<id>_o<k>.png     occluder slices: props that must draw IN FRONT of the hero when the hero stands behind them
and it returns the metadata (projection, walk grid, heights, doorway cells) that goes to data/rooms.json.
Usage: python3 tools/build_scenes.py <folder with the unzipped sprite packs> [--debug]
"""
import json, os, sys
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vox_iso as V

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "assets", "art", "rooms")
A = 4                       # pixels per half voxel width
CLEAR = 9                   # free voxels needed above the floor for the hero to stand (hero is about 12 voxels tall)
LOW = 3                     # decoration up to this many voxels tall (grass, flowers) does not block walking
STEP = 2                    # largest floor step the hero can climb
BAND = 4                    # width (in x+y) of one occluder slice

# id -> (vox file stem, folder hint)
ROOMS = {
    "boss": "Boss Room.vox", "dragon": "Dragon Room.vox", "garden": "Garden.vox", "king": "King Room.vox",
    "princess": "Princess  Chamber.vox", "stairs": "Stairs.vox", "corridor": "Thirsty Corridor.vox",
    "trapped": "Trapped Room.vox", "treasure": "Treasure.vox",
}


def find_file(roots, name):
    for r in roots:
        for d, _, files in os.walk(r):
            if name in files:
                return os.path.join(d, name)
    return None


def analyse(g):
    """Walk data from the voxel grid. Returns dict(T, walk, region) with T = floor top per column."""
    solid = g > 0
    nx, ny, nz = g.shape
    run = np.cumprod(solid, axis=2)
    T = run.sum(axis=2).astype(np.int32)                       # contiguous solid run from the bottom (floor slab, walls)
    zi = np.arange(nz)[None, None, :]
    obj = solid & (zi >= T[:, :, None])                         # everything not part of the slab: props, arches, torches
    cand = np.zeros((nx, ny), dtype=bool)
    for x in range(nx):
        for y in range(ny):
            t = int(T[x, y])
            if t <= 0:
                continue
            hi = min(nz, t + CLEAR)
            cand[x, y] = not obj[x, y, min(nz, t + LOW):hi].any()
    # largest connected region of cells joined by steps of at most STEP
    seen = np.zeros((nx, ny), dtype=bool)
    best = []
    for sx in range(nx):
        for sy in range(ny):
            if not cand[sx, sy] or seen[sx, sy]:
                continue
            comp, stack = [], [(sx, sy)]
            seen[sx, sy] = True
            while stack:
                x, y = stack.pop()
                comp.append((x, y))
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    X, Y = x + dx, y + dy
                    if 0 <= X < nx and 0 <= Y < ny and cand[X, Y] and not seen[X, Y] and abs(int(T[X, Y]) - int(T[x, y])) <= STEP:
                        seen[X, Y] = True
                        stack.append((X, Y))
            if len(comp) > len(best):
                best = comp
    walk = np.zeros((nx, ny), dtype=bool)
    for x, y in best:
        walk[x, y] = True
    # props: object voxels standing on floor-level columns (not wall decorations); they keep a one-cell margin so the hero never clips them
    base = int(T[walk].min()) if walk.any() else 0
    low = T <= base + 14
    props = obj & low[:, :, None]
    blocked = np.zeros((nx, ny), dtype=bool)
    pc = np.zeros((nx, ny), dtype=bool)
    for z in range(nz):
        pc |= props[:, :, z] & (z >= T + LOW) & (z < T + CLEAR + 4)
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            sh = np.zeros((nx, ny), dtype=bool)
            xs0, xs1 = max(0, dx), min(nx, nx + dx)
            ys0, ys1 = max(0, dy), min(ny, ny + dy)
            sh[xs0 - dx:xs1 - dx, ys0 - dy:ys1 - dy] = pc[xs0:xs1, ys0:ys1]
            blocked |= sh
    walk &= ~blocked
    return {"T": T, "obj": props, "walk": walk}


def build_room(rid, path, debug=False):
    models, pal = V.read_vox(path)
    size, vox = models[0]
    g = V.rotate_grid(V.to_grid(size, vox), 2)
    an = analyse(g)
    bg, pr = V.render_grid(g, pal, a=A)
    os.makedirs(OUT, exist_ok=True)
    bg.save(os.path.join(OUT, rid + ".png"))
    # occluder slices
    nx, ny, nz = g.shape
    slices = []
    obj = an["obj"]
    xs = np.arange(nx)[:, None, None]
    ys = np.arange(ny)[None, :, None]
    ssum = xs + ys
    for d0 in range(0, nx + ny, BAND):
        m = obj & (ssum >= d0) & (ssum < d0 + BAND)
        if not m.any():
            continue
        im, _ = V.render_grid(g, pal, a=A, only=m)
        bb = im.getbbox()
        if bb is None:
            continue
        k = len(slices)
        im.crop(bb).save(os.path.join(OUT, "%s_o%d.png" % (rid, k)))
        slices.append({"x": bb[0], "y": bb[1], "key": float(d0 + BAND * 0.5 + 1.0)})
    T, walk = an["T"], an["walk"]
    base = int(T[walk].min()) if walk.any() else 0
    rows, hrows = [], []
    for y in range(ny):
        rows.append("".join("." if walk[x, y] else "#" for x in range(nx)))
        hrows.append("".join(np.base_repr(min(35, max(0, int(T[x, y]) - base)), 36).lower() if walk[x, y] else "0" for x in range(nx)))
    meta = {
        "w": pr.w, "h": pr.h, "a": A, "ox": pr.ox, "oy": pr.oy, "kz": round(pr.kz, 4),
        "nx": nx, "ny": ny, "base": base, "walk": rows, "height": hrows, "slices": slices,
    }
    if debug:
        _debug(rid, bg, pr, an, base)
    return meta


def _debug(rid, bg, pr, an, base):
    im = bg.convert("RGBA")
    ov = Image.new("RGBA", im.size, (0, 0, 0, 0))
    dr = ImageDraw.Draw(ov)
    nx, ny = an["walk"].shape
    for x in range(nx):
        for y in range(ny):
            if an["walk"][x, y]:
                z = int(an["T"][x, y])
                p = [pr.pt(x, y, z), pr.pt(x + 1, y, z), pr.pt(x + 1, y + 1, z), pr.pt(x, y + 1, z)]
                dr.polygon(p, fill=(60, 255, 90, 90))
    for k in range(0, nx, 10):
        for j in range(0, ny, 10):
            if an["walk"][k, j]:
                p = pr.pt(k + 0.5, j + 0.5, int(an["T"][k, j]))
                dr.text((p[0] - 8, p[1] - 5), "%d,%d" % (k, j), fill=(255, 255, 255, 255))
    for k in range(5, 50, 5):
        p = pr.pt(0, k, base + 16)
        dr.text((p[0] - 6, p[1]), "y%d" % k, fill=(255, 80, 80, 255))
        p = pr.pt(k, 0, base + 16)
        dr.text((p[0] - 6, p[1]), "x%d" % k, fill=(80, 160, 255, 255))
    im.alpha_composite(ov)
    os.makedirs("/tmp/scene_debug", exist_ok=True)
    im.save("/tmp/scene_debug/%s.png" % rid)


def main():
    roots = [a for a in sys.argv[1:] if not a.startswith("--")]
    debug = "--debug" in sys.argv
    if not roots:
        print(__doc__)
        return 1
    out = {}
    for rid, fname in ROOMS.items():
        p = find_file(roots, fname)
        if p is None:
            print("skip (not found):", rid, fname)
            continue
        out[rid] = build_room(rid, p, debug)
        print("ok  %-9s %dx%d  slices=%d  walkable=%d" % (rid, out[rid]["w"], out[rid]["h"], len(out[rid]["slices"]), sum(r.count(".") for r in out[rid]["walk"])))
    with open(os.path.join(ROOT, "data", "rooms.json"), "w") as f:
        json.dump({"rooms": out}, f, separators=(",", ":"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
