#!/usr/bin/env python3
"""Checkpoint: make the project downloadable and resumable RIGHT NOW, finished or not (v0.7.0).

Run it after every finished sub-step (and always before a session ends):

    python3 -I tools/checkpoint.py --note "what is done / what is half done"
    python3 -I tools/checkpoint.py --done            # a finished release instead of a work-in-progress checkpoint

It does, in this order, and never stops half way:
  1. runs the static checker and the JSON validity check (the result is RECORDED, a failure does not block the checkpoint,
     because a broken-but-saved project is better than no project; the report says so loudly);
  2. writes docs/CHECKPOINT.md (version, time, lint and JSON result, your note, docs/WIP.md, features merged so far);
  3. builds Kindlewake_Project.zip with ONE top-level folder "Kindlewake/" (the phone build workflow needs that);
  4. copies docs/GDD.md -> GDD_Kindlewake.md and docs/CONTINUATION_PROMPT.md -> CONTINUATION_PROMPT.md;
  5. verifies the zip (integrity, required files) and prints the three paths.

Fixed file names, no versions in names (standing rule). Output folder: --out, else /mnt/user-data/outputs when it exists,
else <project>/../kindlewake_out. Stdlib only.
"""
import argparse
import datetime
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOP = "Kindlewake"
ZIP_NAME = "Kindlewake_Project.zip"
GDD_NAME = "GDD_Kindlewake.md"
PROMPT_NAME = "CONTINUATION_PROMPT.md"
EXCLUDE_DIRS = {".godot", "__pycache__", "dist", ".merge_backup", ".git", ".import", ".mono"}
EXCLUDE_SUFFIX = {".pyc", ".tmp", ".bak"}
EXCLUDE_NAMES = {".DS_Store", "Thumbs.db"}
EXCLUDE_ROOT_FILES = {ZIP_NAME, GDD_NAME, PROMPT_NAME}   # only the loose copies in the project ROOT (docs/CONTINUATION_PROMPT.md stays in)
REQUIRED = ["project.godot", "export_presets.cfg", "README.md", "docs/GDD.md", "docs/CONTINUATION_PROMPT.md",
            "docs/SESSION_HANDOFF.md", "tools/checkpoint.py", "tools/merge_features.py", "tools/gd_static_check.py",
            "data/world.json", "scripts/ui/world_scene.gd"]


def version() -> str:
    try:
        m = re.search(r'GAME_VERSION\s*:?=\s*"([^"]+)"', (ROOT / "scripts/core/save_system.gd").read_text(encoding="utf-8"))
        return m.group(1) if m else "?"
    except OSError:
        return "?"


def run_lint() -> dict:
    script = ROOT / "tools/gd_static_check.py"
    if not script.exists():
        return {"ran": False, "ok": False, "text": "tools/gd_static_check.py is missing"}
    p = subprocess.run([sys.executable, "-I", str(script)], cwd=str(ROOT), capture_output=True, text=True)
    out = (p.stdout + p.stderr).strip()
    m = re.search(r"errors:\s*(\d+)\s+warnings:\s*(\d+)", out)
    errors, warnings = (int(m.group(1)), int(m.group(2))) if m else (-1, -1)
    return {"ran": True, "ok": errors == 0 and warnings == 0, "errors": errors, "warnings": warnings,
            "text": out.splitlines()[-1] if out else "(no output)", "full": out}


def check_json() -> dict:
    bad = []
    n = 0
    for f in sorted((ROOT / "data").rglob("*.json")):
        n += 1
        try:
            json.loads(f.read_text(encoding="utf-8"))
        except (ValueError, OSError) as e:
            bad.append("%s: %s" % (f.relative_to(ROOT), e))
    return {"files": n, "bad": bad, "ok": not bad}


def feature_list() -> list:
    reg = ROOT / "docs/FEATURES.json"
    if not reg.exists():
        return []
    try:
        return json.loads(reg.read_text(encoding="utf-8")).get("applied", [])
    except (ValueError, OSError):
        return []


def write_checkpoint_doc(note: str, done: bool, lint: dict, js: dict) -> Path:
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines = ["# Checkpoint", "",
             "- **Status:** %s" % ("RELEASE (work for this step is finished)" if done else "WORK IN PROGRESS (resume with the steps below)"),
             "- **Game version:** %s" % version(),
             "- **Made:** %s" % now,
             "- **Static check:** %s%s" % (lint["text"], "" if lint["ok"] else "   <-- NOT CLEAN, fix this first"),
             "- **JSON data:** %d files, %s" % (js["files"], "all valid" if js["ok"] else "PROBLEMS: " + "; ".join(js["bad"])),
             "- **Run in Godot:** no (nothing has been executed in the engine; import first: `godot --headless --path . --import`)",
             ""]
    if note:
        lines += ["## Note from the session", "", note.strip(), ""]
    wip = ROOT / "docs/WIP.md"
    if wip.exists():
        lines += ["## Work in progress (docs/WIP.md)", "", wip.read_text(encoding="utf-8").strip(), ""]
    feats = feature_list()
    lines += ["## Features merged so far (docs/FEATURES.json)", ""]
    lines += ["- %s (%s)" % (f.get("id", "?"), f.get("version", "?")) for f in feats] or ["- none (the base project only)"]
    lines += ["", "## How to resume in a new chat", "",
              "1. Attach `Kindlewake_Project.zip`, `GDD_Kindlewake.md` and `CONTINUATION_PROMPT.md`; paste the prompt.",
              "2. Unzip, read `docs/CHECKPOINT.md` (this file), `docs/WIP.md` and `docs/SESSION_HANDOFF.md`.",
              "3. Run `python3 -I tools/gd_static_check.py` and finish whatever is listed as in progress.",
              "4. Features built in a separate chat arrive as `Feature_<id>.zip`: `python3 -I tools/merge_features.py apply Feature_<id>.zip` (dry run first).",
              ""]
    path = ROOT / "docs/CHECKPOINT.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def included(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    if len(rel.parts) == 1 and path.name in EXCLUDE_ROOT_FILES:
        return False
    return path.is_file() and path.name not in EXCLUDE_NAMES and path.suffix not in EXCLUDE_SUFFIX


def build_zip(out: Path) -> tuple:
    zpath = out / ZIP_NAME
    tmp = out / (ZIP_NAME + ".tmp")
    names = []
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for f in sorted(ROOT.rglob("*")):
            if included(f):
                arc = "%s/%s" % (TOP, f.relative_to(ROOT).as_posix())
                zf.write(f, arc)
                names.append(arc)
    tmp.replace(zpath)
    return zpath, names


def verify_zip(zpath: Path, names: list) -> list:
    problems = []
    with zipfile.ZipFile(zpath) as zf:
        bad = zf.testzip()
        if bad:
            problems.append("corrupt entry: " + bad)
        have = set(zf.namelist())
    for r in REQUIRED:
        if "%s/%s" % (TOP, r) not in have:
            problems.append("missing from the zip: " + r)
    if any(not n.startswith(TOP + "/") for n in have):
        problems.append("an entry is outside the top-level folder")
    return problems


def main() -> int:
    ap = argparse.ArgumentParser(description="Build a downloadable, resumable checkpoint of the project.")
    ap.add_argument("--note", default="", help="what is done and what is half done")
    ap.add_argument("--done", action="store_true", help="mark this as a finished release instead of work in progress")
    ap.add_argument("--out", default="", help="output folder (default: /mnt/user-data/outputs, else ../kindlewake_out)")
    args = ap.parse_args()

    out = Path(args.out) if args.out else (Path("/mnt/user-data/outputs") if Path("/mnt/user-data/outputs").is_dir() else ROOT.parent / "kindlewake_out")
    out.mkdir(parents=True, exist_ok=True)

    lint = run_lint()
    js = check_json()
    write_checkpoint_doc(args.note, args.done, lint, js)
    zpath, names = build_zip(out)
    (out / GDD_NAME).write_bytes((ROOT / "docs/GDD.md").read_bytes())
    (out / PROMPT_NAME).write_bytes((ROOT / "docs/CONTINUATION_PROMPT.md").read_bytes())
    problems = verify_zip(zpath, names)

    digest = hashlib.sha256(zpath.read_bytes()).hexdigest()[:16]
    print("checkpoint: %s  version %s  (%s)" % ("RELEASE" if args.done else "work in progress", version(), datetime.date.today()))
    print("static check: %s" % lint["text"])
    print("json: %d files, %s" % (js["files"], "all valid" if js["ok"] else "PROBLEMS " + "; ".join(js["bad"])))
    print("zip: %s  (%d files, %.1f MB, sha256 %s)" % (zpath, len(names), zpath.stat().st_size / 1048576.0, digest))
    print("docs: %s, %s" % (out / GDD_NAME, out / PROMPT_NAME))
    if problems:
        print("ZIP PROBLEMS:")
        for p in problems:
            print("  - " + p)
        return 2
    if not lint["ok"] or not js["ok"]:
        print("saved, but NOT CLEAN (see above): fix before building the APK")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
