#!/usr/bin/env python3
"""Kindlewake world generator (v0.7.0).

Writes data/world_map.json (terrain + region layers, 452 x 340 tiles = about 50x the old 64 x 48 map)
and data/world.json (regions, 39 places, road list). Deterministic: the same SEED always gives the same world.
Run:  python3 tools/make_world.py          (needs numpy; takes about 20-60 s)
The game never runs this; it only reads the two JSON files. Edit PLACES / REGIONS below and re-run to change the world.
"""
import base64
import heapq
import json
import math
import os
import sys

import numpy as np

W, H = 452, 340
SEED = 1187
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")

GRASS, FOREST, HILL, FORD, WATER, MOUNTAIN, ROAD, BRIDGE, SAND, SNOW, MARSH = range(11)
WALK_COST = {GRASS: 1.0, FOREST: 3.5, HILL: 3.0, FORD: 2.0, WATER: 11.0, MOUNTAIN: 80.0, ROAD: 0.35,
             BRIDGE: 0.35, SAND: 1.0, SNOW: 1.7, MARSH: 3.0}
BLOCKED = {WATER, MOUNTAIN}

# id, name, centre, danger tier (1 easiest), floor tile, text
REGIONS = [
    ("sethmarch", "Sethmarch", (75, 275), 1, GRASS, "The Sallow Marches around Kaer Sethorn: wet meadows, reeds and roadwolves."),
    ("orrowen", "Orrowen Weald", (75, 160), 2, GRASS, "Yeoman forest of House Orrowen. Poachers, outlaws and the best archers in Eldrimar."),
    ("ysmark", "Ysmark Coast", (250, 295), 2, GRASS, "Salt marsh, cliffs and the ports of House Ysmark. Gold buys most things here."),
    ("aurelmont", "Aurelmont", (250, 175), 3, GRASS, "The crown lands around the capital. The Regency's patrols watch every road."),
    ("vessmoor", "Vessmoor Plains", (385, 245), 3, SAND, "Dust, wind and horse-lords. Honour is settled in duels and sandstorms."),
    ("tarnholt", "Tarnholt Cloisters", (245, 55), 4, GRASS, "Monastery roads and relic shrines. Faith is law, and some of the faithful are armed."),
    ("quillon", "Quillon Heights", (380, 70), 4, GRASS, "Windswept scholars' hills. Some of the books bite back."),
    ("brennhallow", "Brennhallow Highlands", (105, 45), 5, SNOW, "Snow, iron and the fortress marches of the Lord Regent."),
]

RUMOURS = {
    "sethmarch": [
        "They say Hask Gravelteeth was a Dunmarrow sergeant once. He kept the road until the coin stopped coming.",
        "The marsh gives back what you drop in it, but never in the same shape. Mind the reeds after dark.",
        "Old folk swear the Dunmarrow signet still opens a door somewhere in Aurelmont.",
        "A peddler at the ford swears the Regent's riders are asking about Torren by name."],
    "orrowen": [
        "The Greenhood outlaws shoot only at men in mail. Plain cloth walks free, mostly.",
        "Lucan Thorne keeps the Weald's old oaths. Do him a favour and he will remember it.",
        "Orrowen bowyers hide the best staves in hollow oaks. Poachers know which ones.",
        "There is a Codicil, the woodcutters whisper, and King Osric's keeper died for it."],
    "ysmark": [
        "Lady Sabela buys debts the way other lords buy horses. Be careful what you sign.",
        "Smugglers in the cove pay the harbour watch twice: once in coin, once in silence.",
        "A wreck on the western strand still has cargo in the hold. The gulls guard it well.",
        "Ships from the east carry rumours of the Covenant of the Seven Flames."],
    "aurelmont": [
        "The capital's throne stands empty. The Regency calls it 'waiting'. Everyone else has other words.",
        "Deserters from Osric's Field have turned the crossroads into a toll road.",
        "Brennhallow banners fly over the palace. Not one noble will say who pays for them.",
        "Half the court has a spy and the other half is one."],
    "vessmoor": [
        "A Vessmoor duel ends at first blood or last breath. Be certain which you agreed to.",
        "The horse-lords bury their riders with their tack. The barrows are rich and cursed.",
        "Dust-riders watch the caravan road from the dry-wash. They count your mules before they count you.",
        "Lady Isaure was disinherited for refusing a marriage. Her kin still ride in her name."],
    "tarnholt": [
        "The abbey's lamps are lit by the Archprelate's own hand. Nobody asks what they burn.",
        "Pilgrims have gone missing on the relic road. The monks say they chose to stay.",
        "Sister Odalys left the inquisition. The inquisition has not left her.",
        "A relic in the Broken Reliquary is said to answer only to a Dunmarrow."],
    "quillon": [
        "Quillon scholars sell lenses to see the stars and charms to ignore them.",
        "A sealed vault above Starwick has cracked from the inside. The librarians have stopped talking about it.",
        "The Flamebearer fire gives no heat. Those who stand near it stop shivering. They stop everything else, too.",
        "Somewhere in the Tower a seal holds the Hidden Codicil. Ask the right librarian the wrong question."],
    "brennhallow": [
        "Brennhold has not lost a siege in two hundred years. The Regent intends to keep that record.",
        "Black Lancers ride the passes by night. Do not light a fire where they can see it.",
        "Maelor Brennhallow is no tyrant, the old soldiers say. That is what makes it so hard.",
        "A warden left his coat in a cairn on the ridge. The wind keeps the secret."],
}

# id, name, kind, (x, y), text, extra   kind: keep / city / town / village / ruin / camp
PLACES = [
    # --- Sethmarch (tier 1)
    ("sethorn", "Kaer Sethorn", "keep", (60, 290), "The broken keep of House Dunmarrow. Torren's company rests here, sorts its gear and counts its coin.", {}),
    ("crossing", "Sallow Crossing", "village", (105, 262), "A ford village where carters, peddlers and rumours meet.", {}),
    ("marrowmill", "Marrow Mill", "village", (40, 245), "A water-mill village. The miller grinds more rumour than flour.", {}),
    ("watch", "Old Watchtower", "ruin", (112, 224), "A fallen border tower. Someone hid a purse in the cellar long ago.", {"reward_gold": 60}),
    ("roadwolf_camp", "Roadwolf Camp", "camp", (146, 246), "Hask Gravelteeth's raiders hold the road to Eldrimar from this palisade.", {"group": "hask_band"}),
    ("barrow", "Dunmarrow Barrow", "ruin", (28, 322), "The family barrow. Torren's ancestors sleep here beside their grave goods.", {"reward_gold": 80, "reward_item": "iron_ring"}),
    # --- Orrowen Weald (tier 2)
    ("orrowen_hall", "Orrowen Hall", "city", (72, 150), "The oak-beamed seat of House Orrowen. Archers drill on the green, and every tavern has a bow over the fire.", {}),
    ("thornwick", "Thornwick", "village", (112, 188), "A hedge-ringed village of woodcutters and charcoal burners.", {}),
    ("yewgate", "Yewgate", "village", (34, 192), "Two ancient yews mark the gate. Travellers leave coins in their roots.", {}),
    ("hollow_oak", "Hollow Oak", "ruin", (96, 118), "A hollow tree the size of a barn. Poachers stash their loot inside.", {"reward_gold": 120, "reward_item": "short_bow"}),
    ("greenhood_camp", "Greenhood Camp", "camp", (52, 112), "Outlaw archers raid the weald from a camp hidden in the brambles.", {"group": "greenhood_band"}),
    # --- Brennhallow Highlands (tier 5)
    ("brennhold", "Brennhold", "city", (92, 52), "The iron tower on black rock. The Lord Regent's seat, and a city that never sleeps.", {}),
    ("ironford", "Ironford", "town", (152, 78), "A forge-town on the Black Stair. Everything here is hammered, including the gossip.", {}),
    ("cairnwatch", "Cairnwatch", "ruin", (40, 72), "A ring of cairns on a wind-scoured ridge. The wardens left their last orders here.", {"reward_gold": 300, "reward_item": "warden_coat"}),
    ("blackcrag_camp", "Blackcrag Fastness", "camp", (134, 28), "An iron-knight garrison that answers to no captain but the Regent.", {"group": "blackcrag_garrison"}),
    # --- Tarnholt Cloisters (tier 4)
    ("tarnholt_abbey", "Tarnholt Abbey", "city", (240, 56), "A white-walled abbey where the Archprelate's lamps burn all night.", {}),
    ("candlemere", "Candlemere", "village", (204, 92), "A lakeside village of candle-makers and pilgrims.", {}),
    ("saints_vale", "Saint's Vale", "village", (286, 36), "A hillside hamlet living off the shrine road.", {}),
    ("reliquary_ruin", "Broken Reliquary", "ruin", (262, 98), "A looted reliquary. The faithful say a relic is still hidden in the crypt.", {"reward_gold": 220, "reward_item": "pilgrim_medal"}),
    # --- Quillon Heights (tier 4)
    ("quillon_tower", "Quillon Tower", "city", (386, 70), "A tower-city of scholars. Every window is a library and every library is locked.", {}),
    ("starwick", "Starwick", "village", (340, 112), "Observatory village; the astronomers sell lenses and complaints.", {}),
    ("inkwell", "Inkwell", "village", (430, 42), "A quiet village that makes the ink for half of Eldrimar.", {}),
    ("sealed_vault", "Sealed Vault", "ruin", (412, 124), "A vault with a seal that has been cracked from the inside.", {"reward_gold": 260, "reward_item": "scholar_ring"}),
    ("flamebearer_camp", "Flamebearer Camp", "camp", (352, 38), "Cultists of the Seven Flames gather around a bonfire that gives no heat.", {"group": "flame_cult"}),
    # --- Aurelmont (tier 3)
    ("aurelmont", "Aurelmont", "city", (250, 176), "The capital: white stone, red banners and a throne with nobody on it.", {}),
    ("kingsway", "Kingsway Inn", "town", (200, 150), "A walled coaching inn on the great road. Every faction has a spy at the bar.", {}),
    ("harrowgate", "Harrowgate", "town", (300, 202), "A grain-market town that sells to whoever pays on the day.", {}),
    ("osrics_field", "Osric's Field", "ruin", (214, 208), "The old battlefield where King Osric's last army broke. Relics still surface in the plough.", {"reward_gold": 180, "reward_item": "chain_surcoat"}),
    ("deserter_camp", "Deserters' Camp", "camp", (272, 136), "Regency deserters have turned bandit and hold the crossroads.", {"group": "deserter_band"}),
    # --- Vessmoor Plains (tier 3)
    ("cindermead", "Cindermead", "city", (388, 236), "A city of mud-brick towers and horse-markets on the ash plain.", {}),
    ("dustwell", "Dustwell", "village", (340, 206), "A well, a stable and a very old argument.", {}),
    ("saddleback", "Saddleback", "village", (432, 272), "Horse-breeders' camp turned village. The foals are worth more than the huts.", {}),
    ("horsebone_barrows", "Horsebone Barrows", "ruin", (402, 192), "Burial mounds of the first horse-lords. Their riding gear was buried with them.", {"reward_gold": 200, "reward_item": "falchion"}),
    ("sandjackal_camp", "Sandjackal Camp", "camp", (362, 292), "Dust-riders raid the caravan road from a dry-wash fortress.", {"group": "sandjackal_band"}),
    # --- Ysmark Coast (tier 2)
    ("brinegate", "Brinegate", "city", (252, 302), "The port city of House Ysmark: ships, warehouses and ledgers deeper than the harbour.", {}),
    ("salt_market", "Salt Market", "town", (200, 270), "A market town on the salt flats. Everything is priced in pinches.", {}),
    ("gullrock", "Gullrock", "village", (304, 316), "Fishermen, gulls and one good tavern.", {}),
    ("gilded_hind", "Wreck of the Gilded Hind", "ruin", (176, 316), "A beached merchantman. The hold was never fully emptied.", {"reward_gold": 150, "reward_item": "dirk"}),
    ("smugglers_cove", "Smugglers' Cove", "camp", (322, 286), "Smugglers and cutthroats run contraband through a cliff cave.", {"group": "smuggler_band"}),
]

# Road links between settlements (cities, towns, villages, keep). Extra ruin/camp tracks are added automatically.
SETTLEMENT_KINDS = {"keep", "city", "town", "village"}
EXTRA_LINKS = [("crossing", "salt_market"), ("kingsway", "orrowen_hall"), ("aurelmont", "harrowgate"),
               ("harrowgate", "cindermead"), ("tarnholt_abbey", "aurelmont"), ("quillon_tower", "tarnholt_abbey"),
               ("ironford", "tarnholt_abbey"), ("brennhold", "orrowen_hall"), ("brinegate", "harrowgate"),
               ("dustwell", "starwick")]


# ------------------------------------------------------------------ noise
def vnoise(w, h, scale, seed):
    """Smooth value noise in 0..1, shape (h, w)."""
    rs = np.random.RandomState(seed)
    gw, gh = int(w / scale) + 3, int(h / scale) + 3
    grid = rs.rand(gh, gw)
    ys = np.arange(h) / scale
    xs = np.arange(w) / scale
    iy = ys.astype(int)
    ix = xs.astype(int)
    fy = ys - iy
    fx = xs - ix
    fy = fy * fy * (3 - 2 * fy)
    fx = fx * fx * (3 - 2 * fx)
    a = grid[iy][:, ix] * (1 - fx)[None, :] + grid[iy][:, ix + 1] * fx[None, :]
    b = grid[iy + 1][:, ix] * (1 - fx)[None, :] + grid[iy + 1][:, ix + 1] * fx[None, :]
    return a * (1 - fy)[:, None] + b * fy[:, None]


def fractal(w, h, scales, weights, seed):
    out = np.zeros((h, w))
    for i, (s, wt) in enumerate(zip(scales, weights)):
        out += vnoise(w, h, s, seed + 17 * i) * wt
    return out / sum(weights)


# ------------------------------------------------------------------ generation
def build_regions(warp_x, warp_y):
    yy, xx = np.mgrid[0:H, 0:W]
    px = xx + (warp_x - 0.5) * 70.0
    py = yy + (warp_y - 0.5) * 70.0
    dist = np.stack([np.hypot(px - c[0], py - c[1]) for (_i, _n, c, _t, _f, _x) in REGIONS])
    return np.argmin(dist, axis=0).astype(np.uint8)


def build_terrain(region):
    e = fractal(W, H, (60, 24, 9, 4), (0.4, 0.3, 0.2, 0.1), SEED)
    wet = fractal(W, H, (40, 16, 6), (0.5, 0.3, 0.2), SEED + 31)
    dry = fractal(W, H, (22, 8), (0.6, 0.4), SEED + 53)
    ridge1 = np.abs(fractal(W, H, (70, 30), (0.7, 0.3), SEED + 71) - 0.5)
    ridge2 = np.abs(fractal(W, H, (90, 35), (0.7, 0.3), SEED + 97) - 0.5)
    ford_n = vnoise(W, H, 7, SEED + 111)
    edge_n = vnoise(W, H, 6, SEED + 131)
    sea_n = vnoise(W, H, 40, SEED + 151)
    yy, xx = np.mgrid[0:H, 0:W]
    ridx = {r[0]: i for i, r in enumerate(REGIONS)}
    reg_arr = region
    e_bias = np.zeros((H, W))
    e_bias[reg_arr == ridx["brennhallow"]] += 0.13
    e_bias[reg_arr == ridx["quillon"]] += 0.08
    e_bias[reg_arr == ridx["tarnholt"]] += 0.02
    e_bias[reg_arr == ridx["vessmoor"]] += 0.03
    e_bias[reg_arr == ridx["orrowen"]] -= 0.02
    e = e + e_bias

    t = np.full((H, W), GRASS, dtype=np.uint8)
    forest_thr = np.full((H, W), 0.64)
    forest_thr[reg_arr == ridx["orrowen"]] = 0.46
    forest_thr[reg_arr == ridx["sethmarch"]] = 0.58
    forest_thr[reg_arr == ridx["vessmoor"]] = 0.80
    forest_thr[reg_arr == ridx["brennhallow"]] = 0.68
    forest_thr[reg_arr == ridx["quillon"]] = 0.62
    forest_thr[reg_arr == ridx["ysmark"]] = 0.64
    hill_thr = np.full((H, W), 0.66)
    hill_thr[reg_arr == ridx["brennhallow"]] = 0.58
    hill_thr[reg_arr == ridx["quillon"]] = 0.56
    mount_thr = np.full((H, W), 0.80)
    mount_thr[reg_arr == ridx["brennhallow"]] = 0.72
    mount_thr[reg_arr == ridx["quillon"]] = 0.74
    mount_thr[reg_arr == ridx["vessmoor"]] = 0.78

    t[wet > forest_thr] = FOREST
    t[e > hill_thr] = HILL
    # floor tiles of the dry and snowy regions
    sand_mask = (reg_arr == ridx["vessmoor"]) & (dry > 0.30)
    t[sand_mask & (t == GRASS)] = SAND
    snow_mask = (reg_arr == ridx["brennhallow"]) & (dry > 0.18)
    t[snow_mask & (t == GRASS)] = SNOW
    snow_peaks = (reg_arr == ridx["quillon"]) & (e > 0.64) & (t == GRASS)
    t[snow_peaks] = SNOW
    # marsh in Sethmarch and Ysmark salt flats
    marsh = ((reg_arr == ridx["sethmarch"]) & (wet > 0.46) & (e < 0.58)) | ((reg_arr == ridx["ysmark"]) & (wet > 0.52) & (e < 0.52))
    t[marsh & (t == GRASS)] = MARSH
    # lakes and rivers
    t[e < 0.27] = WATER
    river = (ridge1 < 0.010) | (ridge2 < 0.008)
    river[reg_arr == ridx["vessmoor"]] = (ridge1 < 0.0035)[reg_arr == ridx["vessmoor"]]   # a dry land has few rivers
    t[river & (t != MOUNTAIN)] = WATER
    t[(t == WATER) & (ford_n > 0.70)] = FORD
    t[(e >= 0.27) & (e < 0.30) & (t == GRASS)] = FORD
    # mountains
    t[e > mount_thr] = MOUNTAIN
    # southern sea (Ysmark coast)
    sea_line = 326 + (sea_n - 0.5) * 16
    sea = (yy > sea_line) & (xx > 130)
    t[sea] = WATER
    # edge wall
    edge = np.minimum(np.minimum(xx, W - 1 - xx), np.minimum(yy, H - 1 - yy))
    t[edge < 2 + (edge_n * 4).astype(int)] = MOUNTAIN
    t[:, :1] = MOUNTAIN
    t[:, -1:] = MOUNTAIN
    t[:1, :] = MOUNTAIN
    t[-1:, :] = MOUNTAIN
    return t


def hash01(x, y, s):
    h = (x * 374761393 + y * 668265263 + s * 1442695041) & 0x7FFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0x7FFFFFFF
    h ^= h >> 16
    return (h & 0xFFFF) / 65535.0


def astar_road(tiles, a, b, seed):
    """4-connected least-cost path from a to b (x, y). Returns the list of cells."""
    w, h = W, H
    cost = [[WALK_COST[int(tiles[y][x])] for x in range(w)] for y in range(h)]
    bx, by = b
    open_heap = [(0.0, 0.0, a[0], a[1])]
    best = {a: 0.0}
    came = {}
    min_c = 0.35
    while open_heap:
        _f, g, x, y = heapq.heappop(open_heap)
        if (x, y) == b:
            break
        if g > best.get((x, y), 1e18):
            continue
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if nx < 1 or ny < 1 or nx >= w - 1 or ny >= h - 1:
                continue
            step = cost[ny][nx] * (1.0 + 0.6 * hash01(nx, ny, seed))
            ng = g + step
            if ng < best.get((nx, ny), 1e18):
                best[(nx, ny)] = ng
                came[(nx, ny)] = (x, y)
                heapq.heappush(open_heap, (ng + min_c * (abs(bx - nx) + abs(by - ny)), ng, nx, ny))
    path = [b]
    cur = b
    while cur != a:
        cur = came[cur]
        path.append(cur)
    path.reverse()
    return path


def carve(tiles, path):
    for (x, y) in path:
        t = int(tiles[y][x])
        if t in (WATER, FORD):
            tiles[y][x] = BRIDGE
        elif t != BRIDGE:
            tiles[y][x] = ROAD


def mst_edges(items):
    """Prim minimum spanning tree over [(id, (x, y))]."""
    ids = [i for i, _ in items]
    pos = dict(items)
    in_tree = {ids[0]}
    edges = []
    while len(in_tree) < len(ids):
        best = None
        for a in in_tree:
            for b in ids:
                if b in in_tree:
                    continue
                d = math.hypot(pos[a][0] - pos[b][0], pos[a][1] - pos[b][1])
                if best is None or d < best[0]:
                    best = (d, a, b)
        in_tree.add(best[2])
        edges.append((best[1], best[2]))
    return edges


def main():
    print("noise ...", flush=True)
    wx = vnoise(W, H, 55, SEED + 201)
    wy = vnoise(W, H, 55, SEED + 202)
    region = build_regions(wx, wy)
    tiles = build_terrain(region)
    floor_by_region = [r[4] for r in REGIONS]
    # clear a meadow around every place
    print("places ...", flush=True)
    pos = {}
    for (pid, _name, kind, (x, y), _text, _extra) in PLACES:
        pos[pid] = (x, y)
        rad = 3 if kind in ("city", "keep") else 2 if kind in ("town", "village") else 1
        fl = floor_by_region[int(region[y][x])]
        for dy in range(-rad, rad + 1):
            for dx in range(-rad, rad + 1):
                cx, cy = x + dx, y + dy
                if 2 <= cx < W - 2 and 2 <= cy < H - 2:
                    tiles[cy][cx] = fl
    settle = [(p[0], p[3]) for p in PLACES if p[2] in SETTLEMENT_KINDS]
    links = mst_edges(settle) + [l for l in EXTRA_LINKS]
    # ruins and camps get a track to their nearest settlement
    tracks = []
    for p in PLACES:
        if p[2] in SETTLEMENT_KINDS:
            continue
        best = min(settle, key=lambda s: math.hypot(s[1][0] - p[3][0], s[1][1] - p[3][1]))
        tracks.append((best[0], p[0]))
    all_links = links + tracks
    print("roads (%d) ..." % len(all_links), flush=True)
    for i, (a, b) in enumerate(all_links):
        carve(tiles, astar_road(tiles, pos[a], pos[b], SEED + 99))
        print("  %d/%d %s - %s" % (i + 1, len(all_links), a, b), flush=True)
    for pid, (x, y) in pos.items():
        tiles[y][x] = ROAD
    # ---- validation
    print("validating ...", flush=True)
    walk = np.isin(tiles, [WATER, MOUNTAIN], invert=True)
    start = pos["sethorn"]
    seen = np.zeros((H, W), dtype=bool)
    stack = [start]
    seen[start[1]][start[0]] = True
    while stack:
        x, y = stack.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and walk[ny][nx] and not seen[ny][nx]:
                seen[ny][nx] = True
                stack.append((nx, ny))
    bad = [pid for pid, (x, y) in pos.items() if not seen[y][x]]
    if bad:
        print("ERROR: unreachable places:", bad)
        sys.exit(1)
    print("all %d places reachable from Kaer Sethorn" % len(pos))
    print("walkable %.1f%%, reachable %.1f%% of all tiles" % (100.0 * walk.mean(), 100.0 * seen.mean()))
    names = ["grass", "forest", "hill", "ford", "water", "mountain", "road", "bridge", "sand", "snow", "marsh"]
    for i, n in enumerate(names):
        print("  %-9s %5.1f%%" % (n, 100.0 * (tiles == i).mean()))
    for i, r in enumerate(REGIONS):
        m = region == i
        print("  region %-12s %5d tiles, reachable %.0f%%" % (r[0], int(m.sum()), 100.0 * (seen & m).sum() / max(1, m.sum())))
    # ---- write files
    # Raw bytes (row by row, one byte per tile) as base64: the game decodes it with ONE call (Marshalls.base64_to_raw).
    map_json = {
        "width": W, "height": H, "seed": SEED,
        "tiles_b64": base64.b64encode(tiles.astype(np.uint8).tobytes()).decode("ascii"),
        "regions_b64": base64.b64encode(region.astype(np.uint8).tobytes()).decode("ascii"),
    }
    with open(os.path.join(ROOT, "data", "world_map.json"), "w") as f:
        json.dump(map_json, f, separators=(",", ":"))
    places = []
    for (pid, name, kind, (x, y), text, extra) in PLACES:
        d = {"id": pid, "name": name, "kind": kind, "cell": [x, y], "region": REGIONS[int(region[y][x])][0], "text": text}
        d.update(extra)
        places.append(d)
    world = {
        "name": "Eldrimar",
        "seed": SEED, "width": W, "height": H, "map_file": "world_map.json",
        "start": "sethorn", "safe_radius": 6,
        "encounter_min": 1000, "encounter_max": 2000,
        "regions": [{"id": r[0], "name": r[1], "tier": r[3], "text": r[5], "center": list(r[2]), "rumours": RUMOURS[r[0]]} for r in REGIONS],
        "places": places,
        "roads": [list(l) for l in all_links],
    }
    with open(os.path.join(ROOT, "data", "world.json"), "w") as f:
        json.dump(world, f, indent=1)
    print("wrote data/world_map.json and data/world.json")


if __name__ == "__main__":
    main()
