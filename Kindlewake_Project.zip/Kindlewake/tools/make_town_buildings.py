#!/usr/bin/env python3
"""Build authored, data-driven settlement silhouettes from the supplied voxel sprites.

Run: python3 -I tools/make_town_buildings.py [--check]
No packages or network access required.
"""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORLD = ROOT / "data/world.json"
OUT = ROOT / "data/town_buildings.json"
SPRITES = ROOT / "assets/sprites/world"

# Each entry is [sprite stem, x offset, y offset] relative to the settlement marker.
# These are intentionally hand-authored: the landmark silhouette should identify the place.
LAYOUTS = {
    "sethorn": ("Dunmarrow keep", [["tall3", 0, 4], ["tall1", -58, 18], ["tall2", 60, 18], ["large1", 0, 42], ["small4", -34, 58]]),
    "crossing": ("ford village", [["small1", -34, 8], ["tiny", 32, 4], ["small3", 0, 28], ["tiny", 58, 28]]),
    "marrowmill": ("mill village", [["small3", -28, 16], ["tall1", 24, 4], ["small1", 46, 32], ["tiny", -54, 34]]),
    "orrowen_hall": ("oak hall", [["tall2", -48, 2], ["tall1", 48, 4], ["large1", 0, 34], ["small4", -78, 44], ["small3", 76, 48], ["tiny", 18, 62]]),
    "thornwick": ("hedge village", [["small1", -38, 10], ["small4", 4, 18], ["tiny", 44, 8], ["small3", 24, 42]]),
    "yewgate": ("yewstead", [["tall1", -30, 0], ["small3", 26, 18], ["small1", 56, 32], ["tiny", -58, 34]]),
    "brennhold": ("regent citadel", [["tall3", -54, 0], ["tall2", 54, 0], ["tall1", 0, 4], ["large1", 0, 42], ["small4", -84, 48], ["small3", 82, 52]]),
    "ironford": ("forge town", [["large1", -4, 10], ["tall1", 48, 0], ["small4", -54, 34], ["small1", 52, 40], ["tiny", 4, 58]]),
    "tarnholt_abbey": ("white abbey", [["tall2", -54, 0], ["tall2", 54, 0], ["tall1", 0, -8], ["large1", 0, 38], ["small4", -82, 52], ["small3", 82, 52]]),
    "candlemere": ("lakeside village", [["small3", -34, 8], ["small1", 20, 20], ["tiny", 54, 2], ["small4", 0, 46]]),
    "saints_vale": ("shrine hamlet", [["tall1", 0, -2], ["small1", -38, 24], ["small3", 36, 26], ["tiny", 62, 44]]),
    "quillon_tower": ("scholar tower", [["tall3", 0, -12], ["tall2", -60, 10], ["tall1", 60, 10], ["large1", 0, 42], ["small4", -86, 56], ["small3", 84, 56]]),
    "starwick": ("observatory village", [["tall1", 0, -4], ["small3", -40, 22], ["small1", 36, 26], ["tiny", 68, 40]]),
    "inkwell": ("inkmakers village", [["small4", -36, 10], ["small1", 18, 18], ["small3", 54, 36], ["tiny", -62, 38]]),
    "aurelmont": ("capital", [["tall3", 0, -10], ["tall2", -68, 6], ["tall1", 68, 6], ["large1", 0, 48], ["small4", -96, 58], ["small3", 94, 60], ["tiny", 30, 72]]),
    "kingsway": ("coaching inn", [["large1", 0, 10], ["small4", -50, 30], ["small1", 52, 30], ["tiny", 0, 58]]),
    "harrowgate": ("grain market", [["large1", -18, 8], ["small3", 42, 18], ["small1", -62, 32], ["small4", 24, 48], ["tiny", 68, 48]]),
    "cindermead": ("mudbrick city", [["tall1", -58, 4], ["tall2", 58, 6], ["large1", 0, 34], ["small1", -78, 46], ["small4", 76, 46], ["tiny", 18, 62]]),
    "dustwell": ("well hamlet", [["small1", -30, 14], ["small4", 26, 16], ["tiny", 0, 34], ["small3", 48, 42]]),
    "saddleback": ("horse village", [["small3", -42, 12], ["small1", 12, 18], ["small4", 54, 34], ["tiny", -8, 48]]),
    "brinegate": ("port city", [["tall2", -62, 0], ["tall1", 60, 0], ["large1", 0, 30], ["small4", -88, 48], ["small1", 84, 46], ["tiny", 18, 66]]),
    "salt_market": ("salt market", [["large1", -8, 8], ["small1", -58, 28], ["small4", 42, 24], ["small3", 18, 48], ["tiny", 68, 48]]),
    "gullrock": ("fishing village", [["small1", -36, 12], ["small3", 16, 18], ["tiny", 54, 8], ["small4", 0, 44]]),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    world = json.loads(WORLD.read_text(encoding="utf-8"))
    places = {p["id"]: p for p in world.get("places", []) if p.get("kind") in {"keep", "city", "town", "village"}}
    errors = []
    for pid in sorted(set(places) - set(LAYOUTS)):
        errors.append(f"missing authored layout: {pid}")
    for pid in sorted(set(LAYOUTS) - set(places)):
        errors.append(f"layout references non-settlement: {pid}")
    palettes = {"sethmarch": "thatch", "orrowen": "thatch", "ysmark": "thatch", "aurelmont": "stone", "vessmoor": "sand", "tarnholt": "stone", "quillon": "stone", "brennhallow": "slate"}
    payload = {"version": 1, "source": "supplied voxel building sprites", "places": {}}
    for pid, (style, buildings) in LAYOUTS.items():
        p = places.get(pid, {})
        palette = "stone" if p.get("kind") == "keep" else palettes.get(p.get("region"), "stone")
        if not 3 <= len(buildings) <= 7:
            errors.append(f"{pid}: expected 3-7 buildings, got {len(buildings)}")
        out = []
        for sprite, x, y in buildings:
            path = SPRITES / f"{sprite}_{palette}.png"
            if not path.is_file():
                errors.append(f"{pid}: missing sprite {path.name}")
            out.append({"sprite": sprite, "x": x, "y": y})
        payload["places"][pid] = {"style": style, "palette": palette, "buildings": out}
    if errors:
        raise SystemExit("\n".join(errors))
    if args.check:
        print(f"OK: {len(payload['places'])} authored settlement layouts; all building sprites exist")
        return
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {OUT.relative_to(ROOT)} ({len(payload['places'])} settlements)")


if __name__ == "__main__":
    main()
