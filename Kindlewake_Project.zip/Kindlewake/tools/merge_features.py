#!/usr/bin/env python3
"""Feature packs: build a feature in one chat, merge it into the project in another (v0.7.0). Stdlib only.

    python3 -I tools/merge_features.py pack  --base <old project dir|zip> --new <new project dir|zip> --id <name> [--version 1] [--notes "..."]
    python3 -I tools/merge_features.py apply <Feature_name.zip>            # DRY RUN: shows what would happen
    python3 -I tools/merge_features.py apply <Feature_name.zip> --apply    # does it (backups in .merge_backup/<id>/)
    python3 -I tools/merge_features.py list                                # features merged so far

A pack (`Feature_<id>.zip`, no version in the file name) holds `feature.json` plus every file the feature added or changed
(`files/<path>`) and, for changed data/*.json files, the old copy (`base/<path>`) so JSON can be merged three ways.

Merge rules, per file:
  * not in the project            -> added
  * identical                     -> skipped
  * project copy still equals the pack's base -> updated (fast-forward)
  * data/*.json changed on both sides -> three-way merge by key (lists of {"id":...} objects are merged by id);
        a clash on the same value is a CONFLICT
  * anything else changed on both sides -> CONFLICT
A conflict NEVER overwrites your file: the incoming copy is written next to it as `<file>.incoming` (and listed in
docs/CHECKPOINT.md) so the next session can merge by hand. `--force` takes the incoming copy instead (after a backup).
Deletions in a pack are only reported; `--allow-delete` performs them. Applying the same id twice is refused (`--force`).
Docs (GDD, handoff, prompt, README) usually conflict: merge their text by hand and bump the GDD revision log.
"""
import argparse
import datetime
import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOP = "Kindlewake"
EXCLUDE_DIRS = {".godot", "__pycache__", "dist", ".merge_backup", ".git", ".import", ".mono"}
SKIP_FILES = {"docs/CHECKPOINT.md", "docs/FEATURES.json"}
ROOT_ONLY_SKIP = {"Kindlewake_Project.zip", "GDD_Kindlewake.md", "CONTINUATION_PROMPT.md"}
MISSING = object()


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def skip(rel: str) -> bool:
    parts = rel.split("/")
    if any(p in EXCLUDE_DIRS for p in parts):
        return True
    if len(parts) == 1 and parts[0] in ROOT_ONLY_SKIP:
        return True
    return rel in SKIP_FILES or parts[-1] in (".DS_Store", "Thumbs.db") or parts[-1].endswith((".pyc", ".tmp", ".bak", ".incoming"))


def read_tree(src: Path) -> dict:
    tree = {}
    if src.is_file() and src.suffix == ".zip":
        with zipfile.ZipFile(src) as zf:
            names = [n for n in zf.namelist() if not n.endswith("/")]
            prefix = TOP + "/" if names and all(n.startswith(TOP + "/") for n in names) else ""
            for n in names:
                rel = n[len(prefix):]
                if not skip(rel):
                    tree[rel] = zf.read(n)
    elif src.is_dir():
        for f in sorted(src.rglob("*")):
            if f.is_file():
                rel = f.relative_to(src).as_posix()
                if not skip(rel):
                    tree[rel] = f.read_bytes()
    else:
        sys.exit("not a folder or zip: %s" % src)
    return tree


def game_version(tree: dict) -> str:
    data = tree.get("scripts/core/save_system.gd", b"").decode("utf-8", "replace")
    m = re.search(r'GAME_VERSION\s*:?=\s*"([^"]+)"', data)
    return m.group(1) if m else "0"


def vtuple(v: str) -> tuple:
    return tuple(int(x) if x.isdigit() else 0 for x in re.findall(r"\d+", v)[:3])


# ------------------------------------------------------------------ JSON three-way merge

def _idlist(x) -> bool:
    return isinstance(x, list) and all(isinstance(e, dict) and "id" in e for e in x)


def merge3(base, ours, theirs, path: str, conflicts: list):
    if ours == theirs or theirs == base:
        return ours
    if ours == base:
        return theirs
    if isinstance(ours, dict) and isinstance(theirs, dict) and (base is MISSING or isinstance(base, dict)):
        b = base if isinstance(base, dict) else {}
        out = {}
        keys = list(ours.keys()) + [k for k in theirs if k not in ours] + [k for k in b if k not in ours and k not in theirs]
        for k in keys:
            r = merge3(b.get(k, MISSING), ours.get(k, MISSING), theirs.get(k, MISSING), path + "/" + str(k), conflicts)
            if r is not MISSING:
                out[k] = r
        return out
    b_list = [] if base is MISSING else base
    if _idlist(b_list) and _idlist(ours) and _idlist(theirs):
        bi = {e["id"]: e for e in b_list}
        oi = {e["id"]: e for e in ours}
        ti = {e["id"]: e for e in theirs}
        out_list = []
        for i in list(oi) + [i for i in ti if i not in oi]:
            r = merge3(bi.get(i, MISSING), oi.get(i, MISSING), ti.get(i, MISSING), "%s[id=%s]" % (path, i), conflicts)
            if r is not MISSING:
                out_list.append(r)
        return out_list
    conflicts.append(path or "/")
    return ours


def dump_like(original: bytes, obj) -> bytes:
    text = original.decode("utf-8", "replace")
    indent = 2 if '\n  "' in text else (1 if '\n "' in text else None)
    return (json.dumps(obj, indent=indent, ensure_ascii=False) + ("\n" if text.endswith("\n") else "")).encode("utf-8")


# ------------------------------------------------------------------ pack

def cmd_pack(a) -> int:
    if not re.fullmatch(r"[a-z0-9_]+", a.id):
        sys.exit("--id must be lower-case letters, digits and underscores")
    base, new = read_tree(Path(a.base)), read_tree(Path(a.new))
    files, base_json, deleted = {}, {}, []
    for rel, data in new.items():
        if rel in base and base[rel] == data:
            continue
        files[rel] = data
        if rel in base and rel.startswith("data/") and rel.endswith(".json"):
            base_json[rel] = base[rel]
    deleted = sorted(r for r in base if r not in new)
    manifest = {
        "format": 1, "id": a.id, "name": a.name or a.id, "version": a.version, "notes": a.notes,
        "min_game_version": a.min_game_version or game_version(base),
        "built_on_game_version": game_version(new),
        "created": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "files": {rel: {"sha": sha(d), "base_sha": sha(base[rel]) if rel in base else None} for rel, d in sorted(files.items())},
        "json_merge": sorted(base_json), "deleted": deleted,
    }
    out_dir = Path(a.out) if a.out else (Path("/mnt/user-data/outputs") if Path("/mnt/user-data/outputs").is_dir() else ROOT.parent / "kindlewake_out")
    out_dir.mkdir(parents=True, exist_ok=True)
    zpath = out_dir / ("Feature_%s.zip" % a.id)
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        zf.writestr("feature.json", json.dumps(manifest, indent=1, ensure_ascii=False))
        for rel, d in sorted(files.items()):
            zf.writestr("files/" + rel, d)
        for rel, d in sorted(base_json.items()):
            zf.writestr("base/" + rel, d)
    print("pack: %s  (%d files, %d with a JSON base, %d deletions reported, %.1f MB)" % (zpath, len(files), len(base_json), len(deleted), zpath.stat().st_size / 1048576.0))
    return 0


# ------------------------------------------------------------------ apply

def load_pack(p: Path) -> tuple:
    if not p.is_file():
        sys.exit("no such pack: %s" % p)
    with zipfile.ZipFile(p) as zf:
        if "feature.json" not in zf.namelist():
            sys.exit("not a feature pack (feature.json missing)")
        m = json.loads(zf.read("feature.json"))
        files = {n[6:]: zf.read(n) for n in zf.namelist() if n.startswith("files/") and not n.endswith("/")}
        base = {n[5:]: zf.read(n) for n in zf.namelist() if n.startswith("base/") and not n.endswith("/")}
    for rel, info in m.get("files", {}).items():
        if rel not in files or sha(files[rel]) != info.get("sha"):
            sys.exit("pack is damaged: %s" % rel)
        if rel.startswith("/") or ".." in rel.split("/"):
            sys.exit("unsafe path in pack: %s" % rel)
    return m, files, base


def registry_path(proj: Path) -> Path:
    return proj / "docs" / "FEATURES.json"


def load_registry(proj: Path) -> dict:
    p = registry_path(proj)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except ValueError:
            pass
    return {"applied": []}


def plan_file(proj: Path, rel: str, info: dict, incoming: bytes, base_files: dict, json_merge: set) -> tuple:
    """-> (action, data to write or None, detail). Actions: add, same, update, merge, conflict."""
    target = proj / rel
    if not target.exists():
        return "add", incoming, ""
    ours = target.read_bytes()
    if ours == incoming:
        return "same", None, ""
    if info.get("base_sha") and sha(ours) == info["base_sha"]:
        return "update", incoming, ""
    if rel in json_merge and rel in base_files:
        try:
            b, o, t = json.loads(base_files[rel]), json.loads(ours), json.loads(incoming)
        except ValueError:
            return "conflict", incoming, "not valid JSON"
        conflicts: list = []
        merged = merge3(b, o, t, "", conflicts)
        if conflicts:
            return "conflict", incoming, "same value changed on both sides: " + ", ".join(conflicts[:6]) + (" ..." if len(conflicts) > 6 else "")
        return "merge", dump_like(ours, merged), ""
    return "conflict", incoming, "changed on both sides"


def backup(proj: Path, feature_id: str, rel: str) -> None:
    src = proj / rel
    if src.exists():
        dst = proj / ".merge_backup" / feature_id / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def cmd_apply(a) -> int:
    proj = Path(a.project).resolve()
    m, files, base_files = load_pack(Path(a.pack))
    fid = m["id"]
    reg = load_registry(proj)
    if any(f.get("id") == fid for f in reg["applied"]) and not a.force:
        print("feature '%s' is already merged (docs/FEATURES.json). Use --force to merge it again." % fid)
        return 3
    cur = game_version({"scripts/core/save_system.gd": (proj / "scripts/core/save_system.gd").read_bytes()} if (proj / "scripts/core/save_system.gd").exists() else {})
    if vtuple(cur) < vtuple(str(m.get("min_game_version", "0"))):
        print("WARNING: the pack needs game version %s or newer, this project is %s." % (m.get("min_game_version"), cur))
    json_merge = set(m.get("json_merge", []))
    counts = {"add": 0, "same": 0, "update": 0, "merge": 0, "conflict": 0}
    conflicts, rows = [], []
    for rel, info in sorted(m["files"].items()):
        action, data, detail = plan_file(proj, rel, info, files[rel], base_files, json_merge)
        counts[action] += 1
        rows.append((rel, action, data, detail))
        if action == "conflict":
            conflicts.append("%s (%s)" % (rel, detail))
    print("feature '%s' (%s), built on game %s: %s" % (fid, m.get("name", ""), m.get("built_on_game_version", "?"), m.get("notes", "")))
    for rel, action, _data, detail in rows:
        if action != "same":
            print("  %-9s %s%s" % (action.upper(), rel, ("   " + detail) if detail else ""))
    for rel in m.get("deleted", []):
        print("  %-9s %s" % ("DELETE?", rel) + ("" if a.allow_delete else "   (only with --allow-delete)"))
    print("summary: %(add)d added, %(update)d updated, %(merge)d merged, %(same)d unchanged, %(conflict)d conflicts" % counts)
    if not a.apply:
        print("DRY RUN: nothing was written. Add --apply to merge.")
        return 1 if counts["conflict"] else 0
    for rel, action, data, _detail in rows:
        target = proj / rel
        if action in ("add", "update", "merge") or (action == "conflict" and a.force):
            backup(proj, fid, rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        elif action == "conflict":
            inc = target.parent / (target.name + ".incoming")
            inc.write_bytes(data)
    if a.allow_delete:
        for rel in m.get("deleted", []):
            backup(proj, fid, rel)
            (proj / rel).unlink(missing_ok=True)
    held = [] if a.force else conflicts
    reg["applied"].append({"id": fid, "version": m.get("version", "1"), "name": m.get("name", fid),
                           "applied_at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
                           "files": len(rows), "open_conflicts": held})
    registry_path(proj).parent.mkdir(parents=True, exist_ok=True)
    registry_path(proj).write_text(json.dumps(reg, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    print("merged. Backups: .merge_backup/%s/" % fid)
    if held:
        print("OPEN CONFLICTS (your files were kept; the incoming copies are next to them as *.incoming):")
        for c in held:
            print("  - " + c)
    lint = proj / "tools" / "gd_static_check.py"
    if lint.exists():
        p = subprocess.run([sys.executable, "-I", str(lint)], cwd=str(proj), capture_output=True, text=True)
        tail = (p.stdout + p.stderr).strip().splitlines()
        print("static check after the merge: " + (tail[-1] if tail else "(no output)"))
    print("next: run tools/checkpoint.py")
    return 1 if held else 0


def cmd_list(a) -> int:
    reg = load_registry(Path(a.project).resolve())
    if not reg["applied"]:
        print("no features merged yet (base project only)")
    for f in reg["applied"]:
        print("%s v%s  %s  %d files  %s" % (f.get("id"), f.get("version"), f.get("applied_at"), f.get("files", 0),
                                          ("OPEN CONFLICTS: %d" % len(f["open_conflicts"])) if f.get("open_conflicts") else "clean"))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("pack", help="make Feature_<id>.zip from the difference between two project versions")
    p.add_argument("--base", required=True)
    p.add_argument("--new", required=True)
    p.add_argument("--id", required=True)
    p.add_argument("--name", default="")
    p.add_argument("--version", default="1")
    p.add_argument("--notes", default="")
    p.add_argument("--min-game-version", default="")
    p.add_argument("--out", default="")
    p.set_defaults(fn=cmd_pack)
    p = sub.add_parser("apply", help="merge a feature pack (dry run unless --apply)")
    p.add_argument("pack")
    p.add_argument("--project", default=str(ROOT))
    p.add_argument("--apply", action="store_true")
    p.add_argument("--force", action="store_true")
    p.add_argument("--allow-delete", action="store_true")
    p.set_defaults(fn=cmd_apply)
    p = sub.add_parser("list", help="features merged so far")
    p.add_argument("--project", default=str(ROOT))
    p.set_defaults(fn=cmd_list)
    a = ap.parse_args()
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
