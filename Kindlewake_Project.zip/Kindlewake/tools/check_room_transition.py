#!/usr/bin/env python3
"""Source-level regression guard for the v0.8.8 room swirl transition.

This checks that the shader, RoomScene material setup and transition tween stay wired
 together. It does not compile the shader or replace a Godot import/runtime test.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
SHADER = ROOT / "assets/shaders/room_swirl.gdshader"
SCENE = ROOT / "scripts/ui/room_scene.gd"


def main() -> int:
    problems = []
    if not SHADER.is_file():
        problems.append("missing assets/shaders/room_swirl.gdshader")
        shader = ""
    else:
        shader = SHADER.read_text(encoding="utf-8")
    if not SCENE.is_file():
        problems.append("missing scripts/ui/room_scene.gd")
        scene = ""
    else:
        scene = SCENE.read_text(encoding="utf-8")

    shader_contract = {
        "CanvasItem shader": "shader_type canvas_item;",
        "progress uniform": "uniform float progress",
        "screen-space aspect correction": "SCREEN_PIXEL_SIZE.y / SCREEN_PIXEL_SIZE.x",
        "coverage alpha output": "COLOR = vec4(colour, coverage);",
    }
    for label, token in shader_contract.items():
        if token not in shader:
            problems.append("shader contract missing: " + label)

    scene_contract = {
        "shader resource load": 'load("res://assets/shaders/room_swirl.gdshader") as Shader',
        "initial progress": 'swirl.set_shader_parameter("progress", 0.0)',
        "material assignment": "fade_rect.material = swirl",
        "progress tween": '"shader_parameter/progress", to_progress, TRANSITION_TIME',
        "missing-material callback fallback": "if done.is_valid():\n            done.call()",
        "outbound room/site wipe": "_fade(1.0, _after_exit_fade.bind(e))",
        "destination reveal": "_fade(0.0, Callable())",
        "encounter wipe": "_fade(1.0, _go_battle.bind(def))",
    }
    for label, token in scene_contract.items():
        if token not in scene:
            problems.append("RoomScene wiring missing: " + label)

    if problems:
        print("room transition source check: FAILED")
        for problem in problems:
            print("  - " + problem)
        return 1
    print("room transition source check: shader contract and 8 RoomScene wiring checks passed")
    print("note: source-level only; Godot shader compilation and visual/runtime checks are still required")
    return 0


if __name__ == "__main__":
    sys.exit(main())
