#!/usr/bin/env python3
"""Pre-renders the 3D voxel packs (MagicaVoxel .obj) into 2D sprites for the overworld (v0.7.0).

Why: Godot's 2D renderer cannot draw .obj files, and loading 3D models on a phone costs battery for nothing. Each model is
drawn ONCE here with a small software rasteriser (orthographic three-quarter view, flat shading, 1-pixel outline) and the
game just draws the PNG. Palettes are swapped at render time: "stone", "thatch" and "slate" are medieval recolours for the
Marches; "sand" keeps the original adobe colours for the dry Vessmoor plains.

Usage:  python3 tools/render_voxels.py <folder holding the unzipped packs> <output folder> [--sheet contact.png]
Needs numpy and Pillow. The input packs are NOT shipped in the project (see docs/ASSETS.md).
"""
import colorsys
import glob
import math
import os
import sys

import numpy as np
from PIL import Image

YAW = math.radians(38.0)
PITCH = math.radians(32.0)
LIGHT = np.array([-0.45, 0.80, 0.40])
LIGHT = LIGHT / np.linalg.norm(LIGHT)
OUTLINE = (30, 24, 22, 255)

PALETTES = {
    "sand": {},
    "stone": {241: (132, 131, 126), 242: (178, 176, 168), 240: (92, 92, 94), 233: (92, 64, 46), 232: (58, 40, 30), 192: (70, 44, 32),
              194: (150, 62, 48), 193: (104, 44, 36), 185: (206, 164, 52), 234: (120, 100, 90), 248: (238, 204, 120)},
    "thatch": {241: (178, 166, 136), 242: (214, 202, 172), 240: (122, 110, 88), 233: (88, 62, 44), 232: (58, 40, 30), 192: (70, 44, 32),
               194: (176, 140, 70), 193: (128, 98, 48), 185: (206, 164, 52), 234: (140, 120, 100), 248: (238, 204, 120)},
    "slate": {241: (104, 108, 118), 242: (150, 154, 164), 240: (72, 76, 86), 233: (70, 56, 50), 232: (44, 36, 34), 192: (60, 44, 40),
              194: (62, 78, 108), 193: (44, 56, 82), 185: (190, 160, 70), 234: (100, 100, 110), 248: (238, 204, 120)},
}
# model file stem -> (output name, target height in pixels)
BUILDINGS = {
    "TinyBuilding01": ("tiny", 64), "SmallBuilding01": ("small1", 84), "SmallBuilding03": ("small3", 84),
    "SmallBuilding04": ("small4", 84), "LargeBuilding01": ("large1", 118), "TallBuilding01": ("tall1", 150),
    "TallBuilding02": ("tall2", 160), "TallBuilding03": ("tall3", 170),
}
ROCK_VARIANTS = {"grey": ((118, 120, 126), 0.55), "sand": ((170, 142, 100), 0.5)}


def parse_obj(path):
    verts, vts, vns, faces = [], [], [], []
    with open(path) as f:
        for line in f:
            if line.startswith("v "):
                verts.append(tuple(float(x) for x in line.split()[1:4]))
            elif line.startswith("vt "):
                vts.append(tuple(float(x) for x in line.split()[1:3]))
            elif line.startswith("vn "):
                vns.append(tuple(float(x) for x in line.split()[1:4]))
            elif line.startswith("f "):
                idx = []
                for tok in line.split()[1:]:
                    p = tok.split("/")
                    idx.append((int(p[0]) - 1, int(p[1]) - 1 if len(p) > 1 and p[1] else -1, int(p[2]) - 1 if len(p) > 2 and p[2] else -1))
                faces.append(idx)
    return np.array(verts), np.array(vts), np.array(vns), faces


def project(verts):
    cy, sy = math.cos(YAW), math.sin(YAW)
    cp, sp = math.cos(PITCH), math.sin(PITCH)
    x, y, z = verts[:, 0], verts[:, 1], verts[:, 2]
    xr = x * cy + z * sy
    zr = -x * sy + z * cy
    up = y * cp - zr * sp
    depth = zr * cp + y * sp
    return xr, up, depth


def view_normal(n):
    cy, sy = math.cos(YAW), math.sin(YAW)
    cp, sp = math.cos(PITCH), math.sin(PITCH)
    xr = n[0] * cy + n[2] * sy
    zr = -n[0] * sy + n[2] * cy
    up = n[1] * cp - zr * sp
    dep = zr * cp + n[1] * sp
    return np.array([xr, up, dep])


def raster(verts, faces, vns, colour_of_face, ppu, ss):
    xr, up, depth = project(verts)
    pad = 4 * ss
    minx, maxx, miny, maxy = xr.min(), xr.max(), up.min(), up.max()
    w = int((maxx - minx) * ppu * ss) + 2 * pad
    h = int((maxy - miny) * ppu * ss) + 2 * pad
    sx = (xr - minx) * ppu * ss + pad
    sy = (maxy - up) * ppu * ss + pad
    buf = np.zeros((h, w, 4), dtype=np.float32)
    zb = np.full((h, w), -1e9, dtype=np.float32)
    for fi, f in enumerate(faces):
        vi = [v[0] for v in f]
        ni = f[0][2]
        n = vns[ni] if ni >= 0 else np.cross(verts[vi[1]] - verts[vi[0]], verts[vi[2]] - verts[vi[0]])
        nv = view_normal(n / (np.linalg.norm(n) + 1e-9))
        shade = 0.50 + 0.62 * max(0.0, float(np.dot(nv, LIGHT)))
        col = np.clip(np.array(colour_of_face(fi, f), dtype=np.float32) * shade, 0, 255)
        for k in range(1, len(vi) - 1):
            tri = (vi[0], vi[k], vi[k + 1])
            xs = sx[list(tri)]
            ys = sy[list(tri)]
            zs = depth[list(tri)]
            x0i, x1i = max(int(math.floor(xs.min())), 0), min(int(math.ceil(xs.max())), w - 1)
            y0i, y1i = max(int(math.floor(ys.min())), 0), min(int(math.ceil(ys.max())), h - 1)
            if x1i < x0i or y1i < y0i:
                continue
            X, Y = np.meshgrid(np.arange(x0i, x1i + 1) + 0.5, np.arange(y0i, y1i + 1) + 0.5)
            den = (ys[1] - ys[2]) * (xs[0] - xs[2]) + (xs[2] - xs[1]) * (ys[0] - ys[2])
            if abs(den) < 1e-9:
                continue
            a = ((ys[1] - ys[2]) * (X - xs[2]) + (xs[2] - xs[1]) * (Y - ys[2])) / den
            b = ((ys[2] - ys[0]) * (X - xs[2]) + (xs[0] - xs[2]) * (Y - ys[2])) / den
            c = 1.0 - a - b
            eps = -0.02
            m = (a >= eps) & (b >= eps) & (c >= eps)
            z = a * zs[0] + b * zs[1] + c * zs[2]
            sub = zb[y0i:y1i + 1, x0i:x1i + 1]
            upd = m & (z > sub)
            sub[upd] = z[upd]
            region = buf[y0i:y1i + 1, x0i:x1i + 1]
            region[upd, :3] = col
            region[upd, 3] = 255.0
    return buf


def finish(buf, target_h):
    """Crop, resize (alpha-weighted) to target_h pixels tall, make the edge crisp and add the outline."""
    alpha = buf[:, :, 3] > 0
    ys, xs = np.where(alpha)
    buf = buf[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = buf.shape[:2]
    scale = target_h / float(h)
    nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
    a = buf[:, :, 3:4] / 255.0
    pm = np.concatenate([buf[:, :, :3] * a, a * 255.0], axis=2).astype(np.float32)
    chans = []
    for ch in range(4):
        im = Image.fromarray(pm[:, :, ch], mode="F").resize((nw, nh), Image.BOX if scale < 1 else Image.NEAREST)
        chans.append(np.array(im))
    out = np.stack(chans, axis=2)
    al = out[:, :, 3] / 255.0
    rgb = np.where(al[:, :, None] > 0.01, out[:, :, :3] / np.maximum(al[:, :, None], 0.01) * 255.0 / 255.0, 0)
    sol = al > 0.5
    res = np.zeros((nh + 2, nw + 2, 4), dtype=np.uint8)
    inner = np.zeros((nh + 2, nw + 2), dtype=bool)
    inner[1:-1, 1:-1] = sol
    pad_rgb = np.zeros((nh + 2, nw + 2, 3), dtype=np.float32)
    pad_rgb[1:-1, 1:-1] = rgb
    dil = inner.copy()
    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        dil |= np.roll(np.roll(inner, dy, 0), dx, 1)
    res[dil, :] = OUTLINE
    res[inner, :3] = np.clip(pad_rgb[inner], 0, 255).astype(np.uint8)
    res[inner, 3] = 255
    return Image.fromarray(res, "RGBA")


def render_building(stem, folder, palette_name, target_h):
    obj = os.path.join(folder, stem + ".obj")
    pal_img = Image.open(os.path.join(folder, stem + ".png")).convert("RGB")
    verts, vts, vns, faces = parse_obj(obj)
    override = PALETTES[palette_name]

    def colour(fi, f):
        u = vts[f[0][1]][0]
        idx = min(int(u * pal_img.size[0]), pal_img.size[0] - 1)
        return override.get(idx, pal_img.getpixel((idx, 0)))

    ppu = 60.0
    buf = raster(verts, faces, vns, colour, ppu, 3)
    return finish(buf, target_h)


def render_rock(path, variant, target_w):
    verts, vts, vns, faces = parse_obj(path)
    base, var = ROCK_VARIANTS[variant]
    base = np.array(base, dtype=np.float32)

    def colour(fi, f):
        u = vts[f[0][1]][0] if f[0][1] >= 0 else 0.5
        j = ((u * 977.0) % 1.0 - 0.5) * 2.0 * var * 0.45
        return np.clip(base * (1.0 + j), 0, 255)

    ppu = 40.0
    buf = raster(verts, faces, vns, colour, ppu, 2)
    ys, xs = np.where(buf[:, :, 3] > 0)
    wpx = xs.max() - xs.min() + 1
    hpx = ys.max() - ys.min() + 1
    return finish(buf, int(round(target_w * hpx / wpx)))


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    src, dst = sys.argv[1], sys.argv[2]
    os.makedirs(dst, exist_ok=True)
    made = []
    for stem, (name, th) in BUILDINGS.items():
        hits = glob.glob(os.path.join(src, "**", stem + ".obj"), recursive=True)
        if not hits:
            print("missing", stem)
            continue
        folder = os.path.dirname(hits[0])
        for pal in PALETTES:
            im = render_building(stem, folder, pal, th)
            p = os.path.join(dst, "%s_%s.png" % (name, pal))
            im.save(p)
            made.append(p)
            print("wrote", p, im.size, flush=True)
    for path in sorted(glob.glob(os.path.join(src, "**", "MountainRocks-*.obj"), recursive=True)):
        n = os.path.basename(path).split("-")[1].split(".")[0]
        for var in ROCK_VARIANTS:
            im = render_rock(path, var, 54)
            p = os.path.join(dst, "rock%s_%s.png" % (n, var))
            im.save(p)
            made.append(p)
            print("wrote", p, im.size, flush=True)
    if "--sheet" in sys.argv:
        sheet = sys.argv[sys.argv.index("--sheet") + 1]
        ims = [Image.open(p) for p in made]
        x = y = 0
        rowh = 0
        W = 1500
        canvas = Image.new("RGBA", (W, 1500), (70, 110, 70, 255))
        for im in ims:
            if x + im.width > W:
                x = 0
                y += rowh + 8
                rowh = 0
            canvas.alpha_composite(im, (x, y))
            x += im.width + 8
            rowh = max(rowh, im.height)
        canvas.crop((0, 0, W, y + rowh + 8)).save(sheet)


if __name__ == "__main__":
    main()
