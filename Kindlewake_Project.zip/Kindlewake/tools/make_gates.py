#!/usr/bin/env python3
"""Build the story-gate overlay from the baked Eldrimar region layer."""
import argparse, base64, json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GATE_DEFS = [
    ("g_roadwolf", "Roadwolf Barricade", "barricade", "sethmarch", "ysmark", "salt_market", "brinegate", ["cleared_roadwolf_camp"], "Hask's roadblock still holds the salt road.", "The barricade is broken."),
    ("g_oakroad", "Oathward of Orrowen", "ward", "orrowen", "aurelmont", "thornwick", "kingsway", ["lucan_oath"], "The old ward answers only to an oath sworn at Orrowen Hall.", "The ward fades."),
    ("g_toll", "Brinegate Toll", "toll", "ysmark", "aurelmont", "brinegate", "harrowgate", ["toll_paid"], "The harbour reeve demands 150 gold for the crown road.", "The toll is paid."),
    ("g_dustwell", "Dustwell Barricade", "barricade", "aurelmont", "vessmoor", "harrowgate", "dustwell", ["cleared_deserter_camp"], "Deserters have sealed the dry road.", "The barricade is broken."),
    ("g_cloister", "Cloister Ward", "ward", "aurelmont", "tarnholt", "kingsway", "candlemere", ["pilgrim_seal"], "A pilgrim's seal is needed to pass the cloister ward.", "The ward fades."),
    ("g_starwick", "Starwick Iron Gate", "iron", "vessmoor", "quillon", "dustwell", "starwick", ["cleared_sandjackal_camp"], "The iron gate is held by the sandjackals.", "The gate stands open."),
    ("g_ironford", "Ironford Pass", "iron", "tarnholt", "brennhallow", "candlemere", "ironford", ["cleared_flamebearer_camp"], "The pass is watched by the Flamebearer's sworn guards.", "The pass is open."),
]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    args=ap.parse_args()
    cfg=json.loads((ROOT/"data/world.json").read_text())
    raw=json.loads((ROOT/"data/world_map.json").read_text())
    w,h=int(raw["width"]),int(raw["height"])
    tiles=base64.b64decode(raw["tiles_b64"])
    regions=base64.b64decode(raw["regions_b64"])
    assert len(tiles)==w*h and len(regions)==w*h
    rids={r["id"]:i for i,r in enumerate(cfg["regions"])}
    places={p["id"]:p for p in cfg["places"]}
    free={tuple(sorted((rids["sethmarch"],rids["orrowen"])))}
    boundary=defaultdict(list)
    for y in range(1,h-1):
        for x in range(1,w-1):
            i=y*w+x; a=regions[i]
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                b=regions[(y+dy)*w+x+dx]
                if a!=b and a<len(cfg["regions"]) and b<len(cfg["regions"]):
                    boundary[tuple(sorted((a,b)))].append((x,y))
    # Only boundaries in the authored progression ladder receive physical barriers.
    gate_pairs={tuple(sorted((rids[g[3]],rids[g[4]]))) for g in GATE_DEFS}
    sealed=set(boundary)-free
    # Bands are encoded as [y, x_start, x_end] inclusive runs.
    rows=defaultdict(set)
    for pair in sealed:
        for x,y in boundary[pair]: rows[y].add(x)
    bands=[]
    for y,xs in sorted(rows.items()):
        vals=sorted(xs); start=prev=vals[0]
        for x in vals[1:]:
            if x>prev+1:
                bands.append([y,start,prev]); start=x
            prev=x
        bands.append([y,start,prev])
    gates=[]
    for gid,name,kind,ra,rb,pa,pb,req,hint,opened in GATE_DEFS:
        pair=tuple(sorted((rids[ra],rids[rb])))
        candidates=boundary.get(pair,[])
        if not candidates:
            raise SystemExit("No baked boundary for "+gid)
        a=places[pa]["cell"]; b=places[pb]["cell"]
        mx=(a[0]+b[0])/2; my=(a[1]+b[1])/2
        cx,cy=min(candidates,key=lambda p:(p[0]-mx)**2+(p[1]-my)**2)
        # Pick up to three contiguous cells from this boundary nearest the authored crossing.
        nearby=sorted(candidates,key=lambda p:abs(p[0]-cx)+abs(p[1]-cy))
        chosen=[]
        for p in nearby:
            if all(abs(p[0]-q[0])+abs(p[1]-q[1])<=1 for q in chosen):
                chosen.append(p)
            if len(chosen)==3: break
        gates.append({"id":gid,"name":name,"kind":kind,"between":[ra,rb],
                      "cells":[[x,y] for x,y in chosen],"requires":req,
                      "hint":hint,"open_text":opened})
    out={"schema":1,"source":"data/world_map.json","bands":bands,"gates":gates,
         "place_actions":[
             {"place":"orrowen_hall","id":"swear_lucan_oath","label":"Swear the Oak Oath","requires":["looted_hollow_oak"],"set":["lucan_oath"],"text":"You swear to keep the old road."},
             {"place":"brinegate","id":"pay_toll","label":"Pay 150 gold toll","requires":["gold:150"],"cost":{"gold":150},"set":["toll_paid"],"text":"The reeve takes the coin and opens the road."},
             {"place":"kingsway","id":"claim_pilgrim_seal","label":"Present the pilgrim's medal","requires":["looted_osrics_field"],"set":["pilgrim_seal"],"text":"The wardens recognise the seal."}
         ],
         "quests":[
             {"id":"oak_oath","name":"The Old Oak Oath","steps":[{"flag":"looted_hollow_oak","text":"Recover the token from the Hollow Oak."},{"flag":"lucan_oath","text":"Swear the oath at Orrowen Hall."}]},
             {"id":"pilgrim_seal","name":"A Pilgrim's Mark","steps":[{"flag":"looted_osrics_field","text":"Recover the pilgrim's medal from Osric's Field."},{"flag":"pilgrim_seal","text":"Present it at Kingsway."}]}
         ]}
    # Structural checks: each gate is on a generated sealed boundary and every place has a known region.
    band_cells={(x,y) for y,x0,x1 in bands for x in range(x0,x1+1)}
    for g in gates:
        assert g["cells"] and all(tuple(c) in band_cells for c in g["cells"]), g["id"]
    assert all(p["region"] in rids for p in cfg["places"])
    path=ROOT/"data/world_gates.json"
    if args.check:
        assert path.exists() and json.loads(path.read_text())==out, "world_gates.json is stale; run tools/make_gates.py"
        print("story gates: %d boundary runs, %d gates; overlay verified" % (len(bands),len(gates)))
    else:
        path.write_text(json.dumps(out,indent=2)+"\n")
        print("wrote data/world_gates.json: %d boundary runs, %d gates" % (len(bands),len(gates)))
if __name__=="__main__": main()
