class_name EncounterBuilder
extends RefCounted
## Builds repeatable random fights (data/encounters.json). Pure and static, so tests and the balance report
## can use it without autoloads.


const PATCH_W := 12                # world battles are fought on a 12 x 10 patch of the world
const PATCH_H := 10


static func group_count(encounters: Dictionary, table: String = "skirmish") -> int:
    var cfg: Dictionary = encounters.get(table, {})
    return (cfg.get("groups", []) as Array).size()


## A battle definition with id "skirmish" for enemy group number `group_index`: the base story map, the player's
## spawn points from it and that group's enemies placed on the encounter's enemy cells. {} when the data is missing.
static func build_group(encounters: Dictionary, battles: Dictionary, group_index: int, table: String = "skirmish") -> Dictionary:
    var cfg: Dictionary = encounters.get(table, {})
    var base: Dictionary = (battles.get(str(cfg.get("base_battle", "battle_01")), {}) as Dictionary).duplicate(true)
    var groups: Array = cfg.get("groups", [])
    if base.is_empty() or group_index < 0 or group_index >= groups.size():
        return {}
    var chosen: Dictionary = groups[group_index]
    var spawns: Array = []
    for u in (base.get("units", []) as Array):
        if str((u as Dictionary).get("team", "")) == "player":
            spawns.append(u)
    var cells: Array = cfg.get("enemy_cells", [])
    var members: Array = chosen.get("units", [])
    for i in range(mini(members.size(), cells.size())):
        var entry: Dictionary = {"character_id": str(members[i]), "team": "enemy", "cell": cells[i], "facing": 2}
        if str(chosen.get("commander", "")) == str(members[i]):
            entry["commander"] = true
        spawns.append(entry)
    base["units"] = spawns
    base["id"] = "skirmish"
    base["title"] = str(cfg.get("title", "Skirmish"))
    base["briefing"] = str(cfg.get("briefing", ""))
    return base


## Picks a group by weight (data "weight") and builds it.
static func build_skirmish(encounters: Dictionary, battles: Dictionary, rand: RandomNumberGenerator, table: String = "skirmish") -> Dictionary:
    var cfg: Dictionary = encounters.get(table, {})
    var groups: Array = cfg.get("groups", [])
    if groups.is_empty():
        return {}
    var total := 0
    for g in groups:
        total += int((g as Dictionary).get("weight", 1))
    var roll: int = rand.randi_range(1, maxi(1, total))
    var index := 0
    for i in range(groups.size()):
        roll -= int((groups[i] as Dictionary).get("weight", 1))
        if roll <= 0:
            index = i
            break
    return build_group(encounters, battles, index, table)


# ------------------------------------------------------------------ world battles (v0.7.0)
# A fight on the overworld is fought on a map cut from the world around the party (WorldMap.battle_patch), with the
# player's starting positions and the enemy positions of the Skirmish setup, so every region plays on its own ground.

## An ambush for `region_id` (data "regions": groups with weights). {} when the region has no groups.
static func build_region_ambush(encounters: Dictionary, battles: Dictionary, region_id: String, rand: RandomNumberGenerator, patch: Dictionary) -> Dictionary:
    var reg: Dictionary = (encounters.get("regions", {}) as Dictionary).get(region_id, {})
    var groups: Array = reg.get("groups", [])
    if groups.is_empty():
        return {}
    var total := 0
    for g in groups:
        total += int((g as Dictionary).get("weight", 1))
    var roll: int = rand.randi_range(1, maxi(1, total))
    var chosen: Dictionary = groups[0]
    for g in groups:
        roll -= int((g as Dictionary).get("weight", 1))
        if roll <= 0:
            chosen = g
            break
    return _assemble(encounters, battles, chosen, patch, "Ambush", str(reg.get("ambush", "An ambush!")), "ambush_" + region_id)


## The fixed battle of an enemy camp (data "camps"): its units, with the unit named in "commander" as the chief.
static func build_camp(encounters: Dictionary, battles: Dictionary, camp_id: String, patch: Dictionary) -> Dictionary:
    var camp: Dictionary = (encounters.get("camps", {}) as Dictionary).get(camp_id, {})
    if camp.is_empty():
        return {}
    return _assemble(encounters, battles, camp, patch, str(camp.get("title", "Enemy Camp")), str(camp.get("briefing", "")), "camp_" + camp_id)


static func _assemble(encounters: Dictionary, battles: Dictionary, group: Dictionary, patch: Dictionary, title: String, briefing: String, def_id: String) -> Dictionary:
    var cfg: Dictionary = encounters.get("skirmish", {})
    var base: Dictionary = (battles.get(str(cfg.get("base_battle", "battle_01")), {}) as Dictionary).duplicate(true)
    if base.is_empty() or patch.is_empty():
        return {}
    var spawns: Array = []
    var player_cells: Array[Vector2i] = []
    for u in (base.get("units", []) as Array):
        if str((u as Dictionary).get("team", "")) == "player":
            spawns.append(u)
            var pc: Array = (u as Dictionary).get("cell", [0, 0])
            player_cells.append(Vector2i(int(pc[0]), int(pc[1])))
    var cells: Array = cfg.get("enemy_cells", [])
    var members: Array = group.get("units", [])
    var enemy_cells: Array[Vector2i] = []
    for i in range(mini(members.size(), cells.size())):
        var entry: Dictionary = {"character_id": str(members[i]), "team": "enemy", "cell": cells[i], "facing": 2}
        if str(group.get("commander", "")) == str(members[i]):
            entry["commander"] = true
        spawns.append(entry)
        var ec: Array = cells[i]
        enemy_cells.append(Vector2i(int(ec[0]), int(ec[1])))
    var rows: Array = (patch["terrain"] as Array).duplicate()
    var heights: Array = (patch["heights"] as Array).duplicate()
    for c in player_cells + enemy_cells:
        _flatten_cell(rows, heights, c)
    if not player_cells.is_empty():
        for ec2 in enemy_cells:
            _ensure_path(rows, heights, player_cells[0], ec2)
    base["terrain"] = rows
    base["heights"] = heights
    base["legend"] = (patch.get("legend", base.get("legend", {})) as Dictionary).duplicate()
    base["units"] = spawns
    base["id"] = def_id
    base["title"] = title
    base["briefing"] = briefing
    if group.has("weather"):
        base["weather"] = group["weather"]
    return base


static func _terrain_char(rows: Array, c: Vector2i) -> String:
    if c.y < 0 or c.y >= rows.size():
        return "#"
    var row: String = str(rows[c.y])
    if c.x < 0 or c.x >= row.length():
        return "#"
    return row.substr(c.x, 1)


static func _set_cell(rows: Array, heights: Array, c: Vector2i, ch: String, h: String) -> void:
    if c.y < 0 or c.y >= rows.size():
        return
    var row: String = str(rows[c.y])
    if c.x < 0 or c.x >= row.length():
        return
    rows[c.y] = row.substr(0, c.x) + ch + row.substr(c.x + 1)
    var hrow: String = str(heights[c.y])
    if c.x < hrow.length():
        heights[c.y] = hrow.substr(0, c.x) + h + hrow.substr(c.x + 1)


## Units never start in water or inside rock: such a start cell becomes open grass at height 0.
static func _flatten_cell(rows: Array, heights: Array, c: Vector2i) -> void:
    var ch: String = _terrain_char(rows, c)
    if ch == "~" or ch == "#" or ch == "b":
        _set_cell(rows, heights, c, ".", "0")


static func _is_open(ch: String) -> bool:
    return ch != "~" and ch != "#"


## True when `to` can be walked to from `from` over open ground (4-neighbour flood fill).
static func _reachable(rows: Array, from: Vector2i, to: Vector2i) -> bool:
    var seen: Dictionary = {from: true}
    var queue: Array[Vector2i] = [from]
    var head := 0
    while head < queue.size():
        var cur: Vector2i = queue[head]
        head += 1
        if cur == to:
            return true
        for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
            var n: Vector2i = cur + d
            if seen.has(n) or not _is_open(_terrain_char(rows, n)):
                continue
            seen[n] = true
            queue.append(n)
    return false


## If the two sides are cut off from each other (a river or a cliff band across the map), cut a ford / path between them.
static func _ensure_path(rows: Array, heights: Array, from: Vector2i, to: Vector2i) -> void:
    if _reachable(rows, from, to):
        return
    var cur: Vector2i = from
    while cur != to:
        if cur.x != to.x:
            cur.x += 1 if to.x > cur.x else -1
        else:
            cur.y += 1 if to.y > cur.y else -1
        var ch: String = _terrain_char(rows, cur)
        if ch == "~":
            _set_cell(rows, heights, cur, "w", "0")
        elif ch == "#":
            _set_cell(rows, heights, cur, ".", "0")
