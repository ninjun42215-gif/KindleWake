extends Node
## Small offline audio layer. Placeholder tones are synthesized in memory; no downloads/assets required.

const SAMPLE_RATE := 22050
var music_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var music_stream: AudioStreamWAV
var click_stream: AudioStreamWAV
var gate_stream: AudioStreamWAV
var _ready_audio := false


func _ready() -> void:
    _ensure_buses()
    music_player = AudioStreamPlayer.new()
    music_player.bus = "Music"
    add_child(music_player)
    sfx_player = AudioStreamPlayer.new()
    sfx_player.bus = "SFX"
    add_child(sfx_player)
    music_stream = _make_tone([110.0, 164.81, 220.0], 2.4, 0.055, true)
    click_stream = _make_tone([660.0], 0.075, 0.12, false)
    gate_stream = _make_tone([392.0, 523.25, 659.25], 0.32, 0.15, false)
    _ready_audio = true
    apply_settings()


func _ensure_buses() -> void:
    var master_index := AudioServer.get_bus_index("Master")
    if master_index < 0:
        return
    for bus_name in ["Music", "SFX"]:
        if AudioServer.get_bus_index(bus_name) >= 0:
            continue
        AudioServer.add_bus()
        var index := AudioServer.bus_count - 1
        AudioServer.set_bus_name(index, bus_name)
        AudioServer.set_bus_send(index, "Master")


func apply_settings() -> void:
    if not _ready_audio:
        return
    _set_bus_volume("Master", SettingsStore.volume("master"))
    _set_bus_volume("Music", SettingsStore.volume("music"))
    _set_bus_volume("SFX", SettingsStore.volume("sfx"))


func _set_bus_volume(bus_name: String, amount: float) -> void:
    var index := AudioServer.get_bus_index(bus_name)
    if index < 0:
        return
    AudioServer.set_bus_mute(index, amount <= 0.001)
    AudioServer.set_bus_volume_db(index, linear_to_db(maxf(amount, 0.001)))


func start_music() -> void:
    if not _ready_audio or music_player.playing:
        return
    music_player.stream = music_stream
    music_player.play()


func stop_music() -> void:
    if _ready_audio:
        music_player.stop()


func play_ui_click() -> void:
    _play_sfx(click_stream)


func play_gate_open() -> void:
    _play_sfx(gate_stream)


func _play_sfx(stream: AudioStreamWAV) -> void:
    if not _ready_audio or SettingsStore.volume("sfx") <= 0.001 or SettingsStore.volume("master") <= 0.001:
        return
    sfx_player.stream = stream
    sfx_player.play()


func _make_tone(frequencies: Array, duration: float, amplitude: float, looped: bool) -> AudioStreamWAV:
    var frames := maxi(1, int(SAMPLE_RATE * duration))
    var bytes := PackedByteArray()
    bytes.resize(frames * 2)
    for i in range(frames):
        var sample := 0.0
        for frequency in frequencies:
            sample += sin(TAU * frequency * float(i) / float(SAMPLE_RATE))
        sample /= maxf(1.0, float(frequencies.size()))
        var fade := minf(1.0, float(i) / 180.0)
        if not looped:
            fade *= minf(1.0, float(frames - i) / 500.0)
        var pcm := int(clampf(sample * amplitude * fade, -1.0, 1.0) * 32767.0)
        bytes.encode_s16(i * 2, pcm)
    var stream := AudioStreamWAV.new()
    stream.format = AudioStreamWAV.FORMAT_16_BITS
    stream.mix_rate = SAMPLE_RATE
    stream.stereo = false
    stream.data = bytes
    if looped:
        stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
        stream.loop_begin = 0
        stream.loop_end = frames
    return stream
