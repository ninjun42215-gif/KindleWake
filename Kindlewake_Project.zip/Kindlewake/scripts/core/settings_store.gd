extends Node
## Offline persistent user settings. Save-game payloads are deliberately unaffected.

const SETTINGS_PATH := "user://settings.cfg"
const DEFAULTS := {
    "audio": {"master": 1.0, "music": 0.65, "sfx": 0.85},
    "display": {"screen_shake": true},
    "battle": {"auto_battle": false},
}

var values: Dictionary = {}
var config_path: String = SETTINGS_PATH


func _ready() -> void:
    load_settings()


func load_settings() -> void:
    values = DEFAULTS.duplicate(true)
    var cfg := ConfigFile.new()
    if cfg.load(config_path) != OK:
        return
    for section_value in DEFAULTS.keys():
        var section := str(section_value)
        for key_value in (DEFAULTS[section] as Dictionary).keys():
            var key := str(key_value)
            values[section][key] = cfg.get_value(section, key, DEFAULTS[section][key])
    _sanitize()


func get_setting(section: String, key: String, fallback: Variant = null) -> Variant:
    if values.is_empty():
        load_settings()
    return (values.get(section, {}) as Dictionary).get(key, fallback)


func set_setting(section: String, key: String, value: Variant) -> bool:
    if not values.has(section):
        values[section] = {}
    values[section][key] = value
    _sanitize()
    return save_settings()


func set_volume(bus_name: String, volume: float) -> bool:
    if not ["master", "music", "sfx"].has(bus_name):
        return false
    return set_setting("audio", bus_name, clampf(volume, 0.0, 1.0))


func volume(bus_name: String) -> float:
    return clampf(float(get_setting("audio", bus_name, 1.0)), 0.0, 1.0)


func save_settings() -> bool:
    var cfg := ConfigFile.new()
    # Preserve unrelated keys such as battle settings added by later features.
    cfg.load(config_path)
    for section_value in values.keys():
        var section := str(section_value)
        var section_values: Dictionary = values[section]
        for key_value in section_values.keys():
            var key := str(key_value)
            cfg.set_value(section, key, section_values[key])
    return cfg.save(config_path) == OK


func _sanitize() -> void:
    if not values.has("audio"):
        values["audio"] = {}
    for key in ["master", "music", "sfx"]:
        values["audio"][key] = clampf(float(values["audio"].get(key, DEFAULTS.audio[key])), 0.0, 1.0)
    if not values.has("battle"):
        values["battle"] = {}
    values["battle"]["auto_battle"] = bool(values["battle"].get("auto_battle", false))
