extends Node
## Runtime campaign state (autoload "GameState"). Milestone 2: the persistent party.
## Autoload scripts have no class_name; tests use PartyState / EncounterBuilder / ShopSystem directly instead.

var party: PartyState = PartyState.new()
var rng := RandomNumberGenerator.new()


func _ready() -> void:
    rng.randomize()
    new_game()


func new_game() -> void:
    party = PartyState.new_game(GameData.start, GameData.characters)


## Battle database with the party's current sheets (level, stats, equipment) substituted in.
func battle_db() -> Dictionary:
    return party.battle_db(GameData.as_db())


## Pays EXP, AP and gold after a battle (FF7 rules, see PartyState.battle_rewards).
## Returns {"reports", "gold", "spawned", "defeated", "total_exp", "total_ap"}; an empty report list on defeat.
func award_battle(units: Array, result: String) -> Dictionary:
    return party.apply_battle_result(units, result, rng, GameData.rules_db())


## A repeatable random encounter for grinding (data/encounters.json): the story map with a weighted-random enemy group.
func skirmish_def() -> Dictionary:
    return EncounterBuilder.build_skirmish(GameData.encounters, GameData.battles, rng)
