extends Node
## Runtime campaign state (autoload "GameState"). Milestone 2: the persistent party.
## Autoload scripts have no class_name; tests use PartyState / EncounterBuilder / ShopSystem directly instead.

var party: PartyState = PartyState.new()
var rng := RandomNumberGenerator.new()

# Overworld state (Milestone 7). The world scene and the battle scene hand over through these fields.
var pending_battle: Dictionary = {}      # battle the battle scene should open next (empty = default story battle)
var from_world: bool = false             # true when the battle was started from the overworld
var world_pos: Vector2 = Vector2.ZERO    # last overworld position in pixels (ZERO = start at the keep)
var world_flags: Dictionary = {}         # "seen_<place>", "cleared_<place>" (camps), "looted_<place>" (ruins)
var battle_place: String = ""            # place id of the camp being attacked ("" = a random ambush)
# Pre-rendered rooms (feature pre_rendered_rooms): keeps and dungeons from data/sites.json. The room scene reads these on load.
var pending_site: String = ""
var pending_room: String = ""
var pending_spawn: Array = []            # [x, y] cell for the hero (empty = the room's own spawn)
var battle_return: Dictionary = {}       # where "Back" after a battle goes: {"scene": "world"} or {"scene": "room", "site", "room", "spawn"}
var booted: bool = false                 # the start menu (Continue / New Game) has been handled this session

# Character select (feature character_select): who walks the world and how Torren looks. Saved with the world saves.
var lead_id: String = "torren"
var appearance: Dictionary = {"hair": "raven", "scarf": "ember"}

## Save slots the world reads, newest wins. "world" is the manual save, the autosaves rotate, "1" is the old battle slot.
const SAVE_SLOTS := ["world", "auto_a", "auto_b", "1"]


func _ready() -> void:
    rng.randomize()
    new_game()


func new_game() -> void:
    party = PartyState.new_game(GameData.start, GameData.characters)
    pending_battle = {}
    from_world = false
    world_pos = Vector2.ZERO
    world_flags = {}
    battle_place = ""
    pending_site = ""
    pending_room = ""
    pending_spawn = []
    battle_return = {}
    lead_id = HeroLooks.valid_lead(str(GameData.looks.get("default_lead", "torren")), GameData.looks, party.roster)
    appearance = HeroLooks.default_appearance(GameData.looks)


## Battle database with the party's current sheets (level, stats, equipment) substituted in.
func battle_db() -> Dictionary:
    return party.battle_db(GameData.as_db())


## Pays EXP, AP and gold after a battle (FF7 rules, see PartyState.battle_rewards).
## Returns {"reports", "gold", "spawned", "defeated", "total_exp", "total_ap"}; an empty report list on defeat.
func award_battle(units: Array, result: String) -> Dictionary:
    return party.apply_battle_result(units, result, rng, GameData.rules_db())


## A repeatable random encounter for grinding (data/encounters.json): the story map with a weighted-random enemy group.
func skirmish_def(table: String = "skirmish") -> Dictionary:
    return EncounterBuilder.build_skirmish(GameData.encounters, GameData.battles, rng, table)


## Called by the overworld: the battle scene picks `def` up when it loads. `place_id` is the camp being attacked
## (its "cleared_<id>" flag is set on victory), or "" for a random ambush.
func start_battle_from_world(def: Dictionary, place_id: String = "") -> void:
    pending_battle = def
    from_world = true
    battle_place = place_id
    battle_return = {"scene": "world"}


## Called by a pre-rendered room (keep or dungeon): same hand-over, but "Back" returns to that room and cell.
## `clear_flag` (optional) is set in world_flags when the fight is won (a boss that stays dead).
func start_battle_from_room(def: Dictionary, site_id: String, room_id: String, spawn: Array) -> void:
    pending_battle = def
    from_world = true
    battle_place = ""
    battle_return = {"scene": "room", "site": site_id, "room": room_id, "spawn": spawn}


## The battle scene's "Back" button: the overworld, or the room the fight started in.
func return_from_battle() -> void:
    var r: Dictionary = battle_return
    battle_return = {}
    if str(r.get("scene", "world")) == "room":
        pending_site = str(r.get("site", ""))
        pending_room = str(r.get("room", ""))
        pending_spawn = (r.get("spawn", []) as Array).duplicate()
        get_tree().change_scene_to_file("res://Room.tscn")
    else:
        get_tree().change_scene_to_file("res://World.tscn")


## A random ambush for the region under `cell`, fought on the terrain around it ({} when the region has no enemies).
func ambush_def(wmap: WorldMap, cell: Vector2i) -> Dictionary:
    var patch: Dictionary = wmap.battle_patch(cell, EncounterBuilder.PATCH_W, EncounterBuilder.PATCH_H)
    return EncounterBuilder.build_region_ambush(GameData.encounters, GameData.battles, wmap.region_id_at(cell), rng, patch)


## The fixed fight of the enemy camp `place` (a data/world.json place with a "group").
func camp_def(wmap: WorldMap, place: Dictionary) -> Dictionary:
    var cell_arr: Array = place.get("cell", [0, 0])
    var cell := Vector2i(int(cell_arr[0]), int(cell_arr[1]))
    var patch: Dictionary = wmap.battle_patch(cell, EncounterBuilder.PATCH_W, EncounterBuilder.PATCH_H)
    return EncounterBuilder.build_camp(GameData.encounters, GameData.battles, str(place.get("group", "")), patch)


# ------------------------------------------------------------------ world saves

func world_to_dict() -> Dictionary:
    return {"pos": [world_pos.x, world_pos.y], "flags": world_flags.duplicate(true)}


func world_from_dict(d: Dictionary) -> void:
    var p: Array = d.get("pos", [])
    if p.size() >= 2:
        world_pos = Vector2(float(p[0]), float(p[1]))
    else:
        world_pos = Vector2.ZERO
    world_flags = (d.get("flags", {}) as Dictionary).duplicate(true)


func save_payload() -> Dictionary:
    return {"kind": "world", "party": party.to_dict(), "world": world_to_dict(), "look": look_to_dict()}


## Restores party, gold, items, position and flags from a save payload (battle saves carry them too).
func apply_payload(payload: Dictionary) -> void:
    if payload.has("party"):
        var saved_party: Dictionary = payload["party"]
        party = PartyState.from_dict(saved_party)
    world_from_dict(payload.get("world", {}))
    var saved_look: Dictionary = payload.get("look", {})      # saves without it keep the defaults
    look_from_dict(saved_look)
    pending_battle = {}
    battle_place = ""
    from_world = false


func save_summary() -> String:
    return "Company of Kaer Sethorn | %d gold | %d visited" % [party.gold, visited_count()]


func visited_count() -> int:
    var n := 0
    for k in world_flags.keys():
        if str(k).begins_with("seen_") and bool(world_flags[k]):
            n += 1
    return n


func save_world(slot: String = "world") -> bool:
    return SaveSystem.save_slot(slot, save_payload(), save_summary())


func autosave_world() -> bool:
    return SaveSystem.autosave(save_payload(), save_summary())


## The slot with the newest save ("" when there is none).
func newest_save_slot() -> String:
    var best := ""
    var best_unix := -1.0
    for slot in SAVE_SLOTS:
        var info: Dictionary = SaveSystem.slot_info(str(slot))
        if bool(info["exists"]) and float(info["unix"]) > best_unix:
            best_unix = float(info["unix"])
            best = str(slot)
    return best


## Loads the newest save into the running game. Returns "" on success or an error text.
func load_newest() -> String:
    var slot: String = newest_save_slot()
    if slot == "":
        return "No save found yet."
    var res: Dictionary = SaveSystem.load_slot(slot)
    if not bool(res.get("ok", false)):
        return str(res.get("error", "Load failed."))
    apply_payload(res["payload"])
    return ""


## Called by the battle scene once: returns the queued battle (or {}) and clears it.
func take_pending_battle() -> Dictionary:
    var d: Dictionary = pending_battle
    pending_battle = {}
    return d


# ---------------------------------------------------------------- looks and lead (feature character_select)

## Called by the character select: starts a new campaign with `p_lead` in front and Torren's chosen colours.
func begin_campaign(p_lead: String, p_appearance: Dictionary) -> void:
    new_game()
    appearance = HeroLooks.normalize_appearance(p_appearance, GameData.looks)
    lead_id = HeroLooks.valid_lead(p_lead, GameData.looks, party.roster)
    party.roster = HeroLooks.roster_with_lead_first(lead_id, party.roster)


## Sprite kind of a character right now (heroes have their own sheets, everyone else the plain Soldier).
func look_kind(char_id: String) -> String:
    return HeroLooks.sheet_kind(char_id, GameData.looks, appearance)


func look_scale(char_id: String) -> float:
    return HeroLooks.draw_scale(char_id, GameData.looks)


## The lead's sprite kind (what the overworld draws).
func lead_kind() -> String:
    return look_kind(lead_id)


func look_to_dict() -> Dictionary:
    return {"lead": lead_id, "appearance": appearance.duplicate()}


func look_from_dict(d: Dictionary) -> void:
    var saved_look: Dictionary = d.get("appearance", {})
    appearance = HeroLooks.normalize_appearance(saved_look, GameData.looks)
    lead_id = HeroLooks.valid_lead(str(d.get("lead", "")), GameData.looks, party.roster)
