class_name HeroLooks
extends RefCounted
## Who looks like what (v0.8.0). Pure rules over data/looks.json, no nodes and no autoloads, so the tests cover it.
## Every protagonist has one sprite "kind" (the file prefix in res://assets/art/units/): Torren's kind also carries his
## chosen colourways ("torren_<hair>_<scarf>"), the others are fixed. Unknown characters fall back to the plain Soldier.

const FALLBACK_KIND := "soldier"
const DEFAULT_SCALE := 1.0


static func heroes(looks: Dictionary) -> Dictionary:
    return looks.get("heroes", {})


## The protagonists in the order the character select shows them (the starting party order).
static func select_order(looks: Dictionary, start: Dictionary) -> Array[String]:
    var out: Array[String] = []
    var hs: Dictionary = heroes(looks)
    for cid in (start.get("party", []) as Array):
        if hs.has(str(cid)):
            out.append(str(cid))
    return out


static func default_appearance(looks: Dictionary) -> Dictionary:
    var d: Dictionary = looks.get("appearance_default", {})
    return {"hair": str(d.get("hair", "raven")), "scarf": str(d.get("scarf", "ember"))}


static func _option_ids(looks: Dictionary, group: String) -> Array[String]:
    var ids: Array[String] = []
    var opts: Dictionary = looks.get("appearance_options", {})
    for o in (opts.get(group, []) as Array):
        ids.append(str((o as Dictionary).get("id", "")))
    return ids


## Every key present, every value one of the offered ids (anything else becomes the default).
static func normalize_appearance(app: Dictionary, looks: Dictionary) -> Dictionary:
    var out: Dictionary = default_appearance(looks)
    for group in ["hair", "scarf"]:
        var v: String = str(app.get(group, ""))
        if _option_ids(looks, group).has(v):
            out[group] = v
    return out


## Steps an option: dir +1 / -1, wrapping around. Returns the new appearance.
static func step_option(app: Dictionary, group: String, dir: int, looks: Dictionary) -> Dictionary:
    var ids: Array[String] = _option_ids(looks, group)
    var out: Dictionary = normalize_appearance(app, looks)
    if ids.is_empty():
        return out
    var i: int = ids.find(str(out[group]))
    out[group] = ids[posmod(i + dir, ids.size())]
    return out


static func option_name(looks: Dictionary, group: String, id: String) -> String:
    var opts: Dictionary = looks.get("appearance_options", {})
    for o in (opts.get(group, []) as Array):
        var od: Dictionary = o
        if str(od.get("id", "")) == id:
            return str(od.get("name", id))
    return id


## Sprite kind (file prefix) of a character. Heroes without an entry use the plain Soldier.
static func sheet_kind(char_id: String, looks: Dictionary, app: Dictionary) -> String:
    var h: Dictionary = heroes(looks).get(char_id, {})
    if h.is_empty():
        return FALLBACK_KIND
    var kind: String = str(h.get("kind", FALLBACK_KIND))
    if bool(h.get("customizable", false)):
        var a: Dictionary = normalize_appearance(app, looks)
        return "%s_%s_%s" % [kind, str(a["hair"]), str(a["scarf"])]
    return kind


static func draw_scale(char_id: String, looks: Dictionary) -> float:
    var h: Dictionary = heroes(looks).get(char_id, {})
    return float(h.get("scale", DEFAULT_SCALE))


static func accent(char_id: String, looks: Dictionary) -> Color:
    var h: Dictionary = heroes(looks).get(char_id, {})
    return Color(str(h.get("accent", "#ffffff")))


## A lead must be one of the protagonists that is in the party; otherwise the default lead (or the first in the roster).
static func valid_lead(char_id: String, looks: Dictionary, roster: Array) -> String:
    if heroes(looks).has(char_id) and roster.has(char_id):
        return char_id
    var d: String = str(looks.get("default_lead", ""))
    if roster.has(d):
        return d
    return str(roster[0]) if not roster.is_empty() else ""


## Roster order with the lead first (everyone else keeps their order).
static func roster_with_lead_first(lead_id: String, roster: Array) -> Array[String]:
    var out: Array[String] = []
    if roster.has(lead_id):
        out.append(lead_id)
    for cid in roster:
        if str(cid) != lead_id:
            out.append(str(cid))
    return out
