class_name CharacterSelect
extends Control
## Character select (v0.8.0): the first screen of a new game. Four protagonists stand on a stage with their own sprite
## (animated idle, the selected one also swings or shoots now and then); the right panel shows who they are, how they
## are drawn and their starting stats. Torren's hair and scarf colour can be changed. The choice becomes the lead of
## the party: the one who walks the world and heads the roster.
## It reads no autoloads, so the headless tests can build it: setup(looks, start, characters, classes), then add it
## to the tree. `chosen(lead_id, appearance)` fires once when Begin is pressed (start_scene.gd starts the campaign).

signal chosen(lead_id: String, appearance: Dictionary)

const COL_BG := Color(0.106, 0.092, 0.07)
const COL_PANEL := Color(0.19, 0.155, 0.11)
const COL_CARD := Color(0.255, 0.205, 0.145)
const COL_CARD_SEL := Color(0.36, 0.27, 0.12)
const COL_TILE := Color(0.13, 0.11, 0.085)
const COL_BORDER := Color(0.72, 0.55, 0.32)
const COL_BORDER_DIM := Color(0.46, 0.36, 0.22)
const COL_TEXT := Color(0.94, 0.89, 0.74)
const COL_DIM := Color(0.74, 0.68, 0.55)
const COL_GOLD := Color(1.0, 0.86, 0.3)
const STAT_TILES := [["HP", "hp"], ["STR", "str"], ["DEX", "dex"], ["VIT", "vit"], ["SPD", "spd"], ["EVA", "eva"]]
const SHOWCASE_PERIOD := 3.4          # seconds between the selected hero's attack showcases
const REDRAW_STEP := 0.05             # the stage redraws 20 times a second (battery)

var looks: Dictionary = {}
var start: Dictionary = {}
var characters: Dictionary = {}
var classes: Dictionary = {}
var order: Array[String] = []
var selected: String = ""
var appearance: Dictionary = {}
var clock: float = 0.0
var redraw_acc: float = 0.0
var builds: int = 0                   # tests use it to catch a half-built screen
var done: bool = false
var stage: Control = null
var side: VBoxContainer = null


func setup(p_looks: Dictionary, p_start: Dictionary, p_characters: Dictionary, p_classes: Dictionary) -> void:
    looks = p_looks
    start = p_start
    characters = p_characters
    classes = p_classes
    order = HeroLooks.select_order(looks, start)
    appearance = HeroLooks.default_appearance(looks)
    selected = HeroLooks.valid_lead(str(looks.get("default_lead", "")), looks, order)


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build()


func _process(delta: float) -> void:
    clock += delta
    redraw_acc += delta
    if redraw_acc >= REDRAW_STEP:
        redraw_acc = 0.0
        if stage != null:
            stage.queue_redraw()


# ---------------------------------------------------------------- public actions (what the buttons call)

## Picks a protagonist. Unknown ids are ignored.
func select(char_id: String) -> void:
    if not order.has(char_id):
        return
    selected = char_id
    _refresh()


## Steps Torren's hair or scarf colour (group "hair" or "scarf"); ignored for heroes whose design is fixed.
func step_option(group: String, dir: int) -> void:
    if not _is_customizable(selected):
        return
    appearance = HeroLooks.step_option(appearance, group, dir, looks)
    _refresh()


## Confirms the choice. Fires `chosen` once.
func begin() -> void:
    if done or selected == "":
        return
    done = true
    chosen.emit(selected, appearance.duplicate())


func _is_customizable(char_id: String) -> bool:
    var h: Dictionary = HeroLooks.heroes(looks).get(char_id, {})
    return bool(h.get("customizable", false))


func _refresh() -> void:
    if side != null:
        _fill_side()
    if stage != null:
        stage.queue_redraw()


# ---------------------------------------------------------------- layout

func _style(bg: Color, border: Color, border_w: int = 2, radius: int = 8, margin: float = 12.0) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = bg
    sb.border_color = border
    sb.set_border_width_all(border_w)
    sb.set_corner_radius_all(radius)
    sb.set_content_margin_all(margin)
    return sb


func _text(text: String, font_size: int = 18, color: Color = COL_TEXT) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    return l


## Body text: wraps and fills the row (needs a width, so it is given a minimum).
func _label(text: String, font_size: int = 18, color: Color = COL_TEXT) -> Label:
    var l := Label.new()
    l.text = text
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.custom_minimum_size = Vector2(300, 0)
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    return l


func _skin(b: Button, bg: Color, border: Color, text_col: Color) -> void:
    b.add_theme_stylebox_override("normal", _style(bg, border))
    b.add_theme_stylebox_override("hover", _style(bg.lightened(0.12), border))
    b.add_theme_stylebox_override("pressed", _style(bg.darkened(0.2), COL_GOLD))
    b.add_theme_stylebox_override("disabled", _style(bg.darkened(0.3), border.darkened(0.4)))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.add_theme_color_override("font_color", text_col)
    b.add_theme_color_override("font_hover_color", text_col)
    b.add_theme_color_override("font_pressed_color", COL_GOLD)
    b.focus_mode = Control.FOCUS_NONE


func _button(text: String, handler: Callable, min_size: Vector2, font_size: int = 22, primary: bool = false) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.clip_text = true
    b.add_theme_font_size_override("font_size", font_size)
    if primary:
        _skin(b, COL_CARD_SEL, COL_GOLD, COL_GOLD)
    else:
        _skin(b, COL_CARD, COL_BORDER_DIM, COL_TEXT)
    b.pressed.connect(handler)
    return b


func _tile(caption: String, value: String) -> Control:
    var p := PanelContainer.new()
    p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    p.add_theme_stylebox_override("panel", _style(COL_TILE, COL_BORDER_DIM, 1, 6, 6.0))
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 0)
    var cap := _text(caption, 13, COL_DIM)
    cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var val := _text(value, 22, COL_TEXT)
    val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(cap)
    v.add_child(val)
    p.add_child(v)
    return p


## Insets from the phone's notch and rounded corners (zero on desktop and headless): left, top, right, bottom.
func _safe_insets() -> Array[float]:
    var out: Array[float] = [0.0, 0.0, 0.0, 0.0]
    if not OS.has_feature("mobile") or not is_inside_tree():
        return out
    var win: Vector2i = DisplayServer.window_get_size()
    var safe: Rect2i = DisplayServer.get_display_safe_area()
    var vp: Vector2 = get_viewport().get_visible_rect().size
    if win.x > 0 and win.y > 0 and safe.size.x > 0 and safe.size.y > 0:
        var sx: float = vp.x / float(win.x)
        var sy: float = vp.y / float(win.y)
        out[0] = clampf(float(safe.position.x) * sx, 0.0, 120.0)
        out[1] = clampf(float(safe.position.y) * sy, 0.0, 120.0)
        out[2] = clampf(float(win.x - safe.position.x - safe.size.x) * sx, 0.0, 120.0)
        out[3] = clampf(float(win.y - safe.position.y - safe.size.y) * sy, 0.0, 120.0)
    return out


func _build() -> void:
    for c in get_children():
        remove_child(c)
        c.queue_free()
    builds += 1
    var bg := ColorRect.new()
    bg.color = COL_BG
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(bg)
    var inset: Array[float] = _safe_insets()
    var margin := MarginContainer.new()
    margin.set_anchors_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 20 + int(inset[0]))
    margin.add_theme_constant_override("margin_top", 14 + int(inset[1]))
    margin.add_theme_constant_override("margin_right", 20 + int(inset[2]))
    margin.add_theme_constant_override("margin_bottom", 14 + int(inset[3]))
    add_child(margin)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 8)
    margin.add_child(col)
    col.add_child(_text("Choose your lead", 32, COL_GOLD))
    col.add_child(_label("The lead walks the world and heads the roster. The whole party still fights together.", 17, COL_DIM))
    var row := HBoxContainer.new()
    row.size_flags_vertical = Control.SIZE_EXPAND_FILL
    row.add_theme_constant_override("separation", 14)
    col.add_child(row)
    stage = Control.new()
    stage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    stage.size_flags_vertical = Control.SIZE_EXPAND_FILL
    stage.custom_minimum_size = Vector2(520, 340)
    stage.clip_contents = true
    stage.draw.connect(_draw_stage)
    stage.gui_input.connect(_on_stage_input)
    row.add_child(stage)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(440, 0)
    panel.add_theme_stylebox_override("panel", _style(COL_PANEL, COL_BORDER))
    row.add_child(panel)
    side = VBoxContainer.new()
    side.add_theme_constant_override("separation", 8)
    panel.add_child(side)
    _fill_side()


func _fill_side() -> void:
    for c in side.get_children():
        side.remove_child(c)
        c.queue_free()
    var h: Dictionary = HeroLooks.heroes(looks).get(selected, {})
    var cdef: Dictionary = characters.get(selected, {})
    var cls: Dictionary = classes.get(str(cdef.get("class_id", "")), {})
    var portrait_frame := PanelContainer.new()
    portrait_frame.custom_minimum_size = Vector2(0, 190)
    portrait_frame.add_theme_stylebox_override("panel", _style(COL_TILE, COL_GOLD, 2, 10, 5.0))
    var portrait := TextureRect.new()
    portrait.custom_minimum_size = Vector2(180, 180)
    portrait.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    var portrait_path := str(h.get("portrait", ""))
    if portrait_path != "" and ResourceLoader.exists(portrait_path):
        portrait.texture = load(portrait_path) as Texture2D
    portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
    portrait_frame.add_child(portrait)
    side.add_child(portrait_frame)
    side.add_child(_text(str(cdef.get("name", selected)), 30, COL_TEXT))
    var bar := ColorRect.new()
    bar.color = HeroLooks.accent(selected, looks)
    bar.custom_minimum_size = Vector2(0, 5)
    bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    side.add_child(bar)
    side.add_child(_text("%s  |  House %s  |  Lv %d" % [str(cls.get("name", "")), str(cdef.get("house", "")).capitalize(), int(cdef.get("level", 1))], 17, COL_DIM))
    side.add_child(_label(str(h.get("tagline", "")), 21, COL_GOLD))
    side.add_child(_label(str(h.get("role", "")), 17, COL_TEXT))
    side.add_child(_label(str(h.get("design", "")), 16, COL_DIM))
    var tiles := HBoxContainer.new()
    tiles.add_theme_constant_override("separation", 6)
    var stats: Dictionary = cdef.get("stats", {})
    for t in STAT_TILES:
        tiles.add_child(_tile(str(t[0]), str(int(stats.get(str(t[1]), 0)))))
    side.add_child(tiles)
    if _is_customizable(selected):
        side.add_child(_option_row("hair", "Hair"))
        side.add_child(_option_row("scarf", "Scarf"))
    var spacer := Control.new()
    spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
    spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    side.add_child(spacer)
    var short: String = str(h.get("short", str(cdef.get("name", selected))))
    side.add_child(_button("Begin as %s" % short, begin, Vector2(0, 76), 24, true))


func _option_row(group: String, caption: String) -> Control:
    var r := HBoxContainer.new()
    r.add_theme_constant_override("separation", 8)
    var cap := _text(caption, 18, COL_DIM)
    cap.custom_minimum_size = Vector2(74, 0)
    r.add_child(cap)
    r.add_child(_button("<", step_option.bind(group, -1), Vector2(64, 56), 24))
    var nm := _text(HeroLooks.option_name(looks, group, str(appearance.get(group, ""))), 21, COL_TEXT)
    nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    r.add_child(nm)
    r.add_child(_button(">", step_option.bind(group, 1), Vector2(64, 56), 24))
    return r


# ---------------------------------------------------------------- the stage (sprites)

func _ellipse(center: Vector2, rx: float, ry: float) -> PackedVector2Array:
    var pts := PackedVector2Array()
    for i in range(24):
        var a: float = TAU * float(i) / 24.0
        pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
    return pts


func _draw_stage() -> void:
    if stage == null or order.is_empty() or stage.size.x <= 0.0:
        return
    var sz: Vector2 = stage.size
    var col_w: float = sz.x / float(order.size())
    var feet_y: float = sz.y * 0.66
    var font: Font = ThemeDB.fallback_font
    for i in range(order.size()):
        var cid: String = order[i]
        var sel: bool = cid == selected
        var acc: Color = HeroLooks.accent(cid, looks)
        var cx: float = col_w * (float(i) + 0.5)
        var card := Rect2(Vector2(col_w * float(i) + 4.0, 4.0), Vector2(col_w - 8.0, sz.y - 8.0))
        stage.draw_rect(card, COL_CARD_SEL.darkened(0.2) if sel else COL_TILE)
        stage.draw_rect(card, COL_GOLD if sel else COL_BORDER_DIM, false, 3.0 if sel else 1.0)
        var ped: PackedVector2Array = _ellipse(Vector2(cx, feet_y + 2.0), col_w * 0.34, 12.0)
        stage.draw_colored_polygon(ped, Color(acc.r, acc.g, acc.b, 0.35 if sel else 0.14))
        var kind: String = HeroArt.usable_kind(HeroLooks.sheet_kind(cid, looks, appearance))
        var base: float = (8.0 if sel else 5.6) * HeroLooks.draw_scale(cid, looks)
        var anim: String = "idle"
        var t: float = clock + float(i) * 0.41
        if sel:
            var cyc: float = fmod(clock, SHOWCASE_PERIOD)
            if cyc > SHOWCASE_PERIOD - HeroArt.duration("attack"):
                anim = "attack"
                t = cyc - (SHOWCASE_PERIOD - HeroArt.duration("attack"))
        var tint: Color = Color.WHITE if sel else Color(0.74, 0.74, 0.74)
        if not HeroArt.draw(stage, kind, anim, t, Vector2(cx, feet_y), base, false, tint):
            stage.draw_rect(Rect2(Vector2(cx - 18.0, feet_y - 70.0), Vector2(36, 70)), acc)
        var cdef: Dictionary = characters.get(cid, {})
        var h: Dictionary = HeroLooks.heroes(looks).get(cid, {})
        var cls: Dictionary = classes.get(str(cdef.get("class_id", "")), {})
        stage.draw_string(font, Vector2(col_w * float(i), feet_y + 52.0), str(h.get("short", cid)), HORIZONTAL_ALIGNMENT_CENTER, col_w, 22, COL_GOLD if sel else COL_TEXT)
        stage.draw_string(font, Vector2(col_w * float(i), feet_y + 74.0), str(cls.get("name", "")), HORIZONTAL_ALIGNMENT_CENTER, col_w, 16, COL_DIM)


func _on_stage_input(event: InputEvent) -> void:
    if order.is_empty() or stage == null:
        return
    if event is InputEventMouseButton:
        var mb: InputEventMouseButton = event
        if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT:
            var col_w: float = stage.size.x / float(order.size())
            var i: int = clampi(int(mb.position.x / col_w), 0, order.size() - 1)
            select(order[i])
