extends Control
class_name HomeScene
## Touch-first campaign entry screen. Save-slot selection and settings are separate home_screen steps.

var continue_button: Button
var status_label: Label
var confirm_new_game: ConfirmationDialog
var slot_picker: SlotPicker
var settings_panel: SettingsPanel


func _ready() -> void:
    _build()
    AudioManager.start_music()


func _build() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var background := ColorRect.new()
    background.color = Color(0.055, 0.07, 0.075, 1.0)
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(background)

    var centre := CenterContainer.new()
    centre.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(centre)

    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(560, 0)
    var panel_style := StyleBoxFlat.new()
    panel_style.bg_color = Color(0.13, 0.12, 0.105, 0.98)
    panel_style.border_color = Color(0.58, 0.47, 0.30, 1.0)
    panel_style.set_border_width_all(2)
    panel_style.set_corner_radius_all(12)
    panel_style.content_margin_left = 30
    panel_style.content_margin_right = 30
    panel_style.content_margin_top = 28
    panel_style.content_margin_bottom = 28
    panel.add_theme_stylebox_override("panel", panel_style)
    centre.add_child(panel)

    var stack := VBoxContainer.new()
    stack.add_theme_constant_override("separation", 14)
    panel.add_child(stack)

    var title := Label.new()
    title.text = "KINDLEWAKE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_color_override("font_color", Color(0.91, 0.82, 0.62, 1.0))
    title.add_theme_font_size_override("font_size", 46)
    stack.add_child(title)

    var subtitle := Label.new()
    subtitle.text = "THE SUNDERED VOW"
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_color_override("font_color", Color(0.72, 0.66, 0.54, 1.0))
    subtitle.add_theme_font_size_override("font_size", 18)
    stack.add_child(subtitle)

    var divider := HSeparator.new()
    stack.add_child(divider)

    status_label = Label.new()
    status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status_label.add_theme_color_override("font_color", Color(0.82, 0.79, 0.70, 1.0))
    status_label.add_theme_font_size_override("font_size", 16)
    stack.add_child(status_label)

    continue_button = _make_button("Continue", _on_continue)
    stack.add_child(continue_button)
    stack.add_child(_make_button("Load Game", _on_load_game))
    stack.add_child(_make_button("New Game", _on_new_game))
    stack.add_child(_make_button("Settings", _on_settings))

    var version_label := Label.new()
    version_label.text = "E L D R I M A R   •   v0.8.7"
    version_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    version_label.add_theme_color_override("font_color", Color(0.58, 0.55, 0.48, 1.0))
    version_label.add_theme_font_size_override("font_size", 13)
    stack.add_child(version_label)

    confirm_new_game = ConfirmationDialog.new()
    confirm_new_game.title = "Begin a new company?"
    confirm_new_game.dialog_text = "Your existing saves will remain available. Continue?"
    confirm_new_game.ok_button_text = "Begin"
    confirm_new_game.confirmed.connect(_start_new_game)
    add_child(confirm_new_game)

    slot_picker = SlotPicker.new()
    add_child(slot_picker)
    slot_picker.selected.connect(_on_slot_selected)

    settings_panel = SettingsPanel.new()
    add_child(settings_panel)
    settings_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    settings_panel.visible = false

    _refresh_save_status()


func _make_button(caption: String, action: Callable) -> Button:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(0, 68)
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.add_theme_font_size_override("font_size", 23)
    button.pressed.connect(action)
    return button


func _refresh_save_status() -> void:
    var slot: String = GameState.newest_save_slot()
    continue_button.disabled = slot == ""
    if slot == "":
        status_label.text = "No company has been saved yet. Begin a new journey."
    else:
        var info: Dictionary = SaveSystem.slot_info(slot)
        status_label.text = "Last company\n%s" % str(info.get("summary", "Save available"))


func _on_continue() -> void:
    var error_text: String = GameState.load_newest()
    if error_text != "":
        status_label.text = error_text
        _refresh_save_status()
        return
    GameState.booted = true
    _open_saved_location()


func _on_load_game() -> void:
    slot_picker.open("load")


func _on_slot_selected(slot_id: String, mode: String) -> void:
    if mode != "load":
        return
    var result: Dictionary = SaveSystem.load_slot(slot_id)
    if not bool(result.get("ok", false)):
        status_label.text = str(result.get("error", "Load failed."))
        return
    var payload: Dictionary = result.get("payload", {})
    if payload.has("battle"):
        status_label.text = "That slot contains a battle save. Load it from inside a battle."
        return
    GameState.apply_payload(payload)
    GameState.booted = true
    _open_saved_location()


func _open_saved_location() -> void:
    if GameState.prepare_saved_room():
        get_tree().change_scene_to_file("res://Room.tscn")
    else:
        get_tree().change_scene_to_file("res://World.tscn")


func _on_settings() -> void:
    settings_panel.open()


func _on_new_game() -> void:
    confirm_new_game.popup_centered(Vector2i(520, 220))


func _start_new_game() -> void:
    get_tree().change_scene_to_file("res://CharacterSelect.tscn")
