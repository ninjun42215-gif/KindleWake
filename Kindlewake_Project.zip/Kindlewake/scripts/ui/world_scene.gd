extends Node2D
## Overworld (Milestone 7): walk freely over Eldrimar, a 452 x 340 tile world of eight regions and 39 places.
## Touch: tap to walk to a spot, hold and drag to steer. Terrain changes speed; forests and marsh are more dangerous,
## and each region ambushes you with its own enemies on a battle map cut from the terrain you stand on.
## Towns have shops (only there can you buy, sell, change gear, sigils and rank); the wilderness is view-only.
## Rules live in WorldMap / EncounterBuilder / GameState; battles reuse the battle scene through GameState.start_battle_from_world().

const TILE := 48.0
const WALK_SPEED := 230.0
const PLAYER_RADIUS := 12.0
const INTERACT_RADIUS := 64.0
const AMBUSH_DELAY := 0.9
const SIGHT_TILES := 13.0
const MAP_STEP := 2                      # one minimap pixel covers 2 x 2 tiles
const MAP_VIEW_SCALE := 2.3              # world-map overlay: screen pixels per minimap pixel
const TOWN_KINDS: Array[String] = ["keep", "city", "town", "village"]
const ROMAN: Array[String] = ["I", "II", "III", "IV", "V"]
const TERRAIN_COLORS: Array[Color] = [
    Color("#41714f"), Color("#2f4a38"), Color("#6f8f5a"), Color("#5c7f94"),
    Color("#2d4a63"), Color("#5d6470"), Color("#8a6b4a"), Color("#b78b52"),
    Color("#b8a06a"), Color("#d5dde6"), Color("#55704a"),
]
## Which recoloured building set each region uses (see tools/render_voxels.py): the sandy originals stay in Vessmoor.
const REGION_PALETTE := {
    "sethmarch": "thatch", "orrowen": "thatch", "ysmark": "thatch", "aurelmont": "stone", "vessmoor": "sand",
    "tarnholt": "stone", "quillon": "stone", "brennhallow": "slate",
}
## Sprites that make up each kind of place: [sprite, x offset, y offset] from the place centre (feet of the sprite).
const PLACE_LAYOUT := {
    "village": [["small1", -26, 10], ["tiny", 30, 14], ["small3", 4, 24]],
    "town": [["large1", -4, 8], ["small4", -48, 22], ["small1", 46, 24], ["tiny", 10, 36]],
    "city": [["tall1", -50, 6], ["tall2", 52, 8], ["large1", 0, 22], ["small3", -66, 36], ["small4", 68, 38]],
    "keep": [["tall3", 0, 4], ["tall1", -56, 16], ["tall2", 58, 16], ["large1", 0, 34]],
    "ruin": [["tiny", -12, 12], ["rock1", 20, 20], ["rock4", -34, 26]],
}
const SPRITE_DIR := "res://assets/sprites/world/"
const SOLDIER_DIR := "res://assets/sprites/characters/soldier/"
const FRAME := 100.0                     # Tiny RPG sheets: square frames side by side
const FIGURE_FEET := Vector2(49.5, 60.0) # where the soldier's feet are inside a frame
const FIGURE_SCALE := 2.4

var wmap: WorldMap
var camera: Camera2D
var rng := RandomNumberGenerator.new()
var player_pos: Vector2 = Vector2.ZERO
var target: Vector2 = Vector2.ZERO
var has_target: bool = false
var pressing: bool = false
var facing_left: bool = false
var walk_phase: float = 0.0
var danger_accum: float = 0.0
var next_threshold: float = 1200.0
var ambush_timer: float = -1.0
var toast_timer: float = -1.0
var near_place: Dictionary = {}
var hud_text: String = ""
var new_confirm: bool = false
var tex_cache: Dictionary = {}
var map_tex: ImageTexture
var soldier_idle: Texture2D
var soldier_walk: Texture2D

var hud_root: Control
var party_root: Control
var info_label: Label
var prompt_btn: Button
var place_panel: PanelContainer
var place_title: Label
var place_region: Label
var place_text: Label
var place_buttons: VBoxContainer
var banner: PanelContainer
var banner_label: Label
var party_screen: PartyScreen
var minimap_dot: ColorRect
var menu_panel: PanelContainer
var menu_msg: Label
var map_panel: PanelContainer
var map_markers: Control
var boot_panel: PanelContainer
var boot_msg: Label
var boot_buttons: VBoxContainer


func _ready() -> void:
    rng.randomize()
    wmap = WorldMap.generate(GameData.world, GameData.world_map)
    camera = Camera2D.new()
    add_child(camera)
    camera.make_current()
    camera.zoom = Vector2(1.1, 1.1)
    _load_lead_sprites()
    _place_player_from_state()
    camera.position = player_pos
    _roll_threshold()
    _build_ui()
    _build_map_texture()
    GameState.from_world = true
    if not SaveSystem.app_paused.is_connected(_on_app_paused):
        SaveSystem.app_paused.connect(_on_app_paused)
    _update_seen()
    if not GameState.booted:
        _show_boot()


func _place_player_from_state() -> void:
    if GameState.world_pos == Vector2.ZERO:
        player_pos = cell_center(wmap.start_cell)
    else:
        player_pos = GameState.world_pos
    has_target = false
    pressing = false
    danger_accum = 0.0


func cell_center(c: Vector2i) -> Vector2:
    return (Vector2(c) + Vector2(0.5, 0.5)) * TILE


func cell_of(pos: Vector2) -> Vector2i:
    return Vector2i(floori(pos.x / TILE), floori(pos.y / TILE))


func _place_cell(p: Dictionary) -> Vector2i:
    var a: Array = p.get("cell", [0, 0])
    return Vector2i(int(a[0]), int(a[1]))


## The walker is the lead picked in the character select (hero sheets); the Soldier when a sheet is missing.
func _load_lead_sprites() -> void:
    var kind: String = HeroArt.usable_kind(GameState.lead_kind())
    soldier_idle = HeroArt.sheet(kind, "idle")
    soldier_walk = HeroArt.sheet(kind, "walk")
    if soldier_idle == null:
        soldier_idle = _load_tex(SOLDIER_DIR + "Soldier_Idle.png")
    if soldier_walk == null:
        soldier_walk = _load_tex(SOLDIER_DIR + "Soldier_Walk.png")


func _load_tex(path: String) -> Texture2D:
    if ResourceLoader.exists(path):
        return load(path) as Texture2D
    return null


## Sprite by name from assets/sprites/world; null when the file is missing (the scene then draws simple shapes).
func _get_tex(sprite_name: String) -> Texture2D:
    if not tex_cache.has(sprite_name):
        tex_cache[sprite_name] = _load_tex(SPRITE_DIR + sprite_name + ".png")
    return tex_cache[sprite_name]


func _roll_threshold() -> void:
    var tier: int = wmap.tier_at(cell_of(player_pos))
    next_threshold = WorldMap.encounter_threshold(GameData.world, rng.randf()) * (1.0 - 0.06 * float(tier - 1))


func _blocked() -> bool:
    return place_panel.visible or menu_panel.visible or map_panel.visible or boot_panel.visible or party_screen.visible or ambush_timer >= 0.0


# ------------------------------------------------------------------ input and movement

func _unhandled_input(event: InputEvent) -> void:
    if _blocked():
        return
    if event is InputEventMouseButton:
        var mb := event as InputEventMouseButton
        if mb.button_index == MOUSE_BUTTON_LEFT:
            pressing = mb.pressed
            if mb.pressed:
                _set_target(mb.position)
    elif event is InputEventMouseMotion and pressing:
        _set_target((event as InputEventMouseMotion).position)


func _set_target(screen_pos: Vector2) -> void:
    target = get_canvas_transform().affine_inverse() * screen_pos
    has_target = true


func _free_at(p: Vector2) -> bool:
    var r: float = PLAYER_RADIUS * 0.7
    for off in [Vector2(-r, -r), Vector2(r, -r), Vector2(-r, r), Vector2(r, r)]:
        if not wmap.walkable(cell_of(p + off)):
            return false
    return true


func _process(delta: float) -> void:
    if toast_timer >= 0.0:
        toast_timer -= delta
        if toast_timer < 0.0 and ambush_timer < 0.0:
            banner.visible = false
    if ambush_timer >= 0.0:
        ambush_timer -= delta
        if ambush_timer < 0.0:
            _launch_ambush()
        queue_redraw()
        return
    if not _blocked():
        _move(delta)
        _update_near()
        _update_seen()
    GameState.world_pos = player_pos
    camera.position = camera.position.lerp(player_pos, clampf(delta * 8.0, 0.0, 1.0))
    _update_hud()
    queue_redraw()


func _move(delta: float) -> void:
    if not has_target:
        return
    var to: Vector2 = target - player_pos
    var dist: float = to.length()
    if dist < 4.0:
        has_target = false
        return
    var cell: Vector2i = cell_of(player_pos)
    var step: float = minf(dist, WALK_SPEED * wmap.speed_at(cell) * delta)
    var dir: Vector2 = to / dist
    var before: Vector2 = player_pos
    var nx: Vector2 = player_pos + Vector2(dir.x * step, 0.0)
    if _free_at(nx):
        player_pos = nx
    var ny: Vector2 = player_pos + Vector2(0.0, dir.y * step)
    if _free_at(ny):
        player_pos = ny
    var moved: float = player_pos.distance_to(before)
    if moved < 0.01:
        if not pressing:
            has_target = false
        return
    if absf(dir.x) > 0.2:
        facing_left = dir.x < 0.0
    walk_phase += moved * 0.12
    _accumulate_danger(moved, cell)


func _in_safe_zone(cell: Vector2i) -> bool:
    var radius: float = float(GameData.world.get("safe_radius", 5))
    for p in wmap.places:
        var d: Dictionary = p
        if TOWN_KINDS.has(str(d.get("kind", ""))):
            if Vector2(cell - _place_cell(d)).length() < radius:
                return true
    return false


func _accumulate_danger(dist: float, cell: Vector2i) -> void:
    if _in_safe_zone(cell):
        return
    danger_accum += dist * wmap.danger_at(cell)
    if danger_accum >= next_threshold:
        danger_accum = 0.0
        _roll_threshold()
        has_target = false
        pressing = false
        ambush_timer = AMBUSH_DELAY
        var rid: String = wmap.region_id_at(cell)
        var reg: Dictionary = (GameData.encounters.get("regions", {}) as Dictionary).get(rid, {})
        banner_label.text = "Ambush! " + str(reg.get("ambush", "Enemies attack!"))
        banner.visible = true


func _launch_ambush() -> void:
    var def: Dictionary = GameState.ambush_def(wmap, cell_of(player_pos))
    if def.is_empty():
        banner.visible = false
        return
    _go_to_battle(def, "")


func _go_to_battle(def: Dictionary, place_id: String) -> void:
    GameState.world_pos = player_pos
    GameState.start_battle_from_world(def, place_id)
    get_tree().change_scene_to_file("res://Main.tscn")


func _toast(text: String, seconds: float = 2.2) -> void:
    if ambush_timer >= 0.0:
        return
    banner_label.text = text
    banner.visible = true
    toast_timer = seconds


func _on_app_paused() -> void:
    if GameState.booted:
        GameState.world_pos = player_pos
        GameState.autosave_world()


# ------------------------------------------------------------------ places

func _is_seen(id: String) -> bool:
    return bool(GameState.world_flags.get("seen_" + id, false))


## A place becomes known (drawn, named on the map) once you come within sight of it.
func _update_seen() -> void:
    for p in wmap.places:
        var d: Dictionary = p
        var id: String = str(d.get("id", ""))
        if _is_seen(id):
            continue
        if cell_center(_place_cell(d)).distance_to(player_pos) < SIGHT_TILES * TILE:
            GameState.world_flags["seen_" + id] = true
            if id != "sethorn":
                _toast("Discovered: %s" % str(d.get("name", "a place")))


func _update_near() -> void:
    var best: Dictionary = {}
    var best_d: float = INTERACT_RADIUS
    for p in wmap.places:
        var d: Dictionary = p
        var dist: float = cell_center(_place_cell(d)).distance_to(player_pos)
        if dist < best_d:
            best_d = dist
            best = d
    near_place = best
    prompt_btn.visible = not best.is_empty() and not _blocked()
    if not best.is_empty():
        prompt_btn.text = "Enter %s" % str(best.get("name", "place"))


func _on_prompt_pressed() -> void:
    if not near_place.is_empty():
        _open_place(near_place, "", true)


func _clear_children(node: Node) -> void:
    for c in node.get_children():
        node.remove_child(c)
        c.queue_free()


func _open_place(p: Dictionary, extra: String = "", fresh: bool = false) -> void:
    has_target = false
    pressing = false
    prompt_btn.visible = false
    var id: String = str(p.get("id", ""))
    var kind: String = str(p.get("kind", ""))
    var region: Dictionary = wmap.region_at(_place_cell(p))
    place_title.text = str(p.get("name", "Place"))
    place_region.text = "%s  |  Danger %s" % [str(region.get("name", "")), ROMAN[clampi(int(region.get("tier", 1)) - 1, 0, 4)]]
    var text: String = str(p.get("text", ""))
    _clear_children(place_buttons)
    var site_id: String = str(p.get("site", ""))
    if site_id != "" and GameData.sites.has(site_id):
        place_buttons.add_child(_btn("Enter: %s" % str((GameData.sites[site_id] as Dictionary).get("name", "the way in")), _enter_site.bind(p), 24))
    if TOWN_KINDS.has(kind):
        if fresh:
            GameState.world_pos = player_pos
            GameState.autosave_world()
        for sid in GameData.shops_at(id):
            var shop: Dictionary = GameData.shop_def(str(sid))
            place_buttons.add_child(_btn("Shop: %s" % str(shop.get("name", "Shop")), _open_shop.bind(str(sid)), 22))
        place_buttons.add_child(_btn("Party and Gear", _open_party_edit, 22))
        place_buttons.add_child(_btn("Tavern rumours", _on_rumour.bind(p), 22))
    elif kind == "ruin":
        if bool(GameState.world_flags.get("looted_" + id, false)):
            text += "\n\nYou already searched here."
        else:
            place_buttons.add_child(_btn("Search the ruins", _on_search.bind(p), 24))
    elif kind == "camp":
        if bool(GameState.world_flags.get("cleared_" + id, false)):
            text += "\n\nThe camp lies broken. The raiders are gone."
        else:
            place_buttons.add_child(_btn("Attack the camp", _on_attack_camp.bind(p), 24))
    if extra != "":
        text += "\n\n" + extra
    place_text.text = text
    place_buttons.add_child(_btn("Leave", _close_place, 24))
    place_panel.visible = true


## Walk into a pre-rendered keep or dungeon (data/sites.json). Leaving it puts us back on the map at this spot.
func _enter_site(p: Dictionary) -> void:
    GameState.world_pos = player_pos
    GameState.pending_site = str(p.get("site", ""))
    GameState.pending_room = ""
    GameState.pending_spawn = []
    GameState.autosave_world()
    get_tree().change_scene_to_file("res://Room.tscn")


func _close_place() -> void:
    place_panel.visible = false


func _on_rumour(p: Dictionary) -> void:
    var region: Dictionary = wmap.region_at(_place_cell(p))
    var lines: Array = region.get("rumours", [])
    var line: String = "Nobody here has anything to say."
    if not lines.is_empty():
        line = "\"%s\"" % str(lines[rng.randi_range(0, lines.size() - 1)])
    _open_place(p, line)


func _on_search(p: Dictionary) -> void:
    var id: String = str(p.get("id", ""))
    var gold: int = int(p.get("reward_gold", 0))
    var msg: String = "You find a purse: +%d gold." % gold
    GameState.party.gold += gold
    var item_id: String = str(p.get("reward_item", ""))
    if item_id != "":
        var items: Dictionary = GameData.items
        var item_name: String = str((items.get(item_id, {}) as Dictionary).get("name", item_id))
        GameState.party.add_item(item_id)
        msg += "\nIn the rubble you also find: %s." % item_name
    GameState.world_flags["looted_" + id] = true
    _open_place(p, msg)


func _on_attack_camp(p: Dictionary) -> void:
    var def: Dictionary = GameState.camp_def(wmap, p)
    if def.is_empty():
        _open_place(p, "The camp is deserted.")
        return
    _go_to_battle(def, str(p.get("id", "")))


# ------------------------------------------------------------------ party screen (own top layer)

## View only: the wilderness is no place to change gear, sigils or rank, and there is no shop.
func _open_party_view() -> void:
    party_screen.setup(GameState.party, GameData.party_db(), {}, false)
    party_screen.open()


## Inside a town: gear, sigils and promotion, but no shop tab.
func _open_party_edit() -> void:
    party_screen.setup(GameState.party, GameData.party_db(), {}, true)
    party_screen.open()


## A town shop: the Shop tab opens first, the character sheets stay one tap away.
func _open_shop(shop_id: String) -> void:
    party_screen.setup(GameState.party, GameData.party_db(), GameData.shop_def(shop_id), true)
    party_screen.open(PartyScreen.TAB_SHOP)


func _on_party_closed() -> void:
    hud_text = ""


# ------------------------------------------------------------------ start menu and save/load

func _show_boot() -> void:
    new_confirm = false
    _clear_children(boot_buttons)
    var slot: String = GameState.newest_save_slot()
    if slot != "":
        var info: Dictionary = SaveSystem.slot_info(slot)
        boot_msg.text = "Last save: %s\n%s" % [str(info.get("summary", "")), str(info.get("saved_at", ""))]
        boot_buttons.add_child(_btn("Continue", _on_continue, 28))
    else:
        boot_msg.text = "A new company rides out from Kaer Sethorn."
    boot_buttons.add_child(_btn("New Game", _on_new_game, 28))
    boot_panel.visible = true
    prompt_btn.visible = false


func _on_continue() -> void:
    var err: String = GameState.load_newest()
    if err != "":
        boot_msg.text = err
        return
    _after_load()
    boot_panel.visible = false
    GameState.booted = true


func _on_new_game() -> void:
    if GameState.newest_save_slot() != "" and not new_confirm:
        new_confirm = true
        boot_msg.text = "Starting over leaves your old saves in place until new autosaves overwrite them.\nPress New Game again to confirm."
        return
    if ResourceLoader.exists("res://CharacterSelect.tscn"):
        get_tree().change_scene_to_file("res://CharacterSelect.tscn")      # pick the lead first; it starts the campaign
        return
    GameState.new_game()
    GameState.booted = true
    _after_load()
    boot_panel.visible = false


## Puts the walker where the (just loaded or newly started) game says it is.
func _after_load() -> void:
    _load_lead_sprites()
    _place_player_from_state()
    camera.position = player_pos
    _roll_threshold()
    GameState.from_world = true
    _update_seen()
    _build_map_texture()
    hud_text = ""


func _open_menu() -> void:
    menu_msg.text = "Places discovered: %d of %d" % [GameState.visited_count(), wmap.places.size()]
    menu_panel.visible = true
    prompt_btn.visible = false


func _on_save_pressed() -> void:
    GameState.world_pos = player_pos
    if GameState.save_world("world"):
        menu_msg.text = "Game saved."
    else:
        menu_msg.text = "Save failed."


func _on_load_pressed() -> void:
    var err: String = GameState.load_newest()
    if err != "":
        menu_msg.text = err
        return
    _after_load()
    menu_panel.visible = false
    _toast("Game loaded.")


# ------------------------------------------------------------------ drawing

func _draw() -> void:
    if wmap == null:
        return
    var inv: Transform2D = get_canvas_transform().affine_inverse()
    var vp: Vector2 = get_viewport_rect().size
    var tl: Vector2 = inv * Vector2.ZERO
    var br: Vector2 = inv * vp
    var x0: int = clampi(floori(tl.x / TILE) - 1, 0, wmap.width - 1)
    var y0: int = clampi(floori(tl.y / TILE) - 1, 0, wmap.height - 1)
    var x1: int = clampi(floori(br.x / TILE) + 1, 0, wmap.width - 1)
    var y1: int = clampi(floori(br.y / TILE) + 1, 0, wmap.height - 1)
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            _draw_tile(Vector2i(x, y))
    for y in range(y0, y1 + 2):               # rocks stand on their tile and overlap the row above: draw after the ground
        for x in range(x0, x1 + 1):
            if wmap.in_bounds(Vector2i(x, y)) and wmap.terrain_at(Vector2i(x, y)) == WorldMap.MOUNTAIN:
                _draw_rock(Vector2i(x, y))
    for p in wmap.places:
        _draw_place(p, tl, br)
    _draw_player()


func _draw_tile(c: Vector2i) -> void:
    var t: int = wmap.terrain_at(c)
    var base: Color = TERRAIN_COLORS[t]
    var f: float = 0.93 + 0.14 * WorldMap.hash01(c.x, c.y, 3)
    var col := Color(base.r * f, base.g * f, base.b * f)
    var origin := Vector2(float(c.x), float(c.y)) * TILE
    draw_rect(Rect2(origin, Vector2(TILE + 0.5, TILE + 0.5)), col)
    var h: float = WorldMap.hash01(c.x, c.y, 11)
    if t == WorldMap.FOREST:
        for i in range(2):
            var o := Vector2(TILE * (0.28 + 0.44 * float(i)), TILE * (0.62 - 0.12 * h * float(i + 1)))
            draw_colored_polygon(PackedVector2Array([origin + o + Vector2(-9, 8), origin + o + Vector2(9, 8), origin + o + Vector2(0, -14)]), Color(0.14, 0.30, 0.20))
    elif t == WorldMap.HILL:
        draw_arc(origin + Vector2(TILE * 0.5, TILE * 0.75), 16.0, PI, TAU, 10, Color(0.45, 0.60, 0.36), 3.0)
    elif t == WorldMap.WATER or t == WorldMap.FORD:
        if h > 0.55:
            draw_line(origin + Vector2(10, 20), origin + Vector2(26, 20), Color(1, 1, 1, 0.18), 2.0)
    elif t == WorldMap.BRIDGE:
        draw_rect(Rect2(origin + Vector2(0, 6), Vector2(TILE, TILE - 12)), Color(0.55, 0.40, 0.22))
    elif t == WorldMap.MARSH:
        if h > 0.35:
            draw_line(origin + Vector2(14, 34), origin + Vector2(14, 20), Color(0.30, 0.42, 0.24), 2.0)
            draw_line(origin + Vector2(22, 34), origin + Vector2(24, 18), Color(0.30, 0.42, 0.24), 2.0)
    elif t == WorldMap.SAND:
        if h > 0.7:
            draw_line(origin + Vector2(8, 30), origin + Vector2(22, 28), Color(0.72, 0.60, 0.38), 2.0)
    elif t == WorldMap.SNOW:
        if h > 0.7:
            draw_circle(origin + Vector2(30, 14), 3.0, Color(1, 1, 1, 0.5))


func _draw_rock(c: Vector2i) -> void:
    var h: float = WorldMap.hash01(c.x, c.y, 29)
    var variant: String = "sand" if wmap.region_id_at(c) == "vessmoor" else "grey"
    var tex: Texture2D = _get_tex("rock%d_%s" % [int(h * 9.99), variant])
    var origin := Vector2(float(c.x) + 0.5, float(c.y) + 1.0) * TILE
    if tex == null:
        draw_colored_polygon(PackedVector2Array([origin + Vector2(-20, -4), origin + Vector2(20, -4), origin + Vector2(0, -42)]), Color(0.46, 0.50, 0.57))
        return
    var sz: Vector2 = tex.get_size()
    draw_texture(tex, origin + Vector2(-sz.x * 0.5, -sz.y + 8.0))


func _draw_place(p: Dictionary, tl: Vector2, br: Vector2) -> void:
    var id: String = str(p.get("id", ""))
    if not _is_seen(id):
        return
    var kind: String = str(p.get("kind", ""))
    var c: Vector2 = cell_center(_place_cell(p))
    if c.x < tl.x - 260.0 or c.x > br.x + 260.0 or c.y < tl.y - 260.0 or c.y > br.y + 200.0:
        return
    draw_colored_polygon(_ellipse(c + Vector2(0, 14), 46.0 if kind == "city" or kind == "keep" else 32.0, 12.0), Color(0, 0, 0, 0.25))
    var palette: String = str(REGION_PALETTE.get(str(p.get("region", "")), "stone"))
    if kind == "keep":
        palette = "stone"
    var drew: bool = false
    var layout: Array = PLACE_LAYOUT.get(kind, [])
    for item in layout:
        var base_name: String = str(item[0])
        var sprite_name: String = base_name + "_" + palette
        if base_name.begins_with("rock"):
            sprite_name = base_name + "_" + ("sand" if palette == "sand" else "grey")
        var tex: Texture2D = _get_tex(sprite_name)
        if tex == null:
            continue
        drew = true
        var sz: Vector2 = tex.get_size()
        draw_texture(tex, c + Vector2(float(item[1]) - sz.x * 0.5, float(item[2]) - sz.y))
    if not drew:
        _draw_place_fallback(kind, c)
    if kind == "camp":
        _draw_camp(c, bool(GameState.world_flags.get("cleared_" + id, false)))
    var font: Font = ThemeDB.fallback_font
    var label: String = str(p.get("name", ""))
    var ly: float = 56.0 if (kind == "city" or kind == "keep") else 46.0
    draw_string(font, c + Vector2(-99, ly + 1), label, HORIZONTAL_ALIGNMENT_CENTER, 200, 18, Color(0, 0, 0, 0.85))
    draw_string(font, c + Vector2(-100, ly), label, HORIZONTAL_ALIGNMENT_CENTER, 200, 18, Color(1.0, 0.95, 0.8))


func _draw_place_fallback(kind: String, c: Vector2) -> void:
    if kind == "keep" or kind == "city":
        draw_rect(Rect2(c + Vector2(-20, -18), Vector2(40, 32)), Color(0.55, 0.55, 0.58))
        draw_rect(Rect2(c + Vector2(-24, -28), Vector2(12, 16)), Color(0.48, 0.48, 0.52))
        draw_rect(Rect2(c + Vector2(12, -28), Vector2(12, 16)), Color(0.48, 0.48, 0.52))
        draw_rect(Rect2(c + Vector2(-6, -2), Vector2(12, 16)), Color(0.15, 0.12, 0.10))
    elif kind == "village" or kind == "town":
        for i in range(3):
            var o := Vector2(-18.0 + 18.0 * float(i), 4.0 - 6.0 * float(i % 2))
            draw_rect(Rect2(c + o + Vector2(-7, -6), Vector2(14, 12)), Color(0.62, 0.48, 0.32))
            draw_colored_polygon(PackedVector2Array([c + o + Vector2(-9, -6), c + o + Vector2(9, -6), c + o + Vector2(0, -16)]), Color(0.65, 0.25, 0.2))
    elif kind == "ruin":
        for i in range(3):
            var hgt: float = 14.0 + 8.0 * float(i % 2)
            draw_rect(Rect2(c + Vector2(-16.0 + 14.0 * float(i), -hgt), Vector2(8, hgt + 6)), Color(0.62, 0.62, 0.60))


func _draw_camp(c: Vector2, cleared: bool) -> void:
    var tent: Color = Color(0.5, 0.5, 0.5) if cleared else Color(0.70, 0.22, 0.18)
    draw_colored_polygon(PackedVector2Array([c + Vector2(-16, 12), c + Vector2(16, 12), c + Vector2(0, -16)]), tent)
    for i in range(5):
        draw_line(c + Vector2(-26.0 + 13.0 * float(i), 16), c + Vector2(-26.0 + 13.0 * float(i), 2), Color(0.45, 0.32, 0.2), 4.0)


func _draw_player() -> void:
    var p: Vector2 = player_pos
    draw_colored_polygon(_ellipse(p + Vector2(0, 6), 13.0, 5.0), Color(0, 0, 0, 0.35))
    var tex: Texture2D = soldier_walk if has_target else soldier_idle
    if tex != null:
        var frames: int = maxi(1, int(tex.get_width() / FRAME))
        var frame: int = floori(float(Time.get_ticks_msec()) / (90.0 if has_target else 140.0)) % frames
        var flip: float = -1.0 if facing_left else 1.0
        draw_set_transform(p, 0.0, Vector2(flip, 1.0))
        var fig: float = FIGURE_SCALE * GameState.look_scale(GameState.lead_id)
        draw_texture_rect_region(tex, Rect2(-FIGURE_FEET.x * fig, -FIGURE_FEET.y * fig + 6.0, FRAME * fig, FRAME * fig), Rect2(float(frame) * FRAME, 0.0, FRAME, FRAME))
        draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    else:
        var bob: float = absf(sin(walk_phase)) * 3.0 if has_target else 0.0
        var q: Vector2 = p + Vector2(0, -bob)
        draw_rect(Rect2(q + Vector2(-8, -18), Vector2(16, 22)), Color(0.22, 0.50, 0.88))
        draw_rect(Rect2(q + Vector2(-6, -28), Vector2(12, 11)), Color(0.72, 0.73, 0.70))
        draw_rect(Rect2(q + Vector2(-4, -25), Vector2(8, 3)), Color(0.16, 0.18, 0.20))
    if has_target and not _blocked():
        draw_arc(target, 8.0, 0.0, TAU, 16, Color(1, 1, 1, 0.5), 2.0)


func _ellipse(center: Vector2, rx: float, ry: float) -> PackedVector2Array:
    var pts := PackedVector2Array()
    for i in range(16):
        var a: float = TAU * float(i) / 16.0
        pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
    return pts


# ------------------------------------------------------------------ HUD

func _hud_panel(alpha: float = 0.84) -> PanelContainer:
    var p := PanelContainer.new()
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.09, 0.08, 0.07, alpha)
    sb.border_color = Color(0.62, 0.52, 0.34, 0.9)
    sb.set_border_width_all(2)
    sb.set_corner_radius_all(8)
    sb.set_content_margin_all(10)
    p.add_theme_stylebox_override("panel", sb)
    return p


func _btn(text: String, handler: Callable, font_size: int = 24) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(300, 72)
    b.add_theme_font_size_override("font_size", font_size)
    b.pressed.connect(handler)
    return b


func _apply_safe_area() -> void:
    if hud_root == null or not is_inside_tree():
        return
    var l: float = 0.0
    var t: float = 0.0
    var r: float = 0.0
    var b: float = 0.0
    if OS.has_feature("mobile"):
        var win: Vector2i = DisplayServer.window_get_size()
        var safe: Rect2i = DisplayServer.get_display_safe_area()
        var vp: Vector2 = get_viewport().get_visible_rect().size
        if win.x > 0 and win.y > 0 and safe.size.x > 0 and safe.size.y > 0:
            var sx: float = vp.x / float(win.x)
            var sy: float = vp.y / float(win.y)
            l = clampf(float(safe.position.x) * sx, 0.0, 120.0)
            t = clampf(float(safe.position.y) * sy, 0.0, 120.0)
            r = clampf(float(win.x - safe.position.x - safe.size.x) * sx, 0.0, 120.0)
            b = clampf(float(win.y - safe.position.y - safe.size.y) * sy, 0.0, 120.0)
    for ctrl in [hud_root, party_root]:
        var c: Control = ctrl
        if c != null:
            c.offset_left = l
            c.offset_top = t
            c.offset_right = -r
            c.offset_bottom = -b


func _centre(panel: Control) -> void:
    hud_root.add_child(panel)
    panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
    panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
    panel.grow_vertical = Control.GROW_DIRECTION_BOTH
    panel.visible = false


func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud_root = root

    # The party screen lives on its own, higher layer so the minimap and HUD can never draw over it.
    var party_layer := CanvasLayer.new()
    party_layer.layer = 20
    add_child(party_layer)
    party_root = Control.new()
    party_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    party_layer.add_child(party_root)
    party_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    get_viewport().size_changed.connect(_apply_safe_area)
    call_deferred("_apply_safe_area")

    # Top-left: region, terrain, gold
    var info_panel := _hud_panel()
    info_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    info_label = Label.new()
    info_label.custom_minimum_size = Vector2(300, 0)
    info_label.add_theme_font_size_override("font_size", 20)
    info_panel.add_child(info_label)
    root.add_child(info_panel)
    info_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 12)

    # Top-right: Map, Company, Menu
    var top_right := HBoxContainer.new()
    top_right.add_theme_constant_override("separation", 8)
    top_right.add_child(_top_button("Map", _open_map))
    top_right.add_child(_top_button("Company", _open_party_view))
    top_right.add_child(_top_button("Menu", _open_menu))
    root.add_child(top_right)
    top_right.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 12)
    top_right.grow_horizontal = Control.GROW_DIRECTION_BEGIN

    # Top-centre: banner (ambush and toasts)
    banner = _hud_panel(0.95)
    banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    banner_label = Label.new()
    banner_label.add_theme_font_size_override("font_size", 28)
    banner.add_child(banner_label)
    banner.visible = false
    root.add_child(banner)
    banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 90)
    banner.grow_horizontal = Control.GROW_DIRECTION_BOTH

    # Bottom-centre: enter-place prompt
    prompt_btn = _btn("Enter", _on_prompt_pressed, 28)
    prompt_btn.custom_minimum_size = Vector2(380, 84)
    prompt_btn.visible = false
    root.add_child(prompt_btn)
    prompt_btn.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 16)
    prompt_btn.grow_horizontal = Control.GROW_DIRECTION_BOTH
    prompt_btn.grow_vertical = Control.GROW_DIRECTION_BEGIN

    # Centre: place panel
    place_panel = _hud_panel(0.97)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    place_title = Label.new()
    place_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    place_title.add_theme_font_size_override("font_size", 36)
    place_region = Label.new()
    place_region.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    place_region.add_theme_font_size_override("font_size", 18)
    place_region.add_theme_color_override("font_color", Color(0.78, 0.68, 0.42))
    place_text = Label.new()
    place_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    place_text.custom_minimum_size = Vector2(560, 0)
    place_text.add_theme_font_size_override("font_size", 21)
    place_buttons = VBoxContainer.new()
    place_buttons.add_theme_constant_override("separation", 8)
    var scroll := ScrollContainer.new()
    scroll.custom_minimum_size = Vector2(580, 300)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    var inner := VBoxContainer.new()
    inner.add_theme_constant_override("separation", 10)
    inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    inner.add_child(place_text)
    inner.add_child(place_buttons)
    scroll.add_child(inner)
    box.add_child(place_title)
    box.add_child(place_region)
    box.add_child(scroll)
    place_panel.add_child(box)
    _centre(place_panel)

    _build_menu_panel()
    _build_map_panel()
    _build_boot_panel()

    party_screen = PartyScreen.new()
    party_root.add_child(party_screen)
    party_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    party_screen.visible = false
    party_screen.closed.connect(_on_party_closed)


func _top_button(text: String, handler: Callable) -> Button:
    var b := _btn(text, handler, 24)
    b.custom_minimum_size = Vector2(150, 68)
    return b


func _build_menu_panel() -> void:
    menu_panel = _hud_panel(0.97)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    var title := Label.new()
    title.text = "Menu"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 36)
    menu_msg = Label.new()
    menu_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    menu_msg.add_theme_font_size_override("font_size", 20)
    box.add_child(title)
    box.add_child(menu_msg)
    box.add_child(_btn("Save game", _on_save_pressed, 24))
    box.add_child(_btn("Load last save", _on_load_pressed, 24))
    box.add_child(_btn("Close", _close_menu, 24))
    menu_panel.add_child(box)
    _centre(menu_panel)


func _close_menu() -> void:
    menu_panel.visible = false


func _build_boot_panel() -> void:
    boot_panel = _hud_panel(0.98)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    var title := Label.new()
    title.text = "KINDLEWAKE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 52)
    title.add_theme_color_override("font_color", Color(0.95, 0.80, 0.35))
    var sub := Label.new()
    sub.text = "The Sundered Vow"
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    sub.add_theme_font_size_override("font_size", 24)
    boot_msg = Label.new()
    boot_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    boot_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    boot_msg.custom_minimum_size = Vector2(520, 0)
    boot_msg.add_theme_font_size_override("font_size", 20)
    boot_buttons = VBoxContainer.new()
    boot_buttons.add_theme_constant_override("separation", 10)
    box.add_child(title)
    box.add_child(sub)
    box.add_child(boot_msg)
    box.add_child(boot_buttons)
    boot_panel.add_child(box)
    _centre(boot_panel)


func _build_map_panel() -> void:
    map_panel = _hud_panel(0.98)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 8)
    var title := Label.new()
    title.text = "Eldrimar"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 30)
    var holder := Control.new()
    holder.custom_minimum_size = Vector2(float(ceili(float(wmap.width) / float(MAP_STEP))) * MAP_VIEW_SCALE, float(ceili(float(wmap.height) / float(MAP_STEP))) * MAP_VIEW_SCALE)
    var pic := TextureRect.new()
    pic.name = "MapPic"
    pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    pic.stretch_mode = TextureRect.STRETCH_SCALE
    pic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    pic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
    holder.add_child(pic)
    map_markers = Control.new()
    map_markers.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    map_markers.mouse_filter = Control.MOUSE_FILTER_IGNORE
    map_markers.draw.connect(_draw_map_markers)
    holder.add_child(map_markers)
    var hint := Label.new()
    hint.text = "Places appear once you have seen them. White dot: you."
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.add_theme_font_size_override("font_size", 16)
    box.add_child(title)
    box.add_child(holder)
    box.add_child(hint)
    box.add_child(_btn("Close", _close_map, 22))
    map_panel.add_child(box)
    _centre(map_panel)


func _open_map() -> void:
    var pic: TextureRect = map_panel.find_child("MapPic", true, false) as TextureRect
    if pic != null:
        pic.texture = map_tex
    map_panel.visible = true
    prompt_btn.visible = false
    map_markers.queue_redraw()


func _close_map() -> void:
    map_panel.visible = false


func _draw_map_markers() -> void:
    var sc: float = MAP_VIEW_SCALE / float(MAP_STEP)       # screen pixels per tile
    var font: Font = ThemeDB.fallback_font
    for r in wmap.region_defs:
        var rd: Dictionary = r
        var ctr: Array = rd.get("center", [0, 0])
        var rp := Vector2(float(ctr[0]), float(ctr[1])) * sc
        map_markers.draw_string(font, rp + Vector2(-80, 0), str(rd.get("name", "")), HORIZONTAL_ALIGNMENT_CENTER, 160, 15, Color(1, 1, 1, 0.5))
    for p in wmap.places:
        var d: Dictionary = p
        if not _is_seen(str(d.get("id", ""))):
            continue
        var c: Vector2i = _place_cell(d)
        var pos := Vector2(float(c.x) + 0.5, float(c.y) + 0.5) * sc
        var kind: String = str(d.get("kind", ""))
        var col := Color(1.0, 0.85, 0.2)
        var rad: float = 4.0
        if kind == "city" or kind == "keep":
            rad = 6.0
        elif kind == "camp":
            col = Color(0.95, 0.25, 0.2)
        elif kind == "ruin":
            col = Color(0.75, 0.55, 1.0)
        elif kind == "village":
            col = Color(1, 1, 1)
        map_markers.draw_circle(pos, rad + 1.5, Color(0, 0, 0, 0.8))
        map_markers.draw_circle(pos, rad, col)
        map_markers.draw_string(font, pos + Vector2(-60, -rad - 3), str(d.get("name", "")), HORIZONTAL_ALIGNMENT_CENTER, 120, 13, Color(1, 1, 1, 0.95))
    var me: Vector2 = player_pos / TILE * sc
    map_markers.draw_circle(me, 7.0, Color(0, 0, 0, 0.9))
    map_markers.draw_circle(me, 5.0, Color.WHITE)


## One pixel of the minimap per 2 x 2 tiles: 226 x 170 pixels, built once with a single byte-array fill.
func _build_map_texture() -> void:
    var mw: int = ceili(float(wmap.width) / float(MAP_STEP))
    var mh: int = ceili(float(wmap.height) / float(MAP_STEP))
    var data := PackedByteArray()
    data.resize(mw * mh * 4)
    var pal: Array = []
    for col in TERRAIN_COLORS:
        var cc: Color = col
        pal.append([cc.r8, cc.g8, cc.b8])
    var i := 0
    for y in range(mh):
        var row: int = mini(y * MAP_STEP, wmap.height - 1) * wmap.width
        for x in range(mw):
            var t: int = int(wmap.tiles[row + mini(x * MAP_STEP, wmap.width - 1)])
            var rgb: Array = pal[mini(t, pal.size() - 1)]
            data[i] = int(rgb[0])
            data[i + 1] = int(rgb[1])
            data[i + 2] = int(rgb[2])
            data[i + 3] = 255
            i += 4
    var img: Image = Image.create_from_data(mw, mh, false, Image.FORMAT_RGBA8, data)
    map_tex = ImageTexture.create_from_image(img)
    if minimap_dot == null:
        _build_minimap_widget(mw, mh)
    else:
        (minimap_dot.get_parent() as TextureRect).texture = map_tex


func _build_minimap_widget(mw: int, mh: int) -> void:
    var rect := TextureRect.new()
    rect.texture = map_tex
    rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    rect.stretch_mode = TextureRect.STRETCH_SCALE
    rect.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    rect.custom_minimum_size = Vector2(float(mw), float(mh))
    minimap_dot = ColorRect.new()
    minimap_dot.color = Color.WHITE
    minimap_dot.size = Vector2(6, 6)
    minimap_dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
    rect.add_child(minimap_dot)
    var hit := Button.new()                      # tapping the minimap opens the big map
    hit.flat = true
    hit.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hit.pressed.connect(_open_map)
    rect.add_child(hit)
    var panel := _hud_panel(0.8)
    panel.add_child(rect)
    hud_root.add_child(panel)
    panel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 12)
    panel.grow_vertical = Control.GROW_DIRECTION_BEGIN


func _update_hud() -> void:
    var cell: Vector2i = cell_of(player_pos)
    var region: Dictionary = wmap.region_at(cell)
    var tier: int = clampi(int(region.get("tier", 1)), 1, 5)
    var safe: String = "  (safe)" if _in_safe_zone(cell) else ""
    var txt: String = "%s  [Danger %s]\n%s%s\nGold: %d" % [str(region.get("name", GameData.world.get("name", "World"))), ROMAN[tier - 1], wmap.terrain_name(cell), safe, GameState.party.gold]
    if txt != hud_text:
        hud_text = txt
        info_label.text = txt
    if minimap_dot != null:
        minimap_dot.position = player_pos / TILE / float(MAP_STEP) - Vector2(3, 3)
