extends Node2D
## Pre-rendered rooms, FF7 style (feature pre_rendered_rooms, GDD 11.3). A "site" from data/sites.json (a keep or a dungeon)
## is a set of rooms. Each room is one fixed isometric picture (tools/build_scenes.py renders it from a voxel model) with a
## walk grid under it (RoomMap). Tap or drag to walk; the hero is drawn between the background and the "occluder slices"
## so pillars and props pass in front of him. Walking onto a glowing exit pad changes room (screen to screen, with a fade).
## Spots: text (people, inscriptions), party (war table: gear and sigils), chest (one-time loot, remembered in world_flags),
## battle (a boss that starts a battle and stays dead). Dungeon rooms with "enc" roll random encounters while you walk.

const WALK_SPEED := 11.0                 # cells per second
const HERO_SCALE := 1.9                  # sprite pixels per source pixel, in room-image space
const SPOT_RADIUS := 3.2                 # cells
const TRANSITION_TIME := 0.42
const PANEL_W := 560.0

var site_id: String = ""
var site: Dictionary = {}
var maps: Dictionary = {}                # room id -> RoomMap
var rmap: RoomMap
var room_id: String = ""
var bg_tex: Texture2D
var slice_tex: Array = []
var hero: Vector2 = Vector2(25.5, 25.5)  # cell units
var hero_dz: float = 0.0
var route_pts: Array[Vector2] = []
var pressing: bool = false
var last_tap: Vector2i = Vector2i(-1, -1)
var facing_left: bool = false
var walking: bool = false
var in_exit: String = ""
var near_spot: Dictionary = {}
var panel_open: bool = false
var leaving: bool = false
var enc_walked: float = 0.0
var enc_goal: float = 0.0
var time: float = 0.0
var hud_text: String = ""
var rng := RandomNumberGenerator.new()

var camera: Camera2D
var hud_root: Control
var info_label: Label
var prompt_btn: Button
var spot_panel: PanelContainer
var spot_title: Label
var spot_text: Label
var spot_buttons: VBoxContainer
var party_screen: PartyScreen
var fade_rect: ColorRect


func _ready() -> void:
    rng.randomize()
    if not SaveSystem.app_paused.is_connected(_on_app_paused):
        SaveSystem.app_paused.connect(_on_app_paused)
    if GameState.pending_site == "" and GameState.has_saved_room():
        GameState.prepare_saved_room()
    site_id = GameState.pending_site
    if not GameData.sites.has(site_id):
        call_deferred("_bail")
        return
    site = GameData.sites[site_id]
    maps = RoomMap.load_site(site, GameData.rooms)
    camera = Camera2D.new()
    add_child(camera)
    camera.make_current()
    _build_ui()
    var rid: String = GameState.pending_room
    if not maps.has(rid):
        rid = str(site.get("start", ""))
    var sp: Array = GameState.pending_spawn
    GameState.pending_spawn = []
    var cell := Vector2i(-1, -1)
    if sp.size() >= 2:
        cell = Vector2i(int(sp[0]), int(sp[1]))
    _load_room(rid, cell)


func _bail() -> void:
    GameState.clear_current_room()
    get_tree().change_scene_to_file("res://World.tscn")


func _load_room(id: String, spawn_cell: Vector2i) -> void:
    room_id = id
    rmap = maps[id]
    bg_tex = _load_tex("res://assets/art/rooms/%s.png" % rmap.model)
    slice_tex.clear()
    for k in range(rmap.slices.size()):
        slice_tex.append(_load_tex("res://assets/art/rooms/%s_o%d.png" % [rmap.model, k]))
    var sc: Vector2i = spawn_cell
    if sc.x < 0 or not rmap.walkable(sc):
        sc = rmap.spawn
    hero = Vector2(float(sc.x) + 0.5, float(sc.y) + 0.5)
    hero_dz = float(rmap.floor_dz(sc))
    route_pts.clear()
    pressing = false
    walking = false
    near_spot = {}
    prompt_btn.visible = false
    in_exit = str(rmap.exit_at(sc).get("id", ""))          # standing in a pad on arrival does not trigger it
    enc_walked = 0.0
    _roll_encounter()
    _update_layout()
    hud_text = ""
    GameState.set_current_room(site_id, room_id, rmap.cell_of(hero))
    GameState.autosave_world()
    queue_redraw()


func _load_tex(path: String) -> Texture2D:
    if ResourceLoader.exists(path):
        return load(path) as Texture2D
    return null


func _update_layout() -> void:
    if rmap == null or camera == null:
        return
    var vp: Vector2 = get_viewport_rect().size
    var z: float = minf((vp.y - 20.0) / float(maxi(1, rmap.img_h)), (vp.x - 20.0) / float(maxi(1, rmap.img_w)))
    z = maxf(z, 0.4)
    camera.zoom = Vector2(z, z)
    camera.position = Vector2(float(rmap.img_w) * 0.5, float(rmap.img_h) * 0.5)


# ------------------------------------------------------------------ input and movement

func _unhandled_input(event: InputEvent) -> void:
    if panel_open or party_screen.visible or leaving:
        return
    if event is InputEventMouseButton:
        var mb := event as InputEventMouseButton
        if mb.button_index == MOUSE_BUTTON_LEFT:
            pressing = mb.pressed
            if mb.pressed:
                _tap(mb.position)
    elif event is InputEventMouseMotion and pressing:
        _tap((event as InputEventMouseMotion).position)


func _tap(screen_pos: Vector2) -> void:
    var rp: Vector2 = get_canvas_transform().affine_inverse() * screen_pos
    var c: Vector2i = rmap.cell_at_screen(rp, hero_dz)
    if not rmap.walkable(c):
        c = rmap.nearest_walkable(c, 6)
        if c.x < 0:
            return
    if c == last_tap and not route_pts.is_empty():
        return
    last_tap = c
    route_pts = rmap.route(hero, c)


func _process(delta: float) -> void:
    if rmap == null:
        return
    time += delta
    _update_layout()
    if not leaving and not panel_open and not party_screen.visible:
        _move(delta)
        _check_exit()
        _update_near()
        _check_encounter()
    GameState.set_current_room(site_id, room_id, rmap.cell_of(hero))
    _update_hud()
    queue_redraw()


func _move(delta: float) -> void:
    walking = false
    var moved: float = 0.0
    var budget: float = WALK_SPEED * delta
    while budget > 0.0 and not route_pts.is_empty():
        var tgt: Vector2 = route_pts[0]
        var to: Vector2 = tgt - hero
        var d: float = to.length()
        if absf(to.x - to.y) > 0.05:
            facing_left = (to.x - to.y) < 0.0
        if d <= budget:
            hero = tgt
            budget -= d
            moved += d
            route_pts.remove_at(0)
        else:
            hero += to / d * budget
            moved += budget
            budget = 0.0
        walking = true
    var target_dz: float = float(rmap.floor_dz(rmap.cell_of(hero)))
    hero_dz = move_toward(hero_dz, target_dz, 30.0 * delta)
    enc_walked += moved


func _check_exit() -> void:
    var e: Dictionary = rmap.exit_at(rmap.cell_of(hero))
    var eid: String = str(e.get("id", ""))
    if eid == in_exit:
        return
    in_exit = eid
    if eid != "":
        _take_exit(e)


func _take_exit(e: Dictionary) -> void:
    leaving = true
    route_pts.clear()
    prompt_btn.visible = false
    _fade(1.0, _after_exit_fade.bind(e))


func _after_exit_fade(e: Dictionary) -> void:
    var to: String = str(e.get("to", ""))
    if to == "@leave" or not maps.has(to):
        _leave_site()
        return
    var sp: Array = e.get("spawn", [])
    var cell := Vector2i(-1, -1)
    if sp.size() >= 2:
        cell = Vector2i(int(sp[0]), int(sp[1]))
    _load_room(to, cell)
    leaving = false
    _fade(0.0, Callable())


func _leave_site() -> void:
    GameState.clear_current_room()
    GameState.autosave_world()
    get_tree().change_scene_to_file("res://World.tscn")       # world_pos was saved when the site was entered


func _on_app_paused() -> void:
    if rmap == null:
        return
    GameState.set_current_room(site_id, room_id, rmap.cell_of(hero))
    GameState.autosave_world()


func _fade(to_progress: float, done: Callable) -> void:
    var mat := fade_rect.material as ShaderMaterial
    if mat == null:
        if done.is_valid():
            done.call()
        return
    var tw: Tween = create_tween()
    tw.tween_property(mat, "shader_parameter/progress", to_progress, TRANSITION_TIME)
    if done.is_valid():
        tw.tween_callback(done)


# ------------------------------------------------------------------ random encounters

func _roll_encounter() -> void:
    if rmap.enc.size() == 2 and str(site.get("encounters", "")) != "":
        enc_goal = rng.randf_range(float(rmap.enc[0]), float(rmap.enc[1]))
    else:
        enc_goal = 0.0


func _check_encounter() -> void:
    if enc_goal > 0.0 and enc_walked >= enc_goal:
        var def: Dictionary = GameState.skirmish_def(str(site.get("encounters", "skirmish")))
        if def.is_empty():
            _roll_encounter()
            enc_walked = 0.0
            return
        leaving = true
        route_pts.clear()
        prompt_btn.visible = false
        _fade(1.0, _go_battle.bind(def))


func _go_battle(def: Dictionary) -> void:
    var c: Vector2i = rmap.cell_of(hero)
    GameState.set_current_room(site_id, room_id, c)
    GameState.autosave_world()
    GameState.start_battle_from_room(def, site_id, room_id, [c.x, c.y])
    get_tree().change_scene_to_file("res://Main.tscn")


# ------------------------------------------------------------------ spots

func _flag_key(s: Dictionary) -> String:
    return "chest:%s:%s:%s" % [site_id, room_id, str(s.get("chest_id", ""))]


func _spot_visible(s: Dictionary) -> bool:
    var req: String = str(s.get("requires_flag", ""))
    if req != "" and not bool(GameState.world_flags.get(req, false)):
        return false
    if str(s.get("kind", "")) == "battle":
        var cf: String = str(s.get("clear_flag", ""))
        if cf != "" and bool(GameState.world_flags.get(cf, false)):
            return false
    return true


func _chest_open(s: Dictionary) -> bool:
    return bool(GameState.world_flags.get(_flag_key(s), false))


func _update_near() -> void:
    var best: Dictionary = {}
    var best_d: float = SPOT_RADIUS
    for s in rmap.spots:
        var sd: Dictionary = s
        if not _spot_visible(sd):
            continue
        if str(sd.get("kind", "")) == "chest" and _chest_open(sd):
            continue
        var sc: Vector2i = rmap.spot_cell(sd)
        var d: float = Vector2(float(sc.x) + 0.5, float(sc.y) + 0.5).distance_to(hero)
        if d < best_d:
            best_d = d
            best = sd
    near_spot = best
    prompt_btn.visible = not best.is_empty() and not panel_open
    if not best.is_empty():
        var kind: String = str(best.get("kind", "text"))
        var verb: String = "Examine"
        if kind == "text" and bool(best.get("npc", false)):
            verb = "Talk to"
        elif kind == "party":
            verb = "Use"
        elif kind == "chest":
            verb = "Open"
        elif kind == "battle":
            verb = "Challenge"
        prompt_btn.text = "%s %s" % [verb, str(best.get("name", ""))]


func _on_prompt_pressed() -> void:
    if near_spot.is_empty():
        return
    var s: Dictionary = near_spot
    route_pts.clear()
    pressing = false
    prompt_btn.visible = false
    var kind: String = str(s.get("kind", "text"))
    if kind == "chest":
        _open_chest(s)
        return
    _show_panel(str(s.get("name", "")), str(s.get("text", "")))
    if kind == "party":
        spot_buttons.add_child(_btn("Party and Gear", _open_party, 24))
    elif kind == "battle":
        spot_buttons.add_child(_btn("Fight", _start_boss.bind(s), 24))
    spot_buttons.add_child(_btn("Close", _close_panel, 24))


func _show_panel(title: String, text: String) -> void:
    panel_open = true
    spot_title.text = title
    spot_text.text = text
    for c in spot_buttons.get_children():
        spot_buttons.remove_child(c)
        c.queue_free()
    spot_panel.visible = true


func _close_panel() -> void:
    panel_open = false
    spot_panel.visible = false


func _open_chest(s: Dictionary) -> void:
    var parts: Array[String] = []
    var gold: int = int(s.get("gold", 0))
    if gold > 0:
        GameState.party.gold += gold
        parts.append("%d gold" % gold)
    var its: Dictionary = s.get("items", {})
    for k in its.keys():
        var n: int = int(its[k])
        GameState.party.add_item(str(k), n)
        var nm: String = str((GameData.items.get(str(k), {}) as Dictionary).get("name", str(k)))
        parts.append(nm if n == 1 else "%s x%d" % [nm, n])
    GameState.world_flags[_flag_key(s)] = true
    var found: String = ", ".join(PackedStringArray(parts)) if not parts.is_empty() else "nothing but dust"
    _show_panel(str(s.get("name", "")), "%s\n\nYou found: %s." % [str(s.get("text", "")), found])
    spot_buttons.add_child(_btn("Close", _close_panel, 24))
    GameState.autosave_world()


func _open_party() -> void:
    party_screen.setup(GameState.party, GameData.party_db(), {}, true)
    party_screen.open()


func _start_boss(s: Dictionary) -> void:
    var def: Dictionary = GameData.battle_def(str(s.get("battle", ""))).duplicate(true)
    if def.is_empty():
        return
    def["clear_flag"] = str(s.get("clear_flag", ""))
    panel_open = false
    spot_panel.visible = false
    leaving = true
    var c: Vector2i = rmap.cell_of(hero)
    GameState.set_current_room(site_id, room_id, c)
    GameState.autosave_world()
    GameState.start_battle_from_room(def, site_id, room_id, [c.x, c.y])
    _fade(1.0, _goto_battle_scene)


func _goto_battle_scene() -> void:
    get_tree().change_scene_to_file("res://Main.tscn")


func _on_party_closed() -> void:
    hud_text = ""


# ------------------------------------------------------------------ drawing

func _draw() -> void:
    if rmap == null:
        return
    var inv: Transform2D = get_canvas_transform().affine_inverse()
    var vp: Vector2 = get_viewport_rect().size
    var tl: Vector2 = inv * Vector2.ZERO
    var br: Vector2 = inv * vp
    draw_rect(Rect2(tl - Vector2(40, 40), br - tl + Vector2(80, 80)), Color(0.035, 0.03, 0.04))
    if bg_tex != null:
        draw_texture(bg_tex, Vector2.ZERO)
    else:
        _draw_fallback_floor()
    for e in rmap.exits:
        _draw_exit_pad(e)
    var items: Array = []
    for i in range(rmap.slices.size()):
        items.append({"key": float((rmap.slices[i] as Dictionary).get("key", 0.0)), "kind": "slice", "i": i})
    for s in rmap.spots:
        var sd: Dictionary = s
        if not _spot_visible(sd):
            continue
        var sc: Vector2i = rmap.spot_cell(sd)
        items.append({"key": float(sc.x + sc.y) + 1.0, "kind": "spot", "spot": sd})
    items.append({"key": hero.x + hero.y + 0.6, "kind": "hero"})
    items.sort_custom(func(p, q): return float(p["key"]) < float(q["key"]))
    for o in items:
        var d: Dictionary = o
        var k: String = str(d["kind"])
        if k == "slice":
            var tex: Texture2D = slice_tex[int(d["i"])] as Texture2D
            if tex != null:
                var sl: Dictionary = rmap.slices[int(d["i"])]
                draw_texture(tex, Vector2(float(sl.get("x", 0)), float(sl.get("y", 0))))
        elif k == "spot":
            _draw_spot(d["spot"])
        else:
            _draw_hero()
    if not route_pts.is_empty() and not panel_open:
        var last: Vector2 = route_pts[route_pts.size() - 1]
        var tp: Vector2 = rmap.project(last, float(rmap.floor_dz(rmap.cell_of(last))))
        draw_arc(tp, 6.0, 0.0, TAU, 14, Color(1, 1, 1, 0.5), 1.5)


func _draw_fallback_floor() -> void:
    var pts := PackedVector2Array([rmap.project(Vector2(0, 0), 0.0), rmap.project(Vector2(50, 0), 0.0), rmap.project(Vector2(50, 50), 0.0), rmap.project(Vector2(0, 50), 0.0)])
    draw_colored_polygon(pts, Color(0.35, 0.30, 0.22))


func _exit_dz(e: Dictionary) -> float:
    var rc: Rect2i = rmap.exit_rect(e)
    for yy in range(rc.position.y, rc.position.y + rc.size.y):
        for xx in range(rc.position.x, rc.position.x + rc.size.x):
            if rmap.walkable(Vector2i(xx, yy)):
                return float(rmap.floor_dz(Vector2i(xx, yy)))
    return 0.0


func _draw_exit_pad(e: Dictionary) -> void:
    var rc: Rect2i = rmap.exit_rect(e)
    var dz: float = _exit_dz(e)
    var x0: float = float(rc.position.x)
    var y0: float = float(rc.position.y)
    var x1: float = float(rc.position.x + rc.size.x)
    var y1: float = float(rc.position.y + rc.size.y)
    var pulse: float = 0.5 + 0.5 * sin(time * 3.0)
    var pts := PackedVector2Array([rmap.project(Vector2(x0, y0), dz), rmap.project(Vector2(x1, y0), dz), rmap.project(Vector2(x1, y1), dz), rmap.project(Vector2(x0, y1), dz)])
    draw_colored_polygon(pts, Color(1.0, 0.82, 0.35, 0.10 + 0.10 * pulse))
    var c: Vector2 = rmap.project(rmap.exit_centre(e), dz)
    var label: String = str(e.get("label", ""))
    var near: bool = hero.distance_to(rmap.exit_centre(e)) < 9.0
    if near and label != "":
        draw_string(ThemeDB.fallback_font, c + Vector2(-59, -9), label, HORIZONTAL_ALIGNMENT_CENTER, 120, 12, Color(0, 0, 0, 0.85))
        draw_string(ThemeDB.fallback_font, c + Vector2(-60, -10), label, HORIZONTAL_ALIGNMENT_CENTER, 120, 12, Color(1.0, 0.93, 0.7))
    var tip: Vector2 = c + Vector2(0, -22.0 + sin(time * 3.0) * 2.0)
    draw_colored_polygon(PackedVector2Array([tip + Vector2(-5, -7), tip + Vector2(5, -7), tip]), Color(1.0, 0.85, 0.25, 0.5 + 0.3 * pulse))


func _spot_dz(c: Vector2i) -> float:
    var w: Vector2i = rmap.nearest_walkable(c, 4)
    return float(rmap.floor_dz(w)) if w.x >= 0 else 0.0


func _draw_spot(s: Dictionary) -> void:
    var c: Vector2i = rmap.spot_cell(s)
    var kind: String = str(s.get("kind", "text"))
    var centre := Vector2(float(c.x) + 0.5, float(c.y) + 0.5)
    var dz: float = _spot_dz(c)
    var foot: Vector2 = rmap.project(centre, dz)
    var near: bool = not near_spot.is_empty() and near_spot == s
    var top: float = 30.0
    if bool(s.get("npc", false)):
        var sc: float = float(s.get("npc_scale", 1.9))
        var tint_a: Array = s.get("tint", [1, 1, 1])
        var tint := Color(float(tint_a[0]), float(tint_a[1]), float(tint_a[2]))
        draw_colored_polygon(_ellipse(foot, 9.0 * sc / 1.9, 4.5 * sc / 1.9), Color(0, 0, 0, 0.35))
        var flip: bool = rmap.project(hero, hero_dz).x < foot.x
        if not HeroArt.draw(self, "soldier", "idle", time + float(c.x) * 0.1, foot, sc, flip, tint):
            draw_rect(Rect2(foot + Vector2(-5, -24), Vector2(10, 22)), tint)
        top = 34.0 * sc
    elif kind == "chest" and not bool(s.get("in_art", false)):
        _draw_chest(centre, dz, _chest_open(s))
        top = 22.0
    elif kind == "party":
        top = 26.0
    var bob: float = sin(time * 3.0) * 2.0
    var tip: Vector2 = foot + Vector2(0, -top - 8.0 + bob)
    var col := Color(1.0, 0.85, 0.25) if near else Color(1.0, 0.85, 0.25, 0.65)
    if kind == "chest" and _chest_open(s):
        return
    draw_colored_polygon(PackedVector2Array([tip + Vector2(-5, -7), tip + Vector2(5, -7), tip]), col)
    if near:
        var label: String = str(s.get("name", ""))
        draw_string(ThemeDB.fallback_font, tip + Vector2(-79, -11), label, HORIZONTAL_ALIGNMENT_CENTER, 160, 12, Color(0, 0, 0, 0.85))
        draw_string(ThemeDB.fallback_font, tip + Vector2(-80, -12), label, HORIZONTAL_ALIGNMENT_CENTER, 160, 12, Color(1.0, 0.95, 0.8))


## A small isometric chest (6 x 4 x 4 voxels), drawn with the same projection as the room so it sits on the floor.
func _draw_chest(centre: Vector2, dz: float, opened: bool) -> void:
    var wood := Color(0.46, 0.28, 0.12)
    var gold := Color(0.85, 0.68, 0.22)
    _draw_box(centre, dz, 3.0, 2.0, 0.0, 3.0, wood)
    _draw_box(centre, dz, 3.1, 0.6, 1.2, 1.6, gold)
    if opened:
        _draw_box(centre + Vector2(0.0, -1.7), dz, 3.0, 0.4, 3.0, 2.6, wood.darkened(0.15))
        _draw_box(centre, dz, 2.4, 1.5, 3.0, 0.5, Color(0.95, 0.82, 0.35))
    else:
        _draw_box(centre, dz, 3.0, 2.0, 3.0, 1.4, wood.lightened(0.1))


func _draw_box(c: Vector2, dz: float, hx: float, hy: float, z0: float, h: float, col: Color) -> void:
    var z1: float = dz + z0 + h
    var zb: float = dz + z0
    var top := PackedVector2Array([rmap.project(Vector2(c.x - hx, c.y - hy), z1), rmap.project(Vector2(c.x + hx, c.y - hy), z1), rmap.project(Vector2(c.x + hx, c.y + hy), z1), rmap.project(Vector2(c.x - hx, c.y + hy), z1)])
    draw_colored_polygon(top, col)
    var left := PackedVector2Array([rmap.project(Vector2(c.x - hx, c.y + hy), z1), rmap.project(Vector2(c.x + hx, c.y + hy), z1), rmap.project(Vector2(c.x + hx, c.y + hy), zb), rmap.project(Vector2(c.x - hx, c.y + hy), zb)])
    draw_colored_polygon(left, col.darkened(0.22))
    var right := PackedVector2Array([rmap.project(Vector2(c.x + hx, c.y - hy), z1), rmap.project(Vector2(c.x + hx, c.y + hy), z1), rmap.project(Vector2(c.x + hx, c.y + hy), zb), rmap.project(Vector2(c.x + hx, c.y - hy), zb)])
    draw_colored_polygon(right, col.darkened(0.42))


func _draw_hero() -> void:
    var p: Vector2 = rmap.project(hero, hero_dz)
    draw_colored_polygon(_ellipse(p, 9.0, 4.5), Color(0, 0, 0, 0.38))
    var kind: String = HeroArt.usable_kind(GameState.lead_kind())
    var anim: String = "walk" if walking else "idle"
    var sc: float = HERO_SCALE * GameState.look_scale(GameState.lead_id)
    if not HeroArt.draw(self, kind, anim, time, p + Vector2(0, 1), sc, facing_left):
        draw_rect(Rect2(p + Vector2(-5, -24), Vector2(10, 24)), Color(0.22, 0.50, 0.88))


func _ellipse(center: Vector2, rx: float, ry: float) -> PackedVector2Array:
    var pts := PackedVector2Array()
    for i in range(16):
        var a: float = TAU * float(i) / 16.0
        pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))
    return pts


# ------------------------------------------------------------------ HUD

func _hud_panel(alpha: float = 0.84) -> PanelContainer:
    var p := PanelContainer.new()
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.09, 0.08, 0.07, alpha)
    sb.border_color = Color(0.62, 0.52, 0.34, 0.9)
    sb.set_border_width_all(2)
    sb.set_corner_radius_all(8)
    sb.set_content_margin_all(10)
    p.add_theme_stylebox_override("panel", sb)
    return p


func _btn(text: String, handler: Callable, font_size: int = 24) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(300, 72)
    b.add_theme_font_size_override("font_size", font_size)
    b.pressed.connect(handler)
    return b


func _apply_safe_area() -> void:
    if hud_root == null or not is_inside_tree():
        return
    var l: float = 0.0
    var t: float = 0.0
    var r: float = 0.0
    var b: float = 0.0
    if OS.has_feature("mobile"):
        var win: Vector2i = DisplayServer.window_get_size()
        var safe: Rect2i = DisplayServer.get_display_safe_area()
        var vp: Vector2 = get_viewport().get_visible_rect().size
        if win.x > 0 and win.y > 0 and safe.size.x > 0 and safe.size.y > 0:
            var sx: float = vp.x / float(win.x)
            var sy: float = vp.y / float(win.y)
            l = clampf(float(safe.position.x) * sx, 0.0, 120.0)
            t = clampf(float(safe.position.y) * sy, 0.0, 120.0)
            r = clampf(float(win.x - safe.position.x - safe.size.x) * sx, 0.0, 120.0)
            b = clampf(float(win.y - safe.position.y - safe.size.y) * sy, 0.0, 120.0)
    hud_root.offset_left = l
    hud_root.offset_top = t
    hud_root.offset_right = -r
    hud_root.offset_bottom = -b


func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud_root = root
    get_viewport().size_changed.connect(_apply_safe_area)
    call_deferred("_apply_safe_area")

    var info_panel := _hud_panel()
    info_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    info_label = Label.new()
    info_label.custom_minimum_size = Vector2(300, 0)
    info_label.add_theme_font_size_override("font_size", 20)
    info_panel.add_child(info_label)
    root.add_child(info_panel)
    info_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 12)

    prompt_btn = _btn("Talk", _on_prompt_pressed, 28)
    prompt_btn.custom_minimum_size = Vector2(420, 84)
    prompt_btn.visible = false
    root.add_child(prompt_btn)
    prompt_btn.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 16)
    prompt_btn.grow_horizontal = Control.GROW_DIRECTION_BOTH
    prompt_btn.grow_vertical = Control.GROW_DIRECTION_BEGIN

    spot_panel = _hud_panel(0.97)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    spot_title = Label.new()
    spot_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    spot_title.add_theme_font_size_override("font_size", 36)
    spot_text = Label.new()
    spot_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    spot_text.custom_minimum_size = Vector2(PANEL_W, 0)
    spot_text.add_theme_font_size_override("font_size", 22)
    spot_buttons = VBoxContainer.new()
    spot_buttons.add_theme_constant_override("separation", 10)
    box.add_child(spot_title)
    box.add_child(spot_text)
    box.add_child(spot_buttons)
    spot_panel.add_child(box)
    root.add_child(spot_panel)
    spot_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
    spot_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
    spot_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
    spot_panel.visible = false

    party_screen = PartyScreen.new()
    root.add_child(party_screen)
    party_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    party_screen.visible = false
    party_screen.closed.connect(_on_party_closed)

    fade_rect = ColorRect.new()
    fade_rect.color = Color.WHITE
    fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var swirl := ShaderMaterial.new()
    swirl.shader = load("res://assets/shaders/room_swirl.gdshader") as Shader
    swirl.set_shader_parameter("progress", 0.0)
    fade_rect.material = swirl
    layer.add_child(fade_rect)
    fade_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _update_hud() -> void:
    var txt: String = "%s\n%s\nGold: %d" % [rmap.title, str(site.get("name", "")), GameState.party.gold]
    if txt != hud_text:
        hud_text = txt
        info_label.text = txt
