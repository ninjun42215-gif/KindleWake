class_name PartyScreen
extends Control
## Full-screen party management in one touch UI: character sheet (left/middle) and a right panel with three tabs:
## Equipment, Sigils and Shop. It owns no rules: every action goes through PartyState / CharacterSheet / ShopSystem,
## the same code paths the headless tests cover. It reads no autoloads, so it can be built in tests.
## Usage: setup(party, db, shop) then open(); listen to `closed`.
## db needs "classes", "weapons", "items", "sigils", "skills" (GameData.party_db()).

signal closed()

const TAB_GEAR := 0
const TAB_SIGILS := 1
const TAB_SHOP := 2
const TAB_NAMES: Array[String] = ["Equipment", "Sigils", "Shop"]

const COL_BG := Color(0.106, 0.092, 0.07)
const COL_PANEL := Color(0.19, 0.155, 0.11)
const COL_BORDER := Color(0.72, 0.55, 0.32)
const COL_TEXT := Color(0.94, 0.89, 0.74)
const COL_DIM := Color(0.68, 0.62, 0.5)
const COL_GOLD := Color(1.0, 0.86, 0.3)
const COL_GOOD := Color(0.55, 0.9, 0.55)

var party: PartyState = null
var db: Dictionary = {}
var shop: Dictionary = {}
var selected_id: String = ""
var tab: int = TAB_GEAR
var focus_slot: String = ""           # Equipment tab: the slot whose choices are open
var focus_group: String = ""          # Sigils tab: "weapon" or "armor"
var focus_index: int = -1             # Sigils tab: the socket whose choices are open
var shop_selling: bool = false
var message: String = ""
var changed: bool = false             # true once anything was equipped, socketed, promoted, bought or sold
var right_scroll: ScrollContainer = null
var keep_scroll: int = 0
var reset_scroll: bool = false
var builds: int = 0                   # how many times the layout was completely built (tests use it to catch half-built screens)


func setup(p_party: PartyState, p_db: Dictionary, p_shop: Dictionary) -> void:
    party = p_party
    db = p_db
    shop = p_shop
    if not party.sheets.has(selected_id) and not party.roster.is_empty():
        selected_id = party.roster[0]
    visible = false


func open() -> void:
    changed = false
    message = ""
    focus_slot = ""
    focus_group = ""
    focus_index = -1
    reset_scroll = true
    if not party.sheets.has(selected_id) and not party.roster.is_empty():
        selected_id = party.roster[0]
    visible = true
    _rebuild()


func close() -> void:
    visible = false
    closed.emit()


# ---------------------------------------------------------------- building blocks

func _style(bg: Color, border: Color) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = bg
    sb.border_color = border
    sb.set_border_width_all(2)
    sb.set_corner_radius_all(6)
    sb.set_content_margin_all(10.0)
    return sb


func _panel(min_size: Vector2) -> PanelContainer:
    var p := PanelContainer.new()
    p.custom_minimum_size = min_size
    p.add_theme_stylebox_override("panel", _style(COL_PANEL, COL_BORDER))
    return p


func _label(text: String, font_size: int = 20, color: Color = COL_TEXT) -> Label:
    var l := Label.new()
    l.text = text
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    return l


func _button(text: String, handler: Callable, min_size: Vector2 = Vector2(0, 60), font_size: int = 20) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.clip_text = true
    b.add_theme_font_size_override("font_size", font_size)
    b.pressed.connect(handler)
    return b


func _scroll_box(separation: int = 8) -> Array:
    var scroll := ScrollContainer.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", separation)
    box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(box)
    return [scroll, box]


func _class_title(class_id: String) -> String:
    var cdef: Dictionary = (db.get("classes", {}) as Dictionary).get(class_id, {})
    return str(cdef.get("name", class_id))


func _item_name(item_id: String) -> String:
    var it: Dictionary = (db.get("items", {}) as Dictionary).get(item_id, {})
    return str(it.get("name", item_id))


func _sigil_def(sigil_id: String) -> Dictionary:
    return (db.get("sigils", {}) as Dictionary).get(sigil_id, {})


## Display name of bag sigil number `bag_index` ("sigil" when the index is stale).
func _bag_sigil_name(bag_index: int) -> String:
    if bag_index < 0 or bag_index >= party.sigil_inv.size():
        return "sigil"
    var inst: Dictionary = party.sigil_inv[bag_index]
    return str(_sigil_def(str(inst.get("id", ""))).get("name", "sigil"))


# ---------------------------------------------------------------- whole-screen layout

func _rebuild() -> void:
    if party == null:
        return
    if right_scroll != null and is_instance_valid(right_scroll):
        keep_scroll = 0 if reset_scroll else right_scroll.scroll_vertical
    else:
        keep_scroll = 0
    reset_scroll = false
    right_scroll = null
    for c in get_children():
        remove_child(c)
        c.queue_free()
    var bg := ColorRect.new()
    bg.color = COL_BG
    bg.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(bg)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 16)
    margin.add_theme_constant_override("margin_right", 16)
    margin.add_theme_constant_override("margin_top", 12)
    margin.add_theme_constant_override("margin_bottom", 12)
    add_child(margin)
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var root_box := VBoxContainer.new()
    root_box.add_theme_constant_override("separation", 10)
    margin.add_child(root_box)
    root_box.add_child(_build_header())
    var cols := HBoxContainer.new()
    cols.add_theme_constant_override("separation", 10)
    cols.size_flags_vertical = Control.SIZE_EXPAND_FILL
    root_box.add_child(cols)
    cols.add_child(_build_roster())
    cols.add_child(_build_sheet())
    cols.add_child(_build_right())
    builds += 1
    _restore_scroll.call_deferred()


func _restore_scroll() -> void:
    if right_scroll != null and is_instance_valid(right_scroll):
        right_scroll.scroll_vertical = keep_scroll


func _build_header() -> Control:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 12)
    var title := _label("Company of Kaer Sethorn", 30, COL_GOLD)
    row.add_child(title)
    var gold := _label("Gold: %d" % party.gold, 26, COL_GOLD)
    gold.size_flags_horizontal = Control.SIZE_SHRINK_END
    row.add_child(gold)
    row.add_child(_button("Close", close, Vector2(140, 56), 24))
    return row


func _build_roster() -> Control:
    var panel := _panel(Vector2(250, 0))
    var parts: Array = _scroll_box()
    var scroll: ScrollContainer = parts[0]
    var box: VBoxContainer = parts[1]
    for id in party.roster:
        var sh: CharacterSheet = party.sheet(id)
        var b := _button("%s\n%s  Lv %d" % [sh.display_name, _class_title(sh.class_id), sh.level], _on_select.bind(id), Vector2(0, 76), 20)
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        if id == selected_id:
            b.modulate = COL_GOLD
        box.add_child(b)
    panel.add_child(scroll)
    return panel


func _build_sheet() -> Control:
    var panel := _panel(Vector2(410, 0))
    var parts: Array = _scroll_box(6)
    var scroll: ScrollContainer = parts[0]
    var box: VBoxContainer = parts[1]
    var sh: CharacterSheet = party.sheet(selected_id)
    if sh == null:
        box.add_child(_label("Nobody is selected."))
    else:
        _fill_sheet(box, sh)
    panel.add_child(scroll)
    return panel


func _fill_sheet(box: VBoxContainer, sh: CharacterSheet) -> void:
    var items: Dictionary = db.get("items", {})
    var sdefs: Dictionary = db.get("sigils", {})
    var skills: Dictionary = db.get("skills", {})
    var classes: Dictionary = db.get("classes", {})
    var d: Dictionary = sh.derived(db)
    var total: Dictionary = sh.total_stats(items, sdefs)
    box.add_child(_label(sh.display_name, 30, COL_GOLD))
    box.add_child(_label("Lv %d  %s   (house %s)" % [sh.level, _class_title(sh.class_id), sh.house.capitalize()], 20))
    box.add_child(_label("EXP %d / %d" % [sh.xp, sh.exp_to_next()], 17, COL_DIM))
    var bar := ProgressBar.new()
    bar.min_value = 0.0
    bar.max_value = float(sh.exp_to_next())
    bar.value = float(sh.xp)
    bar.show_percentage = false
    bar.custom_minimum_size = Vector2(0, 14)
    box.add_child(bar)
    box.add_child(_label("HP %d     MP %d" % [int(d["max_hp"]), int(d["max_mp"])], 24))
    box.add_child(_label("ATK %d    DEF %d    RES %d" % [roundi(float(d["attack"])), roundi(float(d["defense"])), roundi(float(d["resistance"]))], 20))
    box.add_child(_label("ACC %d    EVA %d    CRIT %d%%" % [int(d["accuracy"]), int(d["evasion"]), int(d["crit"])], 20))
    box.add_child(_label("SPD %d    MOV %d    Range %d-%d" % [int(d["spd"]), int(d["move"]), int(d["range_min"]), int(d["range_max"])], 20))
    var order: Array[String] = ItemInfo.STAT_ORDER
    var i := 0
    while i < order.size():
        var line: String = ""
        for k in range(i, mini(i + 2, order.size())):
            var key: String = order[k]
            var gear_bonus: int = int(total.get(key, 0)) - int(sh.base_stats.get(key, 0))
            var cell: String = "%s %d" % [ItemInfo.stat_name(key), int(total.get(key, 0))]
            if gear_bonus != 0:
                cell += " (%s)" % ItemInfo.signed(gear_bonus)
            line += cell.rpad(18)
        box.add_child(_label(line.strip_edges(), 18, COL_DIM))
        i += 2
    var mods: Dictionary = sh.skill_mods(items, sdefs)
    var known: Array[String] = sh.all_skills(items, sdefs)
    box.add_child(_label("Skills", 22, COL_GOLD))
    if known.is_empty():
        box.add_child(_label("None yet. Socket a magic sigil to learn spells.", 17, COL_DIM))
    for sid in known:
        var text: String = ItemInfo.skill_line(sid, skills)
        if int(mods.get(sid, 0)) != 0:
            text += "  (power %s%%)" % ItemInfo.signed(int(mods[sid]))
        box.add_child(_label(text, 17))
    var options: Array[String] = sh.promotion_options(classes)
    if not options.is_empty():
        box.add_child(_label("Promotion available", 22, COL_GOLD))
        for cid in options:
            box.add_child(_button("Promote to %s" % _class_title(cid), _on_promote.bind(cid), Vector2(0, 56), 20))


func _build_right() -> Control:
    var panel := _panel(Vector2(0, 0))
    panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var outer := VBoxContainer.new()
    outer.add_theme_constant_override("separation", 8)
    var tabs := HBoxContainer.new()
    tabs.add_theme_constant_override("separation", 8)
    for t in range(TAB_NAMES.size()):
        var tb := _button(TAB_NAMES[t], _on_tab.bind(t), Vector2(0, 56), 22)
        tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        if t == tab:
            tb.modulate = COL_GOLD
        tabs.add_child(tb)
    outer.add_child(tabs)
    var msg := _label(message, 18, COL_GOLD)
    msg.custom_minimum_size = Vector2(0, 28)
    outer.add_child(msg)
    var parts: Array = _scroll_box(8)
    var scroll: ScrollContainer = parts[0]
    var box: VBoxContainer = parts[1]
    right_scroll = scroll
    if tab == TAB_GEAR:
        _fill_gear(box)
    elif tab == TAB_SIGILS:
        _fill_sigils(box)
    else:
        _fill_shop(box)
    outer.add_child(scroll)
    panel.add_child(outer)
    return panel


# ---------------------------------------------------------------- Equipment tab

func _fill_gear(box: VBoxContainer) -> void:
    var sh: CharacterSheet = party.sheet(selected_id)
    if sh == null:
        return
    var current: Dictionary = sh.derived(db)
    for slot in CharacterSheet.SLOTS:
        var iid: String = sh.item_in(slot)
        var shown: String = "- empty -"
        if iid != "":
            shown = _item_name(iid)
        var b := _button("%s: %s" % [ItemInfo.slot_name(slot), shown], _on_slot.bind(slot), Vector2(0, 60), 20)
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        if slot == focus_slot:
            b.modulate = COL_GOLD
        box.add_child(b)
        if slot == focus_slot:
            _fill_slot_choices(box, sh, slot, current)


func _item_fits_slot(it: Dictionary, slot: String) -> bool:
    var item_slot: String = str(it.get("slot", ""))
    return item_slot == slot or (item_slot == "accessory" and slot.begins_with("accessory"))


func _fill_slot_choices(box: VBoxContainer, sh: CharacterSheet, slot: String, current: Dictionary) -> void:
    var items: Dictionary = db.get("items", {})
    var weapons: Dictionary = db.get("weapons", {})
    var worn: String = sh.item_in(slot)
    if worn != "":
        box.add_child(_label(ItemInfo.item_line(worn, items, weapons), 16, COL_DIM))
        box.add_child(_button("Unequip (back to the bag)", _on_unequip.bind(slot), Vector2(0, 52), 18))
    var ids: Array = party.inventory.keys()
    ids.sort()
    var count := 0
    for k in ids:
        var iid: String = str(k)
        var it: Dictionary = items.get(iid, {})
        if not _item_fits_slot(it, slot):
            continue
        count += 1
        var problem: String = sh.equip_problem(slot, iid, items)
        var text: String = "%s  x%d" % [str(it.get("name", iid)), party.item_count(iid)]
        var b: Button
        if problem == "":
            var after: Dictionary = sh.with_item(slot, iid, items).derived(db)
            text += "\n" + ItemInfo.delta_text(current, after)
            b = _button(text, _on_equip.bind(slot, iid), Vector2(0, 64), 17)
        else:
            text += "\n" + problem
            b = _button(text, _on_blocked.bind(problem), Vector2(0, 64), 17)
            b.modulate = Color(1.0, 1.0, 1.0, 0.55)
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        box.add_child(b)
        box.add_child(_label(ItemInfo.item_line(iid, items, weapons, false), 15, COL_DIM))
    if count == 0:
        box.add_child(_label("Nothing in the bag fits this slot. Visit the Shop tab.", 17, COL_DIM))


# ---------------------------------------------------------------- Sigils tab

func _linked(sh: CharacterSheet, group: String, a: int, b: int, items: Dictionary) -> bool:
    return sh.linked_indices(group, a, items).has(b)


func _fill_sigils(box: VBoxContainer) -> void:
    var sh: CharacterSheet = party.sheet(selected_id)
    if sh == null:
        return
    var items: Dictionary = db.get("items", {})
    var sdefs: Dictionary = db.get("sigils", {})
    box.add_child(_label("Sigils sit in the sockets of the weapon and the armor. Linked sockets (=) let a support sigil boost its neighbour. A better item levels sigils faster.", 15, COL_DIM))
    for group in CharacterSheet.SIGIL_GROUPS:
        var item_id: String = sh.item_in(group)
        var n: int = sh.socket_count(group, items)
        var head: String = "%s: %s" % [ItemInfo.slot_name(group), "- nothing equipped -" if item_id == "" else _item_name(item_id)]
        if n > 0:
            head += "   %d sockets, AP x%d" % [n, sh.socket_ap_mult(group, items)]
        box.add_child(_label(head, 20, COL_GOLD))
        if n == 0:
            box.add_child(_label("This item has no sockets.", 16, COL_DIM))
            continue
        var flow := HFlowContainer.new()
        flow.add_theme_constant_override("h_separation", 14)
        flow.add_theme_constant_override("v_separation", 8)
        flow.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        var i := 0
        while i < n:
            var unit := HBoxContainer.new()
            unit.add_theme_constant_override("separation", 4)
            unit.add_child(_socket_button(sh, group, i, sdefs))
            if i + 1 < n and _linked(sh, group, i, i + 1, items):
                unit.add_child(_label("=", 28, COL_GOLD))
                unit.add_child(_socket_button(sh, group, i + 1, sdefs))
                i += 2
            else:
                i += 1
            flow.add_child(unit)
        box.add_child(flow)
        if group == focus_group and focus_index >= 0 and focus_index < n:
            _fill_socket_choices(box, sh, group, focus_index)


func _socket_button(sh: CharacterSheet, group: String, index: int, sdefs: Dictionary) -> Button:
    var inst: Dictionary = sh.sigil_at(group, index)
    var text: String = "- empty -\nsocket %d" % (index + 1)
    if not inst.is_empty():
        var sd: Dictionary = sdefs.get(str(inst.get("id", "")), {})
        text = "%s\n%s" % [ItemInfo.sigil_short(inst, sd), ItemInfo.sigil_ap_text(inst, sd)]
    var b := _button(text, _on_socket.bind(group, index), Vector2(124, 84), 16)
    if group == focus_group and index == focus_index:
        b.modulate = COL_GOLD
    return b


func _fill_socket_choices(box: VBoxContainer, sh: CharacterSheet, group: String, index: int) -> void:
    var items: Dictionary = db.get("items", {})
    var sdefs: Dictionary = db.get("sigils", {})
    var skills: Dictionary = db.get("skills", {})
    var inst: Dictionary = sh.sigil_at(group, index)
    if inst.is_empty():
        box.add_child(_label("Socket %d is empty. Choose a sigil from the bag:" % (index + 1), 18))
    else:
        var sd: Dictionary = sdefs.get(str(inst.get("id", "")), {})
        var lv: int = CharacterSheet.sigil_level(inst, sd)
        var info: String = "%s\n%s\n%s" % [str(sd.get("name", "?")), ItemInfo.sigil_progress(inst, sd), ItemInfo.sigil_effect(sd, lv, skills)]
        var linked_ap: int = sh.linked_support(group, index, items, sdefs, "ap_pct")
        if linked_ap > 0:
            info += "\nLinked Tutor: +%d%% AP" % linked_ap
        box.add_child(_label(info, 17))
        box.add_child(_button("Remove (back to the bag)", _on_unsocket.bind(group, index), Vector2(0, 52), 18))
        box.add_child(_label("Swap with a sigil from the bag:", 17, COL_DIM))
    if party.sigil_inv.is_empty():
        box.add_child(_label("The bag holds no sigils. Buy one in the Shop tab, or master a sigil to forge a copy.", 16, COL_DIM))
    for bag_i in range(party.sigil_inv.size()):
        var bi: Dictionary = party.sigil_inv[bag_i]
        var bd: Dictionary = sdefs.get(str(bi.get("id", "")), {})
        var blv: int = CharacterSheet.sigil_level(bi, bd)
        var text: String = "%s   %s" % [str(bd.get("name", "?")), ItemInfo.sigil_progress(bi, bd)]
        var b := _button(text, _on_socket_sigil.bind(group, index, bag_i), Vector2(0, 56), 17)
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        box.add_child(b)
        box.add_child(_label(ItemInfo.sigil_effect(bd, blv, skills), 15, COL_DIM))


# ---------------------------------------------------------------- Shop tab

func _fill_shop(box: VBoxContainer) -> void:
    var items: Dictionary = db.get("items", {})
    var sdefs: Dictionary = db.get("sigils", {})
    var weapons: Dictionary = db.get("weapons", {})
    var skills: Dictionary = db.get("skills", {})
    var mode_row := HBoxContainer.new()
    mode_row.add_theme_constant_override("separation", 8)
    var buy_b := _button("Buy", _on_shop_mode.bind(false), Vector2(0, 52), 20)
    var sell_b := _button("Sell", _on_shop_mode.bind(true), Vector2(0, 52), 20)
    buy_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    sell_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    if shop_selling:
        sell_b.modulate = COL_GOLD
    else:
        buy_b.modulate = COL_GOLD
    mode_row.add_child(buy_b)
    mode_row.add_child(sell_b)
    box.add_child(mode_row)
    box.add_child(_label("%s     Gold: %d" % [str(shop.get("name", "Shop")), party.gold], 20, COL_GOLD))
    if not shop_selling:
        for entry in ShopSystem.stock(shop, db):
            var e: Dictionary = entry
            var kind: String = str(e["kind"])
            var id: String = str(e["id"])
            var price: int = int(e["price"])
            var b := _button("%s      %d g" % [str(e["name"]), price], _on_buy.bind(kind, id), Vector2(0, 56), 19)
            b.alignment = HORIZONTAL_ALIGNMENT_LEFT
            b.disabled = party.gold < price
            box.add_child(b)
            if kind == "item":
                box.add_child(_label(ItemInfo.item_line(id, items, weapons, false), 15, COL_DIM))
            else:
                var sd: Dictionary = sdefs.get(id, {})
                var th: Array = sd.get("ap", [])
                var ap_list: Array[String] = []
                for t in th:
                    ap_list.append(str(int(t)))
                box.add_child(_label("%s.  AP to level up: %s" % [ItemInfo.sigil_effect(sd, 1, skills), " / ".join(PackedStringArray(ap_list))], 15, COL_DIM))
        return
    box.add_child(_label("Selling pays %d%% of the price. Equipped gear is not listed; heirlooms cannot be sold." % roundi(ShopSystem.sell_ratio(shop) * 100.0), 15, COL_DIM))
    var ids: Array = party.inventory.keys()
    ids.sort()
    var listed := 0
    for k in ids:
        var iid: String = str(k)
        var it: Dictionary = items.get(iid, {})
        var base_price: int = int(it.get("price", 0))
        var sellable: bool = base_price > 0 and str(it.get("rarity", "")) != "heirloom" and str(it.get("bound_to", "")) == ""
        var label: String = "%s  x%d      %d g" % [str(it.get("name", iid)), party.item_count(iid), ShopSystem.sell_price(base_price, shop)]
        if not sellable:
            label = "%s  x%d      (cannot be sold)" % [str(it.get("name", iid)), party.item_count(iid)]
        var sb := _button(label, _on_sell_item.bind(iid), Vector2(0, 56), 19)
        sb.alignment = HORIZONTAL_ALIGNMENT_LEFT
        sb.disabled = not sellable
        box.add_child(sb)
        listed += 1
    for bag_i in range(party.sigil_inv.size()):
        var bi: Dictionary = party.sigil_inv[bag_i]
        var bd: Dictionary = sdefs.get(str(bi.get("id", "")), {})
        var sell_for: int = ShopSystem.sell_price(int(bd.get("price", 0)), shop)
        var sgb := _button("%s   %s      %d g" % [str(bd.get("name", "?")), ItemInfo.sigil_progress(bi, bd), sell_for], _on_sell_sigil.bind(bag_i), Vector2(0, 56), 17)
        sgb.alignment = HORIZONTAL_ALIGNMENT_LEFT
        box.add_child(sgb)
        listed += 1
    if listed == 0:
        box.add_child(_label("Nothing to sell.", 17, COL_DIM))


# ---------------------------------------------------------------- actions (each ends in a rebuild)

func _after(text: String, did_change: bool = false) -> void:
    message = text
    if did_change:
        changed = true
    _rebuild()


func _on_select(id: String) -> void:
    selected_id = id
    focus_slot = ""
    focus_group = ""
    focus_index = -1
    reset_scroll = true
    _after("")


func _on_tab(t: int) -> void:
    tab = t
    focus_slot = ""
    focus_group = ""
    focus_index = -1
    reset_scroll = true
    _after("")


func _on_slot(slot: String) -> void:
    focus_slot = "" if focus_slot == slot else slot
    _after("")


func _on_equip(slot: String, item_id: String) -> void:
    var problem: String = party.equip(selected_id, slot, item_id, db)
    if problem != "":
        _after(problem)
        return
    focus_slot = ""
    _after("Equipped %s." % _item_name(item_id), true)


func _on_unequip(slot: String) -> void:
    var old: String = party.sheet(selected_id).item_in(slot)
    var problem: String = party.unequip(selected_id, slot, db)
    if problem != "":
        _after(problem)
        return
    focus_slot = ""
    _after("Took off %s." % _item_name(old), true)


func _on_blocked(reason: String) -> void:
    _after(reason)


func _on_socket(group: String, index: int) -> void:
    if focus_group == group and focus_index == index:
        focus_group = ""
        focus_index = -1
    else:
        focus_group = group
        focus_index = index
    _after("")


func _on_socket_sigil(group: String, index: int, bag_index: int) -> void:
    var sigil_name: String = _bag_sigil_name(bag_index)
    var problem: String = party.equip_sigil(selected_id, group, index, bag_index, db)
    if problem != "":
        _after(problem)
        return
    _after("Socketed %s." % sigil_name, true)


func _on_unsocket(group: String, index: int) -> void:
    var problem: String = party.unequip_sigil(selected_id, group, index, db)
    if problem != "":
        _after(problem)
        return
    _after("Sigil returned to the bag.", true)


func _on_shop_mode(selling: bool) -> void:
    shop_selling = selling
    reset_scroll = true
    _after("")


func _on_buy(kind: String, id: String) -> void:
    var problem: String = ""
    var shown: String = id
    if kind == "item":
        problem = ShopSystem.buy_item(party, id, db, shop)
        shown = _item_name(id)
    else:
        problem = ShopSystem.buy_sigil(party, id, db, shop)
        shown = str(_sigil_def(id).get("name", id))
    if problem != "":
        _after(problem)
        return
    _after("Bought %s." % shown, true)


func _on_sell_item(item_id: String) -> void:
    var shown: String = _item_name(item_id)
    var problem: String = ShopSystem.sell_item(party, item_id, db, shop)
    if problem != "":
        _after(problem)
        return
    _after("Sold %s." % shown, true)


func _on_sell_sigil(bag_index: int) -> void:
    var shown: String = _bag_sigil_name(bag_index)
    var problem: String = ShopSystem.sell_sigil(party, bag_index, db, shop)
    if problem != "":
        _after(problem)
        return
    _after("Sold %s." % shown, true)


func _on_promote(class_id: String) -> void:
    var sh: CharacterSheet = party.sheet(selected_id)
    if sh != null and sh.promote(class_id, db.get("classes", {})):
        _after("%s is now a %s." % [sh.display_name, _class_title(class_id)], true)
    else:
        _after("Promotion is not possible.")
