extends PanelContainer
class_name SettingsPanel
## Reusable touch-friendly settings overlay for Home and the world menu.

signal closed

var _sliders: Dictionary = {}


func _ready() -> void:
    _build()
    visible = false


func open() -> void:
    _refresh_values()
    visible = true


func _build() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    custom_minimum_size = Vector2(520, 0)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.12, 0.12, 0.11, 0.99)
    style.border_color = Color(0.62, 0.51, 0.32, 1.0)
    style.set_border_width_all(2)
    style.set_corner_radius_all(12)
    style.content_margin_left = 24
    style.content_margin_right = 24
    style.content_margin_top = 20
    style.content_margin_bottom = 20
    add_theme_stylebox_override("panel", style)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    add_child(box)
    var title := Label.new()
    title.text = "Settings"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 32)
    box.add_child(title)
    _add_volume(box, "Master volume", "master")
    _add_volume(box, "Music volume", "music")
    _add_volume(box, "Sound effects", "sfx")
    var note := Label.new()
    note.text = "Audio is generated locally. No connection required."
    note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    note.add_theme_font_size_override("font_size", 14)
    box.add_child(note)
    var preview := Button.new()
    preview.text = "Preview sound"
    preview.custom_minimum_size.y = 52
    preview.pressed.connect(AudioManager.play_ui_click)
    box.add_child(preview)
    var done := Button.new()
    done.text = "Done"
    done.custom_minimum_size.y = 56
    done.pressed.connect(_on_done)
    box.add_child(done)


func _add_volume(parent: VBoxContainer, caption: String, key: String) -> void:
    var row := VBoxContainer.new()
    row.add_theme_constant_override("separation", 3)
    var heading := HBoxContainer.new()
    var label := Label.new()
    label.text = caption
    label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var value_label := Label.new()
    value_label.custom_minimum_size.x = 54
    value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    heading.add_child(label)
    heading.add_child(value_label)
    var slider := HSlider.new()
    slider.min_value = 0.0
    slider.max_value = 1.0
    slider.step = 0.05
    slider.custom_minimum_size.y = 34
    slider.value_changed.connect(_on_volume_changed.bind(key, value_label))
    row.add_child(heading)
    row.add_child(slider)
    parent.add_child(row)
    _sliders[key] = {"slider": slider, "label": value_label}


func _refresh_values() -> void:
    for key_value in _sliders.keys():
        var key := str(key_value)
        var entry: Dictionary = _sliders[key]
        var amount := SettingsStore.volume(key)
        (entry["slider"] as HSlider).set_value_no_signal(amount)
        (entry["label"] as Label).text = "%d%%" % int(round(amount * 100.0))


func _on_volume_changed(amount: float, key: String, value_label: Label) -> void:
    SettingsStore.set_volume(key, amount)
    value_label.text = "%d%%" % int(round(amount * 100.0))
    AudioManager.apply_settings()


func _on_done() -> void:
    visible = false
    closed.emit()
