extends Control
class_name SlotPicker
## Reusable touch-first manual/autosave slot chooser. Emits a slot id; callers own load/save semantics.

signal selected(slot_id: String, mode: String)
signal cancelled

const MANUAL_SLOTS: Array[String] = ["world", "1", "2", "3"]
const AUTO_SLOTS: Array[String] = ["auto_a", "auto_b"]

var mode: String = "load"
var title_label: Label
var rows: VBoxContainer
var message_label: Label
var confirm_dialog: ConfirmationDialog
var pending_slot: String = ""


func open(p_mode: String = "load") -> void:
    mode = "save" if p_mode == "save" else "load"
    if not is_inside_tree():
        return
    _refresh()
    visible = true


func close() -> void:
    visible = false
    pending_slot = ""


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP
    var shade := ColorRect.new()
    shade.color = Color(0.015, 0.02, 0.025, 0.82)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(shade)

    var centre := CenterContainer.new()
    centre.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(centre)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(560, 0)
    var style := StyleBoxFlat.new()
    style.bg_color = Color("#211f1a")
    style.border_color = Color("#94784b")
    style.set_border_width_all(2)
    style.set_corner_radius_all(10)
    style.content_margin_left = 22
    style.content_margin_right = 22
    style.content_margin_top = 20
    style.content_margin_bottom = 20
    panel.add_theme_stylebox_override("panel", style)
    centre.add_child(panel)
    var stack := VBoxContainer.new()
    stack.add_theme_constant_override("separation", 10)
    panel.add_child(stack)

    title_label = Label.new()
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.add_theme_font_size_override("font_size", 30)
    stack.add_child(title_label)
    message_label = Label.new()
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    stack.add_child(message_label)
    var scroll := ScrollContainer.new()
    scroll.custom_minimum_size = Vector2(500, 330)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    rows = VBoxContainer.new()
    rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    rows.add_theme_constant_override("separation", 8)
    scroll.add_child(rows)
    stack.add_child(scroll)
    var close_button := Button.new()
    close_button.text = "Cancel"
    close_button.custom_minimum_size = Vector2(0, 58)
    close_button.add_theme_font_size_override("font_size", 22)
    close_button.pressed.connect(func(): close(); cancelled.emit())
    stack.add_child(close_button)

    confirm_dialog = ConfirmationDialog.new()
    confirm_dialog.title = "Overwrite save?"
    confirm_dialog.dialog_text = "This slot already contains a save. Replace it?"
    confirm_dialog.ok_button_text = "Overwrite"
    confirm_dialog.confirmed.connect(_confirm_overwrite)
    add_child(confirm_dialog)
    visible = false


func _refresh() -> void:
    if rows == null:
        return
    title_label.text = "Save Game" if mode == "save" else "Load Game"
    message_label.text = "Choose a manual slot or a rotating autosave."
    for child in rows.get_children():
        child.queue_free()
    var ids: Array[String] = []
    if mode == "save":
        ids.append_array(MANUAL_SLOTS)
    else:
        ids.append_array(MANUAL_SLOTS)
        ids.append_array(AUTO_SLOTS)
    for slot_id in ids:
        var info: Dictionary = SaveSystem.slot_info(slot_id)
        var exists := bool(info.get("exists", false))
        var label := _slot_label(slot_id, info)
        var button := Button.new()
        button.text = label
        button.custom_minimum_size = Vector2(0, 66)
        button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        button.add_theme_font_size_override("font_size", 18)
        button.disabled = mode == "load" and not exists
        button.pressed.connect(_on_slot_pressed.bind(slot_id, exists))
        rows.add_child(button)


func _slot_label(slot_id: String, info: Dictionary) -> String:
    var names := {"world": "Manual — World", "1": "Manual — Slot 1", "2": "Manual — Slot 2", "3": "Manual — Slot 3", "auto_a": "Autosave A", "auto_b": "Autosave B"}
    if not bool(info.get("exists", false)):
        return "%s  •  Empty" % str(names.get(slot_id, slot_id))
    var summary := str(info.get("summary", "Save available"))
    var saved_at := str(info.get("saved_at", ""))
    return "%s\n%s  •  %s" % [str(names.get(slot_id, slot_id)), summary, saved_at]


func _on_slot_pressed(slot_id: String, exists: bool) -> void:
    if mode == "save" and exists:
        pending_slot = slot_id
        confirm_dialog.popup_centered(Vector2i(480, 200))
        return
    selected.emit(slot_id, mode)
    close()


func _confirm_overwrite() -> void:
    if pending_slot == "":
        return
    selected.emit(pending_slot, mode)
    close()
