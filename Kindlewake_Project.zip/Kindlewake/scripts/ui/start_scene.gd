extends Node
## Character select scene (feature character_select): the New Game flow of the start menu opens it, then the overworld.
## This thin script owns the autoload wiring (GameData, GameState), so CharacterSelect itself stays free of autoloads
## and testable.


func _ready() -> void:
    var cs := CharacterSelect.new()
    cs.setup(GameData.looks, GameData.start, GameData.characters, GameData.classes)
    cs.chosen.connect(_on_chosen)
    add_child(cs)


func _on_chosen(lead_id: String, appearance: Dictionary) -> void:
    GameState.begin_campaign(lead_id, appearance)
    GameState.booted = true                 # the start menu has been handled: the overworld must not show it again
    get_tree().change_scene_to_file("res://World.tscn")
