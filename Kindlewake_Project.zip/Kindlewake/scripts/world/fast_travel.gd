class_name FastTravel
extends RefCounted
## Waystone fast travel (feature "fast_travel", GDD 11.14). Pure logic, no nodes, so the tests can run it.
##
## The rules (all numbers live in data/travel.json):
##  - A waystone only answers while the walker stands inside the safe ground of a settlement (origin_radius).
##  - It can carry the company to any settlement that has been SEEN (world flag "seen_<id>", the flag the overworld
##    already sets when a place comes into sight), so old saves work and there is no new save field.
##  - The destination must be reachable ON FOOT from the origin with the quest gates as they are now: a flood fill over
##    the live WorldMap (closed gates are mountains). Waystones never skip a sealed gate.
##  - The price is gold per 10 tiles of straight-line distance between the two settlements, rounded to a multiple
##    of 5 and clamped between min_gold and max_gold.

const DEFAULT_KINDS: Array[String] = ["keep", "city", "town", "village"]


static func enabled(cfg: Dictionary) -> bool:
    return bool(cfg.get("enabled", true))


static func is_settlement(cfg: Dictionary, kind: String) -> bool:
    var kinds: Array = cfg.get("kinds", DEFAULT_KINDS) as Array
    return kinds.has(kind)


static func place_cell(p: Dictionary) -> Vector2i:
    var a: Array = p.get("cell", [0, 0]) as Array
    return Vector2i(int(a[0]), int(a[1]))


## The settlement whose safe ground contains `cell` ({} when the walker is out in the wild). The nearest one wins.
static func origin_place(wmap: WorldMap, cfg: Dictionary, cell: Vector2i) -> Dictionary:
    var best: Dictionary = {}
    var best_d: float = float(cfg.get("origin_radius", 6))
    for p in wmap.places:
        var d: Dictionary = p
        if not is_settlement(cfg, str(d.get("kind", ""))):
            continue
        var dist: float = Vector2(cell - place_cell(d)).length()
        if dist < best_d:
            best_d = dist
            best = d
    return best


## "" when a waystone answers at `from_cell`, otherwise the reason it does not.
static func depart_problem(wmap: WorldMap, cfg: Dictionary, from_cell: Vector2i) -> String:
    if not enabled(cfg):
        return "The waystones are dark."
    if origin_place(wmap, cfg, from_cell).is_empty():
        return str(cfg.get("need_stone", "Waystones only answer inside a settlement."))
    return ""


## Gold for a trip between two settlements (see the rules above).
static func cost_for(from_cell: Vector2i, to_cell: Vector2i, cfg: Dictionary) -> int:
    var tiles: float = Vector2(to_cell - from_cell).length()
    var raw: float = tiles / 10.0 * float(cfg.get("gold_per_10_tiles", 3))
    var gold: int = int(roundf(raw / 5.0)) * 5
    return clampi(gold, int(cfg.get("min_gold", 10)), int(cfg.get("max_gold", 120)))


## One byte per tile: 1 = the walker can get there on foot from `from_cell` with the gates as they are right now.
## Works on the raw tile bytes (no Vector2i per step) so it stays quick on a phone.
static func reachable_mask(wmap: WorldMap, from_cell: Vector2i) -> PackedByteArray:
    var w: int = wmap.width
    var total: int = w * wmap.height
    var seen := PackedByteArray()
    seen.resize(total)
    if not wmap.walkable(from_cell):
        return seen
    var open := PackedByteArray()
    open.resize(WorldMap.SPEED.size())
    for t in range(WorldMap.SPEED.size()):
        open[t] = 1 if WorldMap.SPEED[t] > 0.0 else 0
    var tiles: PackedByteArray = wmap.tiles
    var first: int = from_cell.y * w + from_cell.x
    var queue := PackedInt32Array()
    queue.append(first)
    seen[first] = 1
    var head: int = 0
    while head < queue.size():
        var idx: int = queue[head]
        head += 1
        var x: int = idx % w
        var n: int = idx - 1
        if x > 0 and seen[n] == 0 and open[tiles[n]] == 1:
            seen[n] = 1
            queue.append(n)
        n = idx + 1
        if x < w - 1 and seen[n] == 0 and open[tiles[n]] == 1:
            seen[n] = 1
            queue.append(n)
        n = idx - w
        if n >= 0 and seen[n] == 0 and open[tiles[n]] == 1:
            seen[n] = 1
            queue.append(n)
        n = idx + w
        if n < total and seen[n] == 0 and open[tiles[n]] == 1:
            seen[n] = 1
            queue.append(n)
    return seen


## Every settlement the party has seen, nearest first. [] when no waystone answers at `from_cell`.
## Each entry: {id, name, kind, region, cell, tiles, cost, state, reason}.
## state: "ok" (can go), "here" (the origin), "cut_off" (a shut gate or no road), "poor" (not enough gold).
static func options(wmap: WorldMap, cfg: Dictionary, flags: Dictionary, gold: int, from_cell: Vector2i) -> Array:
    var out: Array = []
    var origin: Dictionary = origin_place(wmap, cfg, from_cell)
    if origin.is_empty() or not enabled(cfg):
        return out
    var origin_id: String = str(origin.get("id", ""))
    var origin_cell: Vector2i = place_cell(origin)
    var mask: PackedByteArray = reachable_mask(wmap, from_cell)
    for p in wmap.places:
        var d: Dictionary = p
        if not is_settlement(cfg, str(d.get("kind", ""))):
            continue
        var id: String = str(d.get("id", ""))
        if not bool(flags.get("seen_" + id, false)):
            continue
        var c: Vector2i = place_cell(d)
        var cost: int = cost_for(origin_cell, c, cfg)
        var state: String = "ok"
        var reason: String = ""
        if id == origin_id:
            state = "here"
            reason = str(cfg.get("here", "You are already here."))
        elif not wmap.in_bounds(c) or mask[c.y * wmap.width + c.x] == 0:
            state = "cut_off"
            reason = str(cfg.get("cut_off", "The road there is shut."))
        elif gold < cost:
            state = "poor"
            reason = "%s (%d gold)" % [str(cfg.get("too_poor", "Not enough gold.")), cost]
        out.append({"id": id, "name": str(d.get("name", id)), "kind": str(d.get("kind", "")), "region": str(d.get("region", "")),
            "cell": c, "tiles": Vector2(c - origin_cell).length(), "cost": cost, "state": state, "reason": reason})
    out.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a["tiles"]) < float(b["tiles"]))
    return out


## "" when the party may travel to `place_id` right now, otherwise the reason. Re-checks everything: the UI is not trusted.
static func problem(wmap: WorldMap, cfg: Dictionary, flags: Dictionary, gold: int, from_cell: Vector2i, place_id: String) -> String:
    var why: String = depart_problem(wmap, cfg, from_cell)
    if why != "":
        return why
    for o in options(wmap, cfg, flags, gold, from_cell):
        var od: Dictionary = o
        if str(od["id"]) == place_id:
            return "" if str(od["state"]) == "ok" else str(od["reason"])
    return "You have not seen that place yet."


## Gold the trip from the settlement around `from_cell` to `place_id` costs (0 when there is no such trip).
static func price(wmap: WorldMap, cfg: Dictionary, from_cell: Vector2i, place_id: String) -> int:
    var origin: Dictionary = origin_place(wmap, cfg, from_cell)
    var dest: Dictionary = wmap.place_by_id(place_id)
    if origin.is_empty() or dest.is_empty():
        return 0
    return cost_for(place_cell(origin), place_cell(dest), cfg)


## Where the walker stands after the trip: the settlement's own tile, or the nearest walkable tile within 4.
static func arrival_cell(wmap: WorldMap, place_id: String) -> Vector2i:
    var d: Dictionary = wmap.place_by_id(place_id)
    var c: Vector2i = place_cell(d)
    if wmap.walkable(c):
        return c
    for r in range(1, 5):
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if maxi(absi(dx), absi(dy)) != r:
                    continue
                var n := Vector2i(c.x + dx, c.y + dy)
                if wmap.walkable(n):
                    return n
    return wmap.start_cell
