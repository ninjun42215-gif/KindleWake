class_name WorldStory
extends RefCounted
## Pure campaign progression rules for story gates, place actions and the journal.
## The caller supplies GameState.world_flags and the live PartyState; no save schema changes.

var definitions: Dictionary = {}
var gates_by_id: Dictionary = {}
var actions_by_id: Dictionary = {}
var quests_by_id: Dictionary = {}


func _init(p_definitions: Dictionary = {}) -> void:
    definitions = p_definitions.duplicate(true)
    for entry in definitions.get("gates", []):
        if typeof(entry) == TYPE_DICTIONARY:
            gates_by_id[str(entry.get("id", ""))] = entry
    for entry in definitions.get("place_actions", []):
        if typeof(entry) == TYPE_DICTIONARY:
            actions_by_id[str(entry.get("id", ""))] = entry
    for entry in definitions.get("quests", []):
        if typeof(entry) == TYPE_DICTIONARY:
            quests_by_id[str(entry.get("id", ""))] = entry


## Requirement tokens: flag, !flag, item:item_id and gold:amount. All tokens must pass.
func met(reqs: Array, flags: Dictionary, party: Variant = null) -> bool:
    for raw_req in reqs:
        var req := str(raw_req).strip_edges()
        if req == "":
            return false
        if req.begins_with("!"):
            var absent_flag := req.substr(1)
            if absent_flag == "" or bool(flags.get(absent_flag, false)):
                return false
        elif req.begins_with("item:"):
            var item_id := req.substr(5)
            if item_id == "" or _item_count(party, item_id) < 1:
                return false
        elif req.begins_with("gold:"):
            var amount_text := req.substr(5)
            if not amount_text.is_valid_int() or _gold(party) < int(amount_text):
                return false
        elif not bool(flags.get(req, false)):
            return false
    return true


func gate_open(gate_id: String, flags: Dictionary, party: Variant = null) -> bool:
    var gate: Dictionary = gates_by_id.get(gate_id, {})
    if gate.is_empty():
        return false
    return met(gate.get("requires", []), flags, party)


## Returns a stable, UI-friendly snapshot of one quest. current_step is -1 when complete.
func quest_state(quest_id: String, flags: Dictionary) -> Dictionary:
    var quest: Dictionary = quests_by_id.get(quest_id, {})
    if quest.is_empty():
        return {}
    var steps: Array = quest.get("steps", [])
    var current_step := -1
    var completed_steps: Array[String] = []
    for i in range(steps.size()):
        var step: Dictionary = steps[i]
        if bool(flags.get(str(step.get("flag", "")), false)):
            completed_steps.append(str(step.get("text", "")))
        elif current_step < 0:
            current_step = i
    return {
        "id": quest_id,
        "name": str(quest.get("name", quest_id)),
        "completed": current_step < 0,
        "current_step": current_step,
        "step_count": steps.size(),
        "completed_steps": completed_steps,
        "next_step": "" if current_step < 0 else str((steps[current_step] as Dictionary).get("text", "")),
    }


## Journal text includes quests that have begun or are complete; untouched quests stay hidden.
func journal_lines(flags: Dictionary) -> Array[String]:
    var out: Array[String] = []
    var ids: Array = quests_by_id.keys()
    ids.sort()
    for raw_id in ids:
        var id := str(raw_id)
        var state := quest_state(id, flags)
        var steps: Array = (quests_by_id[id] as Dictionary).get("steps", [])
        var started := false
        for step in steps:
            if bool(flags.get(str((step as Dictionary).get("flag", "")), false)):
                started = true
                break
        if not started:
            continue
        if bool(state["completed"]):
            out.append("%s — Complete" % str(state["name"]))
        else:
            out.append("%s — %s" % [str(state["name"]), str(state["next_step"])])
    return out


func place_action(action_id: String) -> Dictionary:
    return (actions_by_id.get(action_id, {}) as Dictionary).duplicate(true)


func _gold(party: Variant) -> int:
    if typeof(party) == TYPE_DICTIONARY:
        return int((party as Dictionary).get("gold", 0))
    if party is Object:
        return int(party.get("gold"))
    return 0


func _item_count(party: Variant, item_id: String) -> int:
    if typeof(party) == TYPE_DICTIONARY:
        var inventory: Dictionary = (party as Dictionary).get("inventory", {})
        return int(inventory.get(item_id, 0))
    if party is Object:
        if party.has_method("item_count"):
            return int(party.call("item_count", item_id))
        var inventory_value: Variant = party.get("inventory")
        if typeof(inventory_value) == TYPE_DICTIONARY:
            return int((inventory_value as Dictionary).get(item_id, 0))
    return 0
