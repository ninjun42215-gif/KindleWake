class_name RoomMap
extends RefCounted
## One pre-rendered room, FF7 style: a fixed isometric background image (tools/build_scenes.py renders it from a voxel
## model) plus a walk grid that was derived from the same voxels. The hero walks on the grid; the picture is only a picture.
## Geometry comes from data/rooms.json (key = "room" model), contents from data/sites.json (exits, spots, spawn, encounters).
## Pure logic, no nodes: the room scene draws it and tests/run_tests.gd validates every room.
##
## Cell coordinates are voxels (50 x 50). Cell (x, y) spans [x, x+1) x [y, y+1). The camera looks at the room from
## the corner where x and y are both large, so the back walls are the planes x = 0 and y = 0.

const NEIGHBOURS := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
const DIAGONALS := [Vector2i(1, 1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(-1, -1)]
const MAX_STEP := 2                       # largest floor height difference (voxels) between two walked cells

var id: String = ""                       # room key inside its site
var model: String = ""                    # key in rooms.json and the image name (assets/art/rooms/<model>.png)
var title: String = ""
var width: int = 0
var height: int = 0
var walk: Array[String] = []              # '.' walkable, '#' blocked
var heights: Array[String] = []           # base-36 digit per cell: floor height above `base`
var base: int = 0
var a: float = 4.0                        # pixels per half voxel width
var ox: float = 0.0
var oy: float = 0.0
var kz: float = 4.9                       # pixels per voxel of height
var img_w: int = 0
var img_h: int = 0
var slices: Array = []                    # [{"x": px, "y": px, "key": depth}] occluder slice placement
var spawn: Vector2i = Vector2i(25, 25)
var exits: Array = []                     # {"id", "rect": [x0, y0, x1, y1], "to", "spawn", "label"}
var spots: Array = []                     # {"cell", "kind": text|party|chest|battle, "name", "text", ...}
var enc: Array = []                       # [min, max] cells of walking between random encounters; empty = safe room


static func from_defs(room_id: String, geo: Dictionary, def: Dictionary) -> RoomMap:
    var m := RoomMap.new()
    m.id = room_id
    m.model = str(def.get("room", ""))
    m.title = str(def.get("title", room_id))
    for r in (geo.get("walk", []) as Array):
        m.walk.append(str(r))
    for r in (geo.get("height", []) as Array):
        m.heights.append(str(r))
    m.height = m.walk.size()
    m.width = 0 if m.walk.is_empty() else m.walk[0].length()
    m.base = int(geo.get("base", 0))
    m.a = float(geo.get("a", 4.0))
    m.ox = float(geo.get("ox", 0.0))
    m.oy = float(geo.get("oy", 0.0))
    m.kz = float(geo.get("kz", 4.9))
    m.img_w = int(geo.get("w", 0))
    m.img_h = int(geo.get("h", 0))
    m.slices = (geo.get("slices", []) as Array).duplicate(true)
    var sp: Array = def.get("spawn", [25, 25])
    m.spawn = Vector2i(int(sp[0]), int(sp[1]))
    m.exits = (def.get("exits", []) as Array).duplicate(true)
    m.spots = (def.get("spots", []) as Array).duplicate(true)
    m.enc = (def.get("enc", []) as Array).duplicate()
    return m


## Every room of a site, keyed by room id.
static func load_site(site: Dictionary, geometry: Dictionary) -> Dictionary:
    var out: Dictionary = {}
    var defs: Dictionary = site.get("rooms", {})
    for k in defs.keys():
        var d: Dictionary = defs[k]
        var geo: Dictionary = geometry.get(str(d.get("room", "")), {})
        out[str(k)] = RoomMap.from_defs(str(k), geo, d)
    return out


func in_bounds(c: Vector2i) -> bool:
    return c.x >= 0 and c.y >= 0 and c.y < height and c.x < width


func walkable(c: Vector2i) -> bool:
    if not in_bounds(c):
        return false
    return walk[c.y].substr(c.x, 1) == "."


## Floor height of a cell in voxels above `base` (0 for blocked cells).
func floor_dz(c: Vector2i) -> int:
    if not in_bounds(c) or c.y >= heights.size() or c.x >= heights[c.y].length():
        return 0
    var u: int = heights[c.y].unicode_at(c.x)
    return u - 87 if u >= 97 else maxi(0, u - 48)


func cell_of(p: Vector2) -> Vector2i:
    return Vector2i(floori(p.x), floori(p.y))


## Screen position (in room image pixels) of a point on the floor: p is in cell units, dz in voxels above `base`.
func project(p: Vector2, dz: float) -> Vector2:
    var z: float = float(base) + dz
    return Vector2(ox + (p.x - p.y) * a, oy + (p.x + p.y) * a * 0.5 - z * kz)


## Inverse of project() for a known height.
func unproject(s: Vector2, dz: float) -> Vector2:
    var z: float = float(base) + dz
    var u: float = (s.x - ox) / a
    var v: float = (s.y - oy + z * kz) / (a * 0.5)
    return Vector2((u + v) * 0.5, (v - u) * 0.5)


## The cell under a screen point. The height of the floor is unknown until the cell is known, so it settles in a few passes.
func cell_at_screen(s: Vector2, start_dz: float = 0.0) -> Vector2i:
    var dz: float = start_dz
    var c: Vector2i = cell_of(unproject(s, dz))
    for _i in range(4):
        dz = float(floor_dz(c)) if walkable(c) else dz
        c = cell_of(unproject(s, dz))
    return c


## Nearest walkable cell to `c` (ring search); (-1, -1) if none within `max_r`.
func nearest_walkable(c: Vector2i, max_r: int = 14) -> Vector2i:
    if walkable(c):
        return c
    var best: Vector2i = Vector2i(-1, -1)
    var best_d: int = 1 << 30
    for r in range(1, max_r + 1):
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if maxi(absi(dx), absi(dy)) != r:
                    continue
                var n := Vector2i(c.x + dx, c.y + dy)
                if walkable(n):
                    var d: int = dx * dx + dy * dy
                    if d < best_d:
                        best_d = d
                        best = n
        if best.x >= 0:
            return best
    return best


func _step_ok(from: Vector2i, to: Vector2i) -> bool:
    return walkable(to) and absi(floor_dz(to) - floor_dz(from)) <= MAX_STEP


## Shortest route between two walkable cells over 8 neighbours (diagonals only when both side cells are open),
## as a list of cells that does not include `from`. Empty when `to` cannot be reached.
func find_path(from: Vector2i, to: Vector2i) -> Array[Vector2i]:
    var out: Array[Vector2i] = []
    if not walkable(from) or not walkable(to) or from == to:
        return out
    var prev: Dictionary = {from: from}
    var queue: Array[Vector2i] = [from]
    var head: int = 0
    var found: bool = false
    while head < queue.size() and not found:
        var c: Vector2i = queue[head]
        head += 1
        var steps: Array = NEIGHBOURS.duplicate()
        steps.append_array(DIAGONALS)
        for d in steps:
            var n: Vector2i = c + (d as Vector2i)
            if prev.has(n) or not _step_ok(c, n):
                continue
            if (d as Vector2i).x != 0 and (d as Vector2i).y != 0:
                if not _step_ok(c, Vector2i(c.x + (d as Vector2i).x, c.y)) or not _step_ok(c, Vector2i(c.x, c.y + (d as Vector2i).y)):
                    continue
            prev[n] = c
            if n == to:
                found = true
                break
            queue.append(n)
    if not found:
        return out
    var cur: Vector2i = to
    while cur != from:
        out.append(cur)
        cur = prev[cur]
    out.reverse()
    return out


## Every cell the hero can walk to from `from` (flood fill with the same step rule as find_path), as {cell: true}.
func region(from: Vector2i) -> Dictionary:
    var seen: Dictionary = {}
    if not walkable(from):
        return seen
    seen[from] = true
    var queue: Array[Vector2i] = [from]
    var head: int = 0
    while head < queue.size():
        var c: Vector2i = queue[head]
        head += 1
        for d in NEIGHBOURS:
            var n: Vector2i = c + (d as Vector2i)
            if not seen.has(n) and _step_ok(c, n):
                seen[n] = true
                queue.append(n)
    return seen


func reachable(from: Vector2i, to: Vector2i) -> bool:
    return region(from).has(to)


## True when the straight walk from p to q stays on walkable cells of about the same height.
func line_clear(p: Vector2, q: Vector2) -> bool:
    var dist: float = p.distance_to(q)
    var n: int = maxi(1, int(ceil(dist / 0.25)))
    var last: Vector2i = cell_of(p)
    for i in range(1, n + 1):
        var pt: Vector2 = p.lerp(q, float(i) / float(n))
        var c: Vector2i = cell_of(pt)
        if c != last:
            if not _step_ok(last, c):
                return false
            last = c
    return true


## A walk target as a list of points (cell centres) with the shortcuts removed. Empty when there is no route.
func route(from: Vector2, to_cell: Vector2i) -> Array[Vector2]:
    var out: Array[Vector2] = []
    var start: Vector2i = cell_of(from)
    if not walkable(start):
        start = nearest_walkable(start)
        if start.x < 0:
            return out
    var cells: Array[Vector2i] = find_path(start, to_cell)
    if cells.is_empty():
        if start == to_cell:
            out.append(Vector2(float(to_cell.x) + 0.5, float(to_cell.y) + 0.5))
        return out
    var pts: Array[Vector2] = []
    for c in cells:
        pts.append(Vector2(float(c.x) + 0.5, float(c.y) + 0.5))
    var anchor: Vector2 = from
    var i: int = 0
    while i < pts.size():
        var far: int = i
        for j in range(pts.size() - 1, i - 1, -1):
            if line_clear(anchor, pts[j]):
                far = j
                break
        out.append(pts[far])
        anchor = pts[far]
        i = far + 1
    return out


func exit_rect(e: Dictionary) -> Rect2i:
    var r: Array = e.get("rect", [0, 0, 0, 0])
    return Rect2i(int(r[0]), int(r[1]), int(r[2]) - int(r[0]) + 1, int(r[3]) - int(r[1]) + 1)


## The exit whose rectangle contains cell `c` ({} if none).
func exit_at(c: Vector2i) -> Dictionary:
    for e in exits:
        var rc: Rect2i = exit_rect(e)
        if c.x >= rc.position.x and c.y >= rc.position.y and c.x < rc.position.x + rc.size.x and c.y < rc.position.y + rc.size.y:
            return e
    return {}


func exit_centre(e: Dictionary) -> Vector2:
    var rc: Rect2i = exit_rect(e)
    return Vector2(float(rc.position.x) + float(rc.size.x) * 0.5, float(rc.position.y) + float(rc.size.y) * 0.5)


func spot_cell(s: Dictionary) -> Vector2i:
    var c: Array = s.get("cell", [0, 0])
    return Vector2i(int(c[0]), int(c[1]))


## Every problem found in a set of sites (empty = all fine). `geometry` is rooms.json "rooms"; `battles` and `items` are
## checked for chest rewards and boss fights. Used by the tests.
static func validate(sites: Dictionary, geometry: Dictionary, battles: Dictionary, items: Dictionary) -> Array[String]:
    var errs: Array[String] = []
    for sk in sites.keys():
        var site: Dictionary = sites[sk]
        var maps: Dictionary = RoomMap.load_site(site, geometry)
        var start: String = str(site.get("start", ""))
        if not maps.has(start):
            errs.append("%s: start room '%s' is missing" % [str(sk), start])
        for rk in maps.keys():
            var m: RoomMap = maps[rk]
            var where: String = "%s/%s" % [str(sk), str(rk)]
            if not geometry.has(m.model):
                errs.append("%s: no geometry for model '%s'" % [where, m.model])
                continue
            if m.width != 50 or m.height != 50 or m.heights.size() != m.height:
                errs.append("%s: walk grid is not 50x50" % where)
                continue
            if not m.walkable(m.spawn):
                errs.append("%s: spawn is blocked" % where)
                continue
            if m.exits.is_empty():
                errs.append("%s: no exit" % where)
            var reg: Dictionary = m.region(m.spawn)
            var seen: Dictionary = {}
            for e in m.exits:
                var ed: Dictionary = e
                var eid: String = str(ed.get("id", ""))
                if seen.has(eid):
                    errs.append("%s: duplicate exit id '%s'" % [where, eid])
                seen[eid] = true
                var rc: Rect2i = m.exit_rect(ed)
                var hit: bool = false
                for yy in range(rc.position.y, rc.position.y + rc.size.y):
                    for xx in range(rc.position.x, rc.position.x + rc.size.x):
                        var cc := Vector2i(xx, yy)
                        if not hit and reg.has(cc):
                            hit = true
                if not hit:
                    errs.append("%s: exit '%s' cannot be reached from the spawn" % [where, eid])
                if m.exit_at(m.spawn).has("id"):
                    errs.append("%s: the spawn stands inside exit '%s'" % [where, str(m.exit_at(m.spawn)["id"])])
                var to: String = str(ed.get("to", ""))
                if to == "@leave":
                    continue
                if not maps.has(to):
                    errs.append("%s: exit '%s' leads to missing room '%s'" % [where, eid, to])
                    continue
                var target: RoomMap = maps[to]
                var sp: Array = ed.get("spawn", [-1, -1])
                var sc := Vector2i(int(sp[0]), int(sp[1]))
                if not target.walkable(sc):
                    errs.append("%s: exit '%s' spawns on a blocked cell" % [where, eid])
                elif not target.region(target.spawn).has(sc):
                    errs.append("%s: exit '%s' spawns in a part of '%s' that is cut off" % [where, eid, to])
                elif target.exit_at(sc).has("id"):
                    errs.append("%s: exit '%s' spawns inside an exit of '%s' (it would bounce back)" % [where, eid, to])
            var names: Dictionary = {}
            for s in m.spots:
                var sd: Dictionary = s
                var nm: String = str(sd.get("name", ""))
                if nm == "" or names.has(nm):
                    errs.append("%s: spot name '%s' is empty or repeated" % [where, nm])
                names[nm] = true
                var sc2: Vector2i = m.spot_cell(sd)
                var near: bool = false
                for dy in range(-3, 4):
                    for dx in range(-3, 4):
                        var n := Vector2i(sc2.x + dx, sc2.y + dy)
                        if not near and float(dx * dx + dy * dy) <= 9.0 and reg.has(n):
                            near = true
                if not near:
                    errs.append("%s: spot '%s' cannot be reached" % [where, nm])
                var kind: String = str(sd.get("kind", "text"))
                if kind == "chest":
                    if str(sd.get("chest_id", "")) == "":
                        errs.append("%s: chest '%s' has no chest_id" % [where, nm])
                    for iid in (sd.get("items", {}) as Dictionary).keys():
                        if not items.has(str(iid)):
                            errs.append("%s: chest '%s' holds unknown item '%s'" % [where, nm, str(iid)])
                elif kind == "battle":
                    if not battles.has(str(sd.get("battle", ""))):
                        errs.append("%s: battle '%s' is missing" % [where, str(sd.get("battle", ""))])
                elif kind != "text" and kind != "party":
                    errs.append("%s: spot '%s' has unknown kind '%s'" % [where, nm, kind])
            if not m.enc.is_empty() and (m.enc.size() != 2 or int(m.enc[0]) <= 0 or int(m.enc[1]) < int(m.enc[0])):
                errs.append("%s: enc must be [min, max] with 0 < min <= max" % where)
        # every room must be reachable through the exits from the start room
        if maps.has(start):
            var reach: Dictionary = {start: true}
            var todo: Array = [start]
            while not todo.is_empty():
                var cur: String = str(todo.pop_back())
                for e2 in (maps[cur] as RoomMap).exits:
                    var t2: String = str((e2 as Dictionary).get("to", ""))
                    if maps.has(t2) and not reach.has(t2):
                        reach[t2] = true
                        todo.append(t2)
            for rk2 in maps.keys():
                if not reach.has(str(rk2)):
                    errs.append("%s/%s: cannot be reached from the start room" % [str(sk), str(rk2)])
    return errs
