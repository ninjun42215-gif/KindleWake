class_name WorldMap
extends RefCounted
## The overworld of Eldrimar (Milestone 7). Two ways to build it, both pure logic (no nodes):
##  - WorldMap.generate(cfg, map_data): the real world. map_data is data/world_map.json (written by tools/make_world.py):
##    452 x 340 tiles, one byte per tile, plus a second byte layer saying which region each tile belongs to.
##  - WorldMap.generate(cfg): a small procedural map from deterministic value noise (used by the tests).
## The world scene draws it and tests/run_tests.gd checks it.

const GRASS := 0
const FOREST := 1
const HILL := 2
const FORD := 3
const WATER := 4
const MOUNTAIN := 5
const ROAD := 6
const BRIDGE := 7
const SAND := 8
const SNOW := 9
const MARSH := 10

const NAMES: Array[String] = ["Grass", "Forest", "Hill", "Ford", "Deep Water", "Mountain", "Road", "Bridge", "Dry Steppe", "Snow", "Marsh"]
## Walking speed multiplier and ambush danger per terrain type (0 speed = blocked).
const SPEED: Array[float] = [1.0, 0.6, 0.7, 0.5, 0.0, 0.0, 1.4, 1.2, 0.9, 0.75, 0.55]
const DANGER: Array[float] = [1.0, 1.6, 1.0, 1.2, 0.0, 0.0, 0.3, 0.3, 1.0, 1.2, 1.3]
## Battle-map legend character for each world terrain (see data/terrain.json and BATTLE_LEGEND).
const BATTLE_CHAR: Array[String] = [".", "f", "h", "w", "~", "#", "r", "b", "s", "n", "m"]
const BATTLE_LEGEND := {".": "grass", "f": "forest", "r": "road", "h": "hill", "w": "ford", "~": "deep_water", "b": "bridge", "#": "rock", "s": "sand", "n": "snow", "m": "marsh"}

var width: int = 0
var height: int = 0
var seed_value: int = 0
var tiles: PackedByteArray = PackedByteArray()
var places: Array = []                  # entries of data/world.json "places"
var start_cell: Vector2i = Vector2i.ZERO
var regions: PackedByteArray = PackedByteArray()   # region index per tile (empty on small procedural maps)
var region_defs: Array = []             # entries of data/world.json "regions": {id, name, tier, text}
var gate_definitions: Dictionary = {}
var world_flags: Dictionary = {}
var story_party: Variant = null
var _base_tiles: PackedByteArray = PackedByteArray()
var _gate_cells: Dictionary = {}        # Vector2i -> gate id
var _gate_cell_originals: Dictionary = {} # Vector2i -> original terrain


static func hash01(x: int, y: int, s: int) -> float:
    var h: int = (x * 374761393 + y * 668265263 + s * 1442695041) & 0x7fffffff
    h = ((h ^ (h >> 13)) * 1274126177) & 0x7fffffff
    h = h ^ (h >> 16)
    return float(h & 0xffff) / 65535.0


static func noise(x: int, y: int, scale: float, s: int) -> float:
    var fx: float = float(x) / scale
    var fy: float = float(y) / scale
    var ix: int = floori(fx)
    var iy: int = floori(fy)
    var tx: float = fx - float(ix)
    var ty: float = fy - float(iy)
    tx = tx * tx * (3.0 - 2.0 * tx)
    ty = ty * ty * (3.0 - 2.0 * ty)
    var a: float = lerpf(hash01(ix, iy, s), hash01(ix + 1, iy, s), tx)
    var b: float = lerpf(hash01(ix, iy + 1, s), hash01(ix + 1, iy + 1, s), tx)
    return lerpf(a, b, ty)


## Builds the world. With `map_data` (data/world_map.json) the tiles come from the file, otherwise from noise.
static func generate(cfg: Dictionary, map_data: Dictionary = {}, gates_data: Dictionary = {}, flags: Dictionary = {}, party: Variant = null) -> WorldMap:
    if map_data.has("tiles_b64"):
        var baked := from_data(cfg, map_data)
        baked.configure_story_gates(gates_data, flags, party)
        return baked
    var m := WorldMap.new()
    m.width = maxi(8, int(cfg.get("width", 64)))
    m.height = maxi(8, int(cfg.get("height", 48)))
    m.seed_value = int(cfg.get("seed", 1))
    m.places = (cfg.get("places", []) as Array).duplicate(true)
    m.tiles.resize(m.width * m.height)
    for y in range(m.height):
        for x in range(m.width):
            var e: float = noise(x, y, 10.0, m.seed_value) * 0.65 + noise(x, y, 5.0, m.seed_value + 7) * 0.35
            var wet: float = noise(x, y, 9.0, m.seed_value + 31) * 0.7 + noise(x, y, 4.0, m.seed_value + 53) * 0.3
            var t: int = GRASS
            if x == 0 or y == 0 or x == m.width - 1 or y == m.height - 1:
                t = MOUNTAIN                         # the map edge is a wall of peaks
            elif e < 0.30:
                t = WATER
            elif e < 0.34:
                t = FORD
            elif e > 0.80:
                t = MOUNTAIN
            elif e > 0.68:
                t = HILL
            elif wet > 0.58:
                t = FOREST
            m.tiles[y * m.width + x] = t
    # clear a small meadow around every place, then lay the roads
    for p in m.places:
        var c: Vector2i = m.place_cell(str((p as Dictionary).get("id", "")))
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                var cc := Vector2i(c.x + dx, c.y + dy)
                if not m.in_bounds(cc):
                    continue
                if m.terrain_at(cc) != MOUNTAIN or (absi(dx) <= 1 and absi(dy) <= 1):
                    m._set(cc, GRASS)
    for r in (cfg.get("roads", []) as Array):
        var pair: Array = r
        m._carve_road(m.place_cell(str(pair[0])), m.place_cell(str(pair[1])))
    for p in m.places:
        m._set(m.place_cell(str((p as Dictionary).get("id", ""))), ROAD)
    m.start_cell = m.place_cell(str(cfg.get("start", "")))
    m.configure_story_gates(gates_data, flags, party)
    return m


## Decodes the baked world: two base64 byte layers (terrain, region), width x height each.
static func from_data(cfg: Dictionary, map_data: Dictionary) -> WorldMap:
    var m := WorldMap.new()
    m.width = int(map_data.get("width", 0))
    m.height = int(map_data.get("height", 0))
    m.seed_value = int(cfg.get("seed", 1))
    m.places = (cfg.get("places", []) as Array).duplicate(true)
    m.region_defs = (cfg.get("regions", []) as Array).duplicate(true)
    m.tiles = Marshalls.base64_to_raw(str(map_data.get("tiles_b64", "")))
    m.regions = Marshalls.base64_to_raw(str(map_data.get("regions_b64", "")))
    if m.tiles.size() != m.width * m.height:
        push_error("WorldMap: the terrain layer has %d bytes, expected %d" % [m.tiles.size(), m.width * m.height])
        m.tiles.resize(maxi(0, m.width * m.height))
    if m.regions.size() != m.tiles.size():
        m.regions.resize(m.tiles.size())
    m.start_cell = m.place_cell(str(cfg.get("start", "")))
    return m


## Install the story overlay without modifying the baked source data. Closed boundary cells are mountains;
## a gate restores its original road/bridge terrain only while its requirements are met.
func configure_story_gates(data: Dictionary, flags: Dictionary = {}, party: Variant = null) -> void:
    gate_definitions = data.duplicate(true)
    world_flags = flags.duplicate(true)
    story_party = party
    if _base_tiles.is_empty():
        _base_tiles = tiles.duplicate()
    _gate_cells.clear()
    _gate_cell_originals.clear()
    var band_cells: Dictionary = {}
    for run_value in gate_definitions.get("bands", []):
        if typeof(run_value) != TYPE_ARRAY or (run_value as Array).size() < 3:
            continue
        var run: Array = run_value
        for x in range(int(run[1]), int(run[2]) + 1):
            var cell := Vector2i(x, int(run[0]))
            if in_bounds(cell):
                band_cells[cell] = true
    for gate_value in gate_definitions.get("gates", []):
        if typeof(gate_value) != TYPE_DICTIONARY:
            continue
        var gate: Dictionary = gate_value
        var gate_id := str(gate.get("id", ""))
        for cell_value in gate.get("cells", []):
            if typeof(cell_value) != TYPE_ARRAY or (cell_value as Array).size() < 2:
                continue
            var pair: Array = cell_value
            var cell := Vector2i(int(pair[0]), int(pair[1]))
            if in_bounds(cell):
                _gate_cells[cell] = gate_id
        # The authored cells mark the pass, but a thick/irregular boundary can require a few
        # additional band cells to make a continuous road crossing. Derive the shortest corridor
        # between the two named regions from the baked region layer; no source map edits.
        for cell in _find_gate_corridor(gate, band_cells):
            _gate_cells[cell] = gate_id
    for cell_value in _gate_cells.keys():
        var cell: Vector2i = cell_value
        _gate_cell_originals[cell] = int(_base_tiles[cell.y * width + cell.x])
    _apply_story_overlay()


## Refresh after flags or party inventory/gold change. Existing save flags remain untouched.
func set_story_state(flags: Dictionary, party: Variant = null) -> void:
    world_flags = flags.duplicate(true)
    story_party = party
    _apply_story_overlay()


func _find_gate_corridor(gate: Dictionary, band_cells: Dictionary) -> Array[Vector2i]:
    var between: Array = gate.get("between", [])
    if between.size() < 2 or regions.size() != tiles.size():
        return []
    var region_a := _region_index(str(between[0]))
    var region_b := _region_index(str(between[1]))
    if region_a < 0 or region_b < 0:
        return []
    var queue: Array[Vector2i] = []
    var previous: Dictionary = {}
    var starts: Array[Vector2i] = []
    for cell_value in band_cells.keys():
        var cell: Vector2i = cell_value
        if _adjacent_to_region(cell, region_a, band_cells):
            starts.append(cell)
    starts.sort_custom(func(a: Vector2i, b: Vector2i) -> bool: return a.y * width + a.x < b.y * width + b.x)
    for cell in starts:
        queue.append(cell)
        previous[cell] = Vector2i(-1, -1)
    var head := 0
    var finish := Vector2i(-1, -1)
    while head < queue.size():
        var cell: Vector2i = queue[head]
        head += 1
        if _adjacent_to_region(cell, region_b, band_cells):
            finish = cell
            break
        for delta in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
            var next := cell + delta
            if band_cells.has(next) and not previous.has(next):
                previous[next] = cell
                queue.append(next)
    var path: Array[Vector2i] = []
    if finish.x < 0:
        return path
    var cursor := finish
    while cursor.x >= 0:
        path.append(cursor)
        cursor = previous[cursor]
    return path


func _region_index(region_id: String) -> int:
    for i in range(region_defs.size()):
        if str((region_defs[i] as Dictionary).get("id", "")) == region_id:
            return i
    return -1


func _adjacent_to_region(cell: Vector2i, region_index: int, band_cells: Dictionary) -> bool:
    for delta in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
        var neighbour := cell + delta
        if in_bounds(neighbour) and not band_cells.has(neighbour) and int(regions[neighbour.y * width + neighbour.x]) == region_index and SPEED[int(_base_tiles[neighbour.y * width + neighbour.x])] > 0.0:
            return true
    return false


func _apply_story_overlay() -> void:
    if _base_tiles.size() != tiles.size():
        return
    tiles = _base_tiles.duplicate()
    for run_value in gate_definitions.get("bands", []):
        if typeof(run_value) != TYPE_ARRAY or (run_value as Array).size() < 3:
            continue
        var run: Array = run_value
        var y := int(run[0])
        for x in range(int(run[1]), int(run[2]) + 1):
            var cell := Vector2i(x, y)
            _set(cell, MOUNTAIN)
    var story := WorldStory.new(gate_definitions)
    for cell_value in _gate_cells.keys():
        var cell: Vector2i = cell_value
        var gate_id := str(_gate_cells[cell])
        if story.gate_open(gate_id, world_flags, story_party):
            var original := int(_gate_cell_originals.get(cell, ROAD))
            _set(cell, original if SPEED[original] > 0.0 else ROAD)


func gate_at(cell: Vector2i) -> Dictionary:
    var gate_id := str(_gate_cells.get(cell, ""))
    if gate_id == "":
        return {}
    for gate_value in gate_definitions.get("gates", []):
        var gate: Dictionary = gate_value
        if str(gate.get("id", "")) == gate_id:
            return gate.duplicate(true)
    return {}


func gate_open_at(cell: Vector2i) -> bool:
    var gate := gate_at(cell)
    if gate.is_empty():
        return true
    return WorldStory.new(gate_definitions).gate_open(str(gate.get("id", "")), world_flags, story_party)


func in_bounds(c: Vector2i) -> bool:
    return c.x >= 0 and c.y >= 0 and c.x < width and c.y < height


func terrain_at(c: Vector2i) -> int:
    if not in_bounds(c):
        return MOUNTAIN
    return int(tiles[c.y * width + c.x])


func _set(c: Vector2i, t: int) -> void:
    if in_bounds(c):
        tiles[c.y * width + c.x] = t


func walkable(c: Vector2i) -> bool:
    return SPEED[terrain_at(c)] > 0.0


## Movement-facing passability name; story overlays have already replaced sealed cells with mountains.
func passable(c: Vector2i) -> bool:
    return walkable(c)


func speed_at(c: Vector2i) -> float:
    return SPEED[terrain_at(c)]


func danger_at(c: Vector2i) -> float:
    return DANGER[terrain_at(c)]


func terrain_name(c: Vector2i) -> String:
    return NAMES[terrain_at(c)]


## The region definition under cell `c` ({} on small procedural maps).
func region_at(c: Vector2i) -> Dictionary:
    if regions.is_empty() or not in_bounds(c):
        return {}
    var i: int = int(regions[c.y * width + c.x])
    if i < 0 or i >= region_defs.size():
        return {}
    return region_defs[i]


func region_id_at(c: Vector2i) -> String:
    return str(region_at(c).get("id", ""))


## Danger tier 1 (easy) to 5 (deadly) of the region under `c`; 1 when there are no regions.
func tier_at(c: Vector2i) -> int:
    return int(region_at(c).get("tier", 1))


## A rows-of-text battle map taken from the world around `center`: one world tile = one battle tile, so a fight in a
## forest is fought in a forest. Returns {"terrain": [rows], "heights": [rows], "legend": {...}}.
func battle_patch(center: Vector2i, bw: int, bh: int) -> Dictionary:
    var rows: Array = []
    var hrows: Array = []
    var x0: int = center.x - floori(float(bw) / 2.0)
    var y0: int = center.y - floori(float(bh) / 2.0)
    for y in range(bh):
        var row: String = ""
        var hrow: String = ""
        for x in range(bw):
            var t: int = terrain_at(Vector2i(x0 + x, y0 + y))
            row += BATTLE_CHAR[t]
            hrow += "1" if t == HILL else "0"
        rows.append(row)
        hrows.append(hrow)
    return {"terrain": rows, "heights": hrows, "legend": BATTLE_LEGEND.duplicate()}


func place_cell(id: String) -> Vector2i:
    for p in places:
        var d: Dictionary = p
        if str(d.get("id", "")) == id:
            var a: Array = d.get("cell", [0, 0])
            return Vector2i(int(a[0]), int(a[1]))
    return Vector2i.ZERO


func place_by_id(id: String) -> Dictionary:
    for p in places:
        if str((p as Dictionary).get("id", "")) == id:
            return p
    return {}


## Winding one-tile road from a to b. Water becomes a bridge, other blocked ground becomes road.
func _carve_road(a: Vector2i, b: Vector2i) -> void:
    var c: Vector2i = a
    var guard: int = width * height
    while c != b and guard > 0:
        guard -= 1
        var dx: int = signi(b.x - c.x)
        var dy: int = signi(b.y - c.y)
        var step_x: bool = absi(b.x - c.x) > absi(b.y - c.y)
        var wobble: float = hash01(c.x, c.y, seed_value + 99)
        if wobble < 0.22 and dx != 0 and dy != 0:
            step_x = not step_x
        if dx == 0:
            step_x = false
        elif dy == 0:
            step_x = true
        c = Vector2i(c.x + dx, c.y) if step_x else Vector2i(c.x, c.y + dy)
        var t: int = terrain_at(c)
        _set(c, BRIDGE if (t == WATER or t == FORD) else ROAD)


## True when b can be reached from a over walkable tiles (4-way). Used by the tests and by place checks.
func connected(a: Vector2i, b: Vector2i) -> bool:
    if not walkable(a) or not walkable(b):
        return false
    var seen: PackedByteArray = PackedByteArray()
    seen.resize(width * height)
    var queue: Array[Vector2i] = [a]
    seen[a.y * width + a.x] = 1
    var head: int = 0
    while head < queue.size():
        var c: Vector2i = queue[head]
        head += 1
        if c == b:
            return true
        for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
            var n: Vector2i = c + d
            if in_bounds(n) and walkable(n) and seen[n.y * width + n.x] == 0:
                seen[n.y * width + n.x] = 1
                queue.append(n)
    return false


## Compatibility name used by place progression checks. It always evaluates the current story state.
func connected_with(a: Vector2i, b: Vector2i) -> bool:
    return connected(a, b)


func walkable_fraction() -> float:
    var n: int = 0
    for i in range(tiles.size()):
        if SPEED[int(tiles[i])] > 0.0:
            n += 1
    return float(n) / float(maxi(1, tiles.size()))


## Next ambush threshold in "danger pixels" for a given random number 0..1.
static func encounter_threshold(cfg: Dictionary, r: float) -> float:
    var lo: float = float(cfg.get("encounter_min", 900))
    var hi: float = maxf(lo, float(cfg.get("encounter_max", 1800)))
    return lerpf(lo, hi, clampf(r, 0.0, 1.0))
