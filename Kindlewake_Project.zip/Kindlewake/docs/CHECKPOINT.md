# Checkpoint

- **Status:** WORK IN PROGRESS (resume with the steps below)
- **Game version:** 0.9.5
- **Made:** 2026-11-08 09:51 UTC
- **Static check:** files: 34   classes: 34   errors: 0   warnings: 0
- **JSON data:** 24 files, all valid
- **Room transition source check:** room transition source check: shader contract and 8 RoomScene wiring checks passed
- **Run in Godot:** no (nothing has been executed in the engine; import first: `godot --headless --path . --import`)

## Note from the session

v0.9.5 fast_travel complete in code and docs (not run in Godot). IMPORTANT: this zip was rebuilt from the GitHub history (v0.9.3 zip + Feature_asset_library_credits) so it does NOT contain assets/library or assets/audio (the big binaries live only in the owner's local v0.9.4 project). Do not replace the local project with it: apply Feature_fast_travel.zip onto the full local project instead.

## Work in progress (docs/WIP.md)

**Done this session (v0.9.5):** feature `fast_travel`. The Map panel has a new **Fast Travel** button that opens a Waystone panel: from inside a settlement's safe ground the party can travel to any settlement it has seen (`seen_<id>`), nearest first, for gold by distance (3 per 10 tiles, multiples of 5, 10..120, `data/travel.json`). A town behind a shut story gate shows as cut off (flood fill over the live gate-aware map), an unaffordable trip is disabled, arrival uses a short black wipe, resets the ambush counter, pays the fare and autosaves. New `scripts/world/fast_travel.gd` (`FastTravel`), `GameData.travel`, `_test_fast_travel()`, and `tools/check_fast_travel.py` (offline Python mirror of the gate overlay: shut gates reach only Sethmarch and Orrowen towns, each opened gate adds exactly its region, all 23 settlements reachable when open; mutation-tested). Also removed a duplicate `root.add_child(journal_panel)` in `world_scene.gd` that would have logged an error. No save-schema change, no new assets, no permissions. Static checker 34 files/classes, 0 errors, 0 warnings. **Not run in Godot.** Base for this pack: v0.9.4 rebuilt from the repo history (v0.9.3 zip + `Feature_asset_library_credits.zip`); binaries (`assets/library`, `assets/audio`) were not available in this session and are untouched.

**Done this session (v0.9.4):** the user supplied 19 asset packs and said the game is for private use and that the creator is Jose Basinillo Jr. Imported and credited all of them: `assets/library/` (17 sprite/tile packs, `.gdignore`), `assets/audio/music/` (11 Reeder tracks + 29 Abstraction loops as OGG q3, 37 MB), `data/audio.json` + `AudioManager.start_music(context)`, `data/credits.json` -> `CREDITS.md` via `tools/credits.py`, Home Credits button, `tools/promote_asset.py`. Not stored: the 3D Quaternius outfits and `Skeleton_Sprite_Pack.rar` (could not be opened here: ask for a ZIP). The user said more assets are still coming. Nothing here has been run in Godot.

**Next for assets:** promote the pieces the game will really use (hero and enemy battle sprites from the knight, warrior, bringer-of-death, hobbit, archer and demon packs; town tiles from the beach, houses and tilesets packs), listen to the music balance on the phone, clear licences before any public release (see `CREDITS.md`).

**Done this session (v0.9.3):** expanded Recruitment Hall candidate cards with origin, personal-quest title, compact stat preview (level/HP/STR/DEX/INT/SPD), and authored human-readable unlock-condition text. Added these fields to Hask, Edda and Joss recruitment definitions and tests for metadata completeness. Requirement evaluation, party insertion, duplicate prevention, recruited flags, autosave and save schema are unchanged. Static-only validation; Godot layout and touch review remain pending.

**Done this session (v0.9.2):** expanded named recruitment with Edda Stonehand (Wallwright, unlocked by visiting Ironford) and Joss Harrow (Cutpurse, unlocked by looting the Gilded Hind). Added full character definitions and distinct town-contact / hidden-location recruitment metadata. Both use the existing requirement-token evaluator, roster insertion, recruited flag and autosave path; no save-schema change. Added distinct 512×512 portraits for both recruits; a styled two-letter monogram remains available for future recruits without artwork. Tests and static checks are source-level only; Godot remains unavailable.

**Done this session (v0.9.1):** visual/recruitment polish. Added four original painterly portrait PNGs (Torren, Sela, Brother Wystan and Hask Gravelteeth; Bram's existing portrait retained), wired the Hask portrait through `data/recruits.json`, and rebuilt the town recruitment board as a portrait-led Recruitment Hall card with class, narrative, join quote, locked/available state and a clear Invite action. Recruitment still uses the existing story requirements, roster check, flag and autosave; no new gameplay rule or save field. Static source check only; Godot import/runtime and phone layout remain unverified.

**Done this session (v0.9.0):** added four original 512x512 character portraits (Torren, Bram, Sela, Brother Wystan) and integrated them into New Game character select and Party roster/sheet. Added data-driven named recruitment definitions in `data/recruits.json`; the Prologue victory against Hask Gravelteeth unlocks his personal recruitment lead, shown at town Recruitment leads. Inviting him adds his existing character definition to the persistent party and autosaves; no save-schema change. Static source checks pass; Godot import, UI, runtime and phone review are not run. This is a first recruitment vertical slice, not the complete 80-character system.

**Done this session (v0.8.9):** added `tools/check_room_transition.py`, a source-level regression guard that checks the radial shader contract and eight wiring points in `RoomScene` (shader resource, initial progress, material assignment, tween parameter, fallback callback, outbound wipe, destination reveal and encounter wipe). `tools/checkpoint.py` now runs and records this check and fails the checkpoint if it fails. No gameplay behavior, save schema, assets or permissions changed. The source check passes; it does not compile the shader or replace Godot import/runtime/phone review.

# Work in progress (edit this by hand; `tools/checkpoint.py` copies it into `docs/CHECKPOINT.md`)

**Done this session (v0.8.8):** feature `room_swirl_transition`: replaced the room scene's plain alpha fade with a procedural radial spiral wipe shader. The same transition path is used for room exits, site exits and dungeon encounters; existing transition callbacks, room hand-off, battle return and autosave behavior are unchanged. No external art, new save fields, network code or permissions. Static checker, JSON checks, content generators and APK offline preflight pass. Godot shader import/compilation, transition timing and phone visuals are not verified (Godot unavailable).

**Done this session (v0.8.7):** feature `watchtower_site`: the existing Sethmarch `watch` ruin now opens a two-room Old Watchtower (`lower` corridor / `crown` stairs), with Muster Roll and Signal Brazier lore spots and a one-time 65-gold lockbox. Reuses existing room renders; no new assets, save fields or network permissions. `_test_rooms()` now checks the site and overworld link. Python parity validation against RoomMap walk-grid/exit/spot rules passes for 3 sites / 11 rooms. Project, save display and Android export version metadata set to 0.8.7. Godot import, headless suite, transitions, chest persistence and phone visuals not run.

**Done this session (v0.8.6):** feature `world_map_polish`: deterministic terrain dressing (grass, forests, hills, water/ford, marsh, sand, snow), connected road/bridge paths, settlement plinths and readable label plaques. Rendering-only change; baked world, movement, gate logic, encounters and save payload remain unchanged. `python3 -I tools/gd_static_check.py` passes (33 files/classes, 0 errors/0 warnings); APK offline preflight passes. Godot import, headless suite, frame-time and phone visual review not run (Godot unavailable).

**Done this session (v0.8.5):** feature `town_buildings`: added authored data-driven settlement silhouettes for all 23 keep/city/town/village places, using existing supplied voxel sprites and region palettes; `GameData` loads the layout data and `WorldScene` renders place-specific clusters with legacy fallback; deterministic generator/checker and `_test_town_buildings()` added. Static checker: 33 files/classes, 0 errors, 0 warnings; generator check passes; all 20 JSON files valid; APK preflight passes. Godot visual review and headless suite not run.

**Done this session (v0.8.4):** feature `room_resume`: world saves optionally store current site, room and hero cell; Home Continue/Load and world Load resume valid saved rooms; room entry/transition, chest loot, boss start and app pause autosave; leaving a site clears the room marker. Older saves without `world.room` remain compatible. Added save-envelope coverage. Static checker and APK preflight pass; tests not run in Godot.

**Earlier (v0.8.3):** `home_screen` steps 1-4 complete. Step 4 removes the legacy world boot overlay and duplicate Continue/New Game flow; Home is the sole entry point, world pause autosaves without the obsolete boot flag, and navigation regression tests cover the configured entry scene and overlay removal. Previous steps provide Home Continue/New Game, manual/autosave slot picker, persistent offline settings and generated placeholder audio. Static checker and JSON checks recorded in checkpoint. Tests added but not run in Godot.

**Earlier feature baseline (v0.7.9):** `story_gates` steps 1-5 are implemented and packaged. The feature includes generated sealed-boundary overlay data (927 runs, seven gates), `WorldStory` requirements/quest/journal logic, `WorldMap` passability corridors, world-scene closed-gate markers and bump hints, three place actions (oath, 150-gold toll, pilgrim seal), autosave after successful actions, and a Journal overlay. Final documentation, checkpoint and merge-ready `Feature_story_gates.zip` are prepared. Static checker: 28 files/classes, 0 errors, 0 warnings. Gate generator check passes. All 19 JSON data files validate. **Not run in Godot**; visual layout, touch interaction, import and headless tests remain unverified.

## Next (in this order)
1. **Engine review when available:** import with `godot --headless --path . --import`, run `godot --headless --path . --script res://tests/run_tests.gd`, then inspect Home and World on a phone. Verify Home Continue/Load/New Game, the four portraits in character select and Party UI, Hask's `battle_01` unlock → town Recruitment leads → invite → save/load flow, world-menu Save/Load/Settings, audio sliders, gate markers/hints/actions/corridors, autosave and Journal layout. Fix engine errors before claiming runtime verification.
2. **Room review:** test Home Continue/Load and world Load resume the correct room and cell; verify chest persistence, the existing keep/barrow rooms and the new Old Watchtower transitions, then review the world map and room scenes on a phone.
3. **Recruitment expansion:** add more named characters with distinct encounter methods (rumour trail, personal quest, duel series, rescue, political favour), reputation thresholds and authored portraits. Keep each recruit as a small end-to-end story slice; do not create a generic filler roster.
4. **Next content pack:** add further explorable sites or medieval interiors only after checking the relevant voxel-pack licences and confirming assets are available; then transports (horse) and fog-of-war as separate packs (fast travel is done in v0.9.5).
5. **Fast-travel review (v0.9.5):** in Godot open Map -> Fast Travel inside a town and in the wild; check the list layout at phone size, disabled-button reasons, the wipe timing, that gold is charged once, that the arrival tile shows the "Enter" prompt and that an autosave exists afterwards. Run `python3 -I tools/check_fast_travel.py` after any change to `data/travel.json`, `world_gates.json` or the world map. Then tune the price and the safe-ground departure rule in `data/travel.json`.

## Known risks
- Fast travel (v0.9.5) is untested in Godot: Tween callbacks with `Callable.bind`, `modulate:a` tweening, the 78 px destination buttons inside a ScrollContainer, and the flood fill speed on a phone (about 150k tiles, one pass per open or tap) are unverified. If the flood is slow, cache its result per gate state.
- The v0.9.4 binaries (`assets/library`, `assets/audio`) are not in the GitHub repo and are above the 30 MB chat-upload limit: send a slim zip (without `assets/library`) or connect the repo; the v0.9.5 pack never touches them.
- Town-building compositions, v0.8.6 world-map polish, v0.8.7 Old Watchtower rooms and v0.8.8 swirl transitions have not been viewed in Godot; inspect overlaps, label clearance, road junctions and mobile scaling before release.
- Room resume has not been exercised in Godot; confirm the app-pause signal fires on Android and that Home/world load route to the expected site and cell.
- Story-gate boundary placement, road continuity, gate markers, place-action reachability and Journal touch layout still need visual/in-engine validation.
- Party screen, world scene, room scenes, battles and sprites have never been run in Godot.
- Godot executable is not present in this environment; no engine import or headless test run was possible.
- Voxel pack licences remain unverified (`docs/ASSETS.md`).
- Keep feature branches separate; port features as packs, never hand-mix the older v0.7.3 town-interiors branch.

## Features merged so far (docs/FEATURES.json)

- party_ui (0.7.1)
- character_select (0.7.2)
- hero_battle_sprites (0.7.3)
- pre_rendered_rooms (0.7.4)
- watchtower_site (1)
- recruitment_hall_portraits (1)
- asset_library_credits (0.9.4)

## How to resume in a new chat

1. Attach `Kindlewake_Project.zip`, `GDD_Kindlewake.md` and `CONTINUATION_PROMPT.md`; paste the prompt.
2. Unzip, read `docs/CHECKPOINT.md` (this file), `docs/WIP.md` and `docs/SESSION_HANDOFF.md`.
3. Run `python3 -I tools/gd_static_check.py` and finish whatever is listed as in progress.
4. Features built in a separate chat arrive as `Feature_<id>.zip`: `python3 -I tools/merge_features.py apply Feature_<id>.zip` (dry run first).
