# Session Handoff — KINDLEWAKE: THE SUNDERED VOW (state: v0.5.1 = v0.5.0 + Android APK packaging pipeline)

## Where we are
- Milestone 1 ("playable tactical combat prototype") has been rebuilt from the single-file prototype into a modular, data-driven project. **The code has never been run in Godot** (no Godot binary was available while writing it). Treat everything as "written carefully, untested" until the test-suite and a manual playthrough pass.
- The Game Design Document (all 17 requested sections) is complete: `docs/GDD.md`.
- Previous prototype (single `scripts/main.gd`, Manhattan movement, adjacent melee only) was replaced; nothing from it is still needed.

## v0.5.1 (this session): Android installer (APK) pipeline
**User request:** "make sure there will be an installer of this game for apk". **Honest status:** the sandbox had no Godot and no internet, so **no APK was built or executed**. What exists is a complete build pipeline, checked offline only (preflight mutation tests; the whole download/extract/import/test/export/verify flow was simulated with fake archives and a fake Godot on Linux; Windows-specific branches such as `.bat` quoting were NOT exercised). Game code and save format are unchanged (`GAME_VERSION` stays 0.5.0; `gd_static_check.py` still 0 errors, 0 warnings).

| File | What |
|---|---|
| `export_presets.cfg` | Preset `Android`: export templates (no Gradle), arm64-v8a + armeabi-v7a, `package/unique_name=com.kindlewake.game`, `version/name 0.5.1`, `version/code 501`, signed, `permissions/internet=false`, `include_filter="*.json"` (data must be packed), `exclude_filter` drops tests/tools/docs/.github/markdown/keys, immersive mode, launcher icons. |
| `project.godot` | Added `config/icon`, `config/version`, `rendering/textures/vram_compression/import_etc2_astc=true` (Godot refuses Android exports without it), orientation 0 -> 4 (landscape on either side). |
| `assets/icons/*` | `icon.png` 512, `icon_main_192.png`, `icon_fg_432.png`, `icon_bg_432.png` (placeholder art: sword with an ember flame). Generator: `tools/make_icon.py` (needs Pillow). |
| `tools/keys/kindlewake-sideload.keystore` | Committed sideload signing key (alias `kindlewake`, password `kindlewake-sideload`, PKCS12, 100 years). Public on purpose, same key for every build so updates install over old ones. NOT for Google Play. Overrides: env `KINDLEWAKE_KEYSTORE`, `KINDLEWAKE_KEY_ALIAS`, `KINDLEWAKE_KEY_PASS`. |
| `tools/build_apk.py` | Cross-platform (Windows/Linux, stdlib only). Steps: preflight (offline) -> download and cache JDK 17 (Temurin), Android cmdline-tools rev 11076708 + platform-tools, build-tools 34.0.0, android-34, Godot 4.2.2 + export templates (only `android_*` files extracted) in `~/.kindlewake_build` (or `KINDLEWAKE_CACHE`; Windows paths with spaces fall back to `C:\kw_build`) -> Godot "self-contained mode" (`_sc_` file, settings in `editor_data/`) with a generated `editor_settings-4.tres` (+ versioned name) -> `--headless --import` (retried once) -> `tests/run_tests.gd` (logged, non-blocking unless `--strict`; `--with-balance` adds the balance report) -> `--export-release Android dist/Kindlewake.apk` (signing via `GODOT_ANDROID_KEYSTORE_*` env vars) -> verify (zip integrity, arm64 library, `aapt2 dump permissions`: **fails if INTERNET is present**, `apksigner verify`). Flags: `--check`, `--skip-tests`, `--strict`, `--with-balance`, `--debug`, `--install` (adb), `--godot VER`, `--cache DIR`, `--allow-internet`. Logs in `dist/logs/`, short report `dist/logs/BUILD_SUMMARY.txt`. |
| `Build_APK.bat`, `tools/build_apk.sh` | Double-click / shell wrappers. |
| `.github/workflows/build-apk.yml` | GitHub Actions: manual run or `v*` tag; caches `~/.kindlewake_build`; uploads `Kindlewake-APK` and `test-logs`; tag builds attach the APK to the release. |
| `docs/BUILD_APK.md` | Plain-English guide: three ways to build, install on the phone, signing notes, troubleshooting table. |
| `docs/GDD.md` | New section 15.1, roadmap row 10, folder tree, revision log 0.5.1. |

**Preflight rules (`python tools/build_apk.py --check`):** preset exists and is Android, no Gradle, valid package name, arm64 on, version code/name, `*.json` in include_filter, no `permissions/internet`, icon files exist with exact sizes, `import_etc2_astc=true`, `config/icon` exists, landscape orientation, signing key exists, every `data/**/*.json` parses, and no network class (`HTTPRequest`, `WebSocketPeer`, `StreamPeerTCP`, `ENet*`, `OS.shell_open`...) appears in `scripts/`. Mutation-tested (11 injected faults, all caught).

**Likely first-run problems (all unverified):** (1) download URLs (Adoptium API, `dl.google.com` cmdline-tools 11076708, GitHub release assets `4.2.2-stable`); (2) Godot's Android export check may want something not installed (read `dist/logs/export.txt`); (3) editor settings file name/location in self-contained mode; (4) `sdkmanager` licence prompts on Windows (the script feeds `y` to stdin and quotes `build-tools;34.0.0` because cmd.exe splits at `;`); (5) a data file not packed (the game would crash at start, check `adb logcat -s godot`); (6) touch layout on a real phone is still unchecked (see v0.5.0 gaps).

**Decisions:** Godot pinned to 4.2.2 (the declared target); a newer Godot is available through `--godot` for 16 KB page-size phones (build-tools 35.0.1 / android-35 are used from 4.4 on; best effort). Release build, not debug (a release export never adds INTERNET). Template-based export, no Gradle, so no NDK/CMake download. APK name fixed `Kindlewake.apk`; no `.aab` yet (Milestone 10). iOS is untouched.

## v0.5.0: party screen, shop, pre-battle panel, static checker, balance report
**Verification status (honest):** this sandbox again had no Godot and no package installs, so NOTHING was executed in Godot. What was done instead:
- New `tools/gd_static_check.py` (pure Python, run `python3 -I tools/gd_static_check.py` from the project folder). It checks indentation, brackets, duplicate members, local variables that redeclare an enclosing scope (a Godot parse error), calls to missing methods / wrong argument counts / missing members and signals on every project class (following typed variables, typed members and return types), undeclared identifiers, probable `:=`-on-Variant mistakes, `connect()` handlers, `load()`/autoload paths and every JSON cross-reference. It was mutation-tested (5 injected bugs, all caught) and reports **0 errors, 0 warnings** on the whole project. It is a linter, not a substitute for Godot: it cannot see engine-API mistakes, runtime type errors or logic bugs.
- Typed-array return values and typed-array assignments were hand-audited (all build typed arrays).
- **Important first-run detail:** `class_name` scripts are only registered after Godot has scanned the project, so a fresh unzip must be imported ONCE before the tests: `godot --headless --path . --import` (or open the project in the editor once). Without it the tests fail with "Could not find type X" / "Identifier not declared" errors for every class_name. Then run `godot --headless --path . --script res://tests/run_tests.gd`. **Any `SCRIPT ERROR` / `Parse Error` line in the output matters even if the checks still say ok** (a runtime error inside a function prints an error and returns, it does not fail a check).
- Autoload scripts (`GameData`, `SaveSystem`, `GameState`) are still instantiated by hand in tests; `GameState.skirmish_def` logic moved to the new static `EncounterBuilder` so no test needs `GameState` any more.

**New / changed files**
| File | What |
|---|---|
| `scripts/ui/party_screen.gd` (`PartyScreen`, a Control built in code) | Full-screen party UI: roster column, character sheet (HP/MP, ATK/DEF/RES/ACC/EVA/CRIT/SPD/MOV/range, 10 stats with gear bonus, skills with power %, EXP bar, promotion buttons) and a right panel with 3 tabs: **Equipment** (6 slots; tap a slot to list matching bag items with a live stat delta such as "ATK +3, DEF +1"; blocked items show the reason; Unequip), **Sigils** (weapon/armor sockets as buttons "Embers Lv2 / 35/70 AP", linked sockets joined by "=", header shows socket count and AP multiplier; tap a socket for its sigil detail, level/AP to next/effect, linked Tutor bonus, Remove, or pick a sigil from the bag), **Shop** (Buy/Sell toggle, prices, item/sigil detail lines, sell ratio). It reads no autoloads: `setup(party, db, shop)` then `open()`; signal `closed`; `builds` counts complete layout builds (tests use it to detect half-built screens). Every action calls PartyState/CharacterSheet/ShopSystem and then rebuilds; scroll position is kept. |
| `scripts/core/shop_system.gd` (`ShopSystem`, static) | `stock`, `buy_item`, `buy_sigil`, `sell_item`, `sell_sigil`, `sell_price` (flat `sell_ratio` of the price, 0.5), `for_sale`. Returns "" on success or a reason ("Not enough gold.", "Not for sale.", "That cannot be sold." for heirlooms/bound items). Only bag items can be sold. |
| `scripts/core/item_info.gd` (`ItemInfo`, static) | Text helpers: `item_line`, `skill_line`, `sigil_effect`, `sigil_progress`, `sigil_ap_text`, `sigil_short`, `bonus_text`, `mods_text`, `delta_text(before, after)`, `signed`, names for stats and slots. |
| `scripts/core/encounter_builder.gd` (`EncounterBuilder`, static) | `build_group(encounters, battles, index)`, `build_skirmish(...)` (weighted pick), `group_count`. Moved out of `GameState`. |
| `scripts/core/character_sheet.gd` | New `with_item(slot, item_id, items)` returns a throw-away copy wearing that item (used for the stat-delta preview). |
| `scripts/core/game_data.gd` | Loads `data/shop.json` into `shop`; new `party_db()` (classes, weapons, items, sigils, skills). |
| `scripts/ui/battle_scene.gd` | **Pre-battle panel** (`prep_panel`): every battle now starts paused with the briefing, gold, **Begin Battle** and **Party, Gear and Shop**. Closing the party screen rebuilds the battle from the new gear (`_on_party_closed` -> `_start_battle`). Results screen got a **Party, Gear and Shop** button. Load is allowed during the pre-battle panel. New vars `prep_*`, `party_screen`, `prep_active`; new funcs `_show_prep`, `_on_begin_pressed`, `_on_party_pressed`, `_on_party_closed`. |
| `data/shop.json` | "Sethorn Market Stall": 19 items, 11 sigils, `sell_ratio` 0.5. |
| `data/sigils.json`, `data/skills.json` | New **Sigil of Frost** (350 g, AP 70/220/520: Frost Shard at Lv1, Frost Lance at Lv3) and two `damage` skills: Frost Shard (power 6, 3 MP, range 2-5), Frost Lance (power 11, 7 MP, range 2-5). |
| `scripts/core/save_system.gd` | `GAME_VERSION` 0.5.0 (save format unchanged; v0.4.0 saves still load). |
| `tests/run_tests.gd` | New `_test_shop_and_screen()` (shop data, Frost sigil, text helpers, buy/sell rules incl. heirloom/equipped/not-in-bag/not-enough-gold, `with_item` preview, and a headless smoke test that builds `PartyScreen` for every roster member x every tab, equips/unequips/sockets/buys/sells through its handlers and checks `builds`, state and messages). Skirmish tests now call `EncounterBuilder`. |
| `tests/balance_report.gd` | `godot --headless --path . --script res://tests/balance_report.gd [-- N]`: AI-vs-AI table per enemy group (win %, turns, survivors, HP lost %, EXP/AP/gold per victory, verdict easy/fair/hard/brutal) plus a 60-battle grind curve with one persistent party (levels, gold, bag sigils every 5 battles). Paste its output into the next chat to tune `HP_GAIN`, enemy rewards and item/sigil prices. |

**Known gaps after v0.5.0:** nothing has run in Godot; the party screen is untested on a real touch device (button sizes 52-84 px at 1280x720 base, fonts 15-30; check on a phone and adjust; the right-panel width is ~570 px so four sockets wrap into two rows); no class/weapon-type restrictions; no blacksmith upgrades; sigil sell price is flat (not level-based); shop stock is a fixed list (no chapter gating); no HQ screen yet, so the party screen is reachable only from the pre-battle panel and the results screen; still missing from Milestone 2: remaining classes as data, skills v1 per tier-1 class, status effects, fatigue, counter-attacks, forest concealment, weather, enemy tables for more maps.

## Files and responsibilities (Milestone 1 core; see the v0.5.0 table above for newer files)
| File | Role |
|---|---|
| `scripts/core/game_data.gd` | Autoload `GameData`: loads all JSON in `data/`; `as_db()` gives one dictionary for the battle code |
| `scripts/core/save_system.gd` | Autoload `SaveSystem`: slots, atomic write, SHA-256 checksum over a payload *string*, `.bak` fallback, version + `migrate()` |
| `scripts/battle/battle_map.gd` | Grid, terrain, heights, Dijkstra reach and paths, line of sight, facing helpers |
| `scripts/battle/battle_unit.gd` | Combatant data, `create()` from character+class defs, `to_dict`/`from_dict` |
| `scripts/battle/combat_calc.gd` | ALL formulas (attack power, defense, hit, crit, facing, flank, height, morale, heal) |
| `scripts/battle/turn_queue.gd` | Charge-Time order, timeline prediction |
| `scripts/battle/battle_ai.gd` | Scoring AI (team-agnostic; `run_ai_turn(true)` lets it play the player side for sims) |
| `scripts/battle/battle_controller.gd` | Rules, state machine, signals, victory/defeat, save/restore |
| `scripts/ui/battle_scene.gd` | Isometric drawing, gestures, HUD built in code |
| `tests/run_tests.gd` | Headless checks + 30-battle AI-vs-AI simulation |
| `scripts/core/character_sheet.gd`, `party_state.gd`, `game_state.gd` | Persistent heroes, party/inventory/sigil bag/gold, runtime state (v0.3.0-0.4.0) |

## v0.4.0: renaming + FF7-style grinding (untested in Godot, like everything since v0.2)
- **Rename:** world, houses, heroes, enemies, class display names and item display names changed (GDD Appendix B). IDs of the hero/enemy characters changed too (`torren`, `bram`, `sela`, `brother_wystan`, `hask_gravelteeth`, `roadreaver`, `roadbowman`; house ids `dunmarrow`, `orrowen`, `tarnholt`...). Class ids and weapon/item ids are unchanged. Save files from v0.3.0 are NOT compatible (old character ids).
- **New data:** `data/sigils.json` (10 sigils), `data/encounters.json` (Skirmish groups), `skills.json` +4 skills (mend_ii, mend_iii, ember_bolt, ember_storm; type `damage` is new), `items.json` weapons/armor have `sockets`, `links`, `ap_mult`, enemies in `characters.json` have `reward {exp, ap, gold}`, `campaign_start.json` has `sigils` (5 in the bag), heroes got MP (Torren 8, Bram 6, Sela 8) and MP growth for swordsman/knight/archer.
- **CharacterSheet:** `sigils` per group (weapon/armor), `fit_sockets`, `active_sigils`, `award_ap` (returns reports, `spawn` flag once on mastery), `all_skills`, `skill_mods`, `sigil_mods`, `reward_pct`; `total_stats(items, sdefs)`; `to_battle_def` now adds sigil skills, `skill_mods`, `reward`.
- **PartyState:** `sigil_inv`, `equip_sigil`/`unequip_sigil`, sockets refit on weapon/armor change (`unequip(char, slot, db)` has a new optional db), **new reward rules** `battle_rewards()` / `apply_battle_result(units, result, rng, db)` which now returns a Dictionary (`reports`, `gold`, `spawned`, ...). `battle_exp()` was removed.
- **Battle:** `BattleUnit.reward`, `skill_mods`; `CombatCalc.enemy_reward`, `skill_preview`, `skill_resolve`, `skill_power_mult`, `heal_amount(caster, skill, skill_id)`; `BattleController.skill_targets` handles `target: "enemy"`, `try_skill` handles `damage` (`_cast_damage`, signal kind `skill_damage`); `BattleAI._best_bolt`.
- **Core/UI:** `GameData.sigils/encounters/rules_db()`; `GameState.award_battle` returns the rewards dictionary, `skirmish_def()` + static `build_skirmish()`; `battle_scene.gd`: results screen shows FF7-style totals, per-hero EXP/AP, sigil level-ups, mastery copies; buttons "Skirmish (grind...)" and "Story Battle"; saves include `battle_def` so a skirmish can be loaded; ember skill preview and damage popup.
- **Tests:** `_test_progression()` battle-reward checks rewritten; new `_test_sigils()` (data integrity, levels, equip, links, Tutor/Resonance, stat sigils, greatsword sockets and AP x2, socket loss, mastery spawn, damage skill, AI, skirmish builder, AI-vs-AI skirmish). Only a static JSON cross-reference check has been run (it passes); the GDScript has never been executed.
- **Known gaps:** no sigil/equipment screen (cannot change sigils in the game yet), no shop, no limit-breaks, no summon/command sigils, no party-wide AP for bench, skirmish uses the one story map, balance untuned (grind pacing: about 62 EXP and 44 AP per hero per Prologue fight).

## v0.3.0: Milestone 2, step 1 (untested in Godot, like everything since v0.2)
- New data: `items.json` (21 items), `campaign_start.json`; `weapons.json` +3 weapons (fine_arming_sword, hardwood_bow, greatsword); `classes.json` cleric now grows MP; `characters.json` party heroes carry an `equipment` block (their armor totals equal the old numbers; a test guards it).
- `scripts/core/character_sheet.gd` (`CharacterSheet`): equipment-derived weapon/armor/stats, `derived(db)` via CombatCalc/BattleUnit, `equip_problem()`, `add_exp()` with growth rolls, `promotion_options()`/`promote()`, to/from dict.
- `scripts/core/party_state.gd` (`PartyState`): roster, inventory, gold, `equip`/`unequip`, `battle_db()` (swaps sheet-derived character defs into the battle db), `battle_exp()`/`apply_battle_result()`, to/from dict.
- `scripts/core/game_state.gd` (autoload `GameState`, registered after GameData in `project.godot`): owns the party and an RNG; `battle_db()`, `award_battle()`.
- `GameData.as_db()` now resolves every character through a sheet (so gear is folded in); `GameData.items`, `GameData.start`.
- `BattleUnit.kills/kill_exp` (saved), `CombatCalc.kill_exp()`, credited in `BattleController.try_attack`.
- `battle_scene.gd`: battles use `GameState.battle_db()`; results screen pays EXP once (`exp_awarded`) and prints one line per character with level-ups; saves include `party`; load restores it; info panel shows EXP. Restart Battle keeps the party's EXP (sandbox behaviour).
- `tests/run_tests.gd`: new `_test_progression()` (data integrity, v0.2-number regression guard, equip rules, EXP/levels, determinism, promotion, battle EXP, kill-EXP credit, JSON round trip).
- Known gaps: no equipment/character-sheet UI yet (equipping is only reachable from code/tests); no class/weapon-type restrictions; `HP_GAIN` and EXP values are untuned; only 5 classes exist so most promotion targets are filtered out.

## Patch v0.2.1: Auto Battle toggle (also untested in Godot)
- `battle_scene.gd`: `auto_battle` flag, toggle button under Save/Load, `_ai_controls(unit)` decides who the AI plays, `_maybe_run_ai()` loop now also runs player units when Auto is on, `_on_auto_toggled()`, settings in `user://settings.cfg` (`[battle] auto_battle`). While Auto runs `ai_busy` stays true, so manual buttons, taps, Save and Load are disabled. Switching Auto off hands control back at the next unit (`resync_view`).
- `battle_ai.gd`: `decide()` now returns `action = "skill"` (+ `skill_id`) when a unit with a heal skill can reach an ally at <= 50% HP (`_best_heal`). It also respects part-played turns (no second move after `has_moved`, nothing after `has_acted`).
- `battle_controller.gd`: `run_ai_turn()` executes the "skill" action via `try_skill`.
- `tests/run_tests.gd`: new `_test_auto_battle()` (heal planning, MP spent, part-played turn, no-force guard).
- Known gaps: the AI still has no buff/debuff logic; the existing "autosave at the start of a player turn" is skipped while the enemy loop is running (`ai_busy`), same as before; Auto does not stop at battle end (it stays on for a restarted battle).

## Key decisions (keep unless there is a strong reason)
- Godot 4.2+, GDScript, GL Compatibility, landscape 1280x720 base, stretch `canvas_items` + aspect `expand`.
- Isometric 2:1 tiles (64x32), height step 16 px. Facing = 4 grid directions (0=N(0,-1), 1=E, 2=S, 3=W).
- Turn order: Charge-Time (not player/enemy phases). Delay = 1000/SPD x (1.0 acted, 0.75 moved only, 0.5 waited).
- Damage = raw^2/(raw+def) with multipliers (see GDD 3.5). All formulas stay in `CombatCalc`.
- Saves: payload stored as a JSON string inside the envelope (stable checksum). 64-bit RNG values saved as strings.
- Autoload scripts have NO `class_name` (it would clash with the autoload name). Tests instantiate them with `load(...).new()`.
- Use spaces (4) for indentation in all GDScript files. Never mix tabs and spaces.
- Original IP only (Eldrimar, House Dunmarrow, Kaer Sethorn, the Covenant of the Seven Flames).

## Known limitations / risks of Milestone 1
1. Never executed: expect a few GDScript typing/parse errors on first run (the static checker removes the common classes of error but not all). Import the project once, then run `tests/run_tests.gd`.
2. Placeholder shape art only; no sprites, animation, audio.
3. Not implemented yet: counter-attacks, fatigue, status effects, weather, forest concealment, skills beyond Mend, equipment and leveling.
4. Pinch-zoom and touch targets are untested on a real device. HUD uses anchors; check on a 20:9 phone.
5. Load = newest of slot 1 / autosaves; there is no slot picker UI yet (Milestone 9).
6. AI has no healing/support logic and approaches the nearest enemy by straight distance before pathing.
7. Balance is unverified; sample matchups kill in 2-4 hits (see simulator output once the tests have run).
8. Dead units are simply hidden; no death animation.

## Next tasks, in order
0. **Build and install the APK first** (it also runs the tests for you): `Build_APK.bat` (Windows) or the GitHub workflow; if it fails, paste the console text or `dist/logs/BUILD_SUMMARY.txt`, and fix the root cause in `tools/build_apk.py` / `export_presets.cfg` (re-run `python tools/build_apk.py --check` and `python3 -I tools/gd_static_check.py` after edits). Then test the APK on a real phone: touch target sizes, party screen layout, save/load, app switching (autosave on pause), the Back button, immersive mode.
1. **Verify.** `godot --headless --path . --import` once, then `godot --headless --path . --script res://tests/run_tests.gd`, then play the battle in the editor (pre-battle panel, Party screen tabs, Skirmish, sigil level-ups on the results screen). Optionally run `tests/balance_report.gd`. If the user pastes errors/output, interpret every line (including SCRIPT ERROR lines that do not fail a check), fix root causes first, and re-run `python3 -I tools/gd_static_check.py` after every edit.
2. **Milestone 2** — stats, classes, leveling, equipment (step 1 DONE in v0.3.0: items, slots, sheets, EXP, promotion, party; equipment + sigil + character-sheet screen and shop DONE in v0.5.0 (unrun); REMAINING: remaining classes as data, skills v1 (3-5 per tier-1 class), status effects, fatigue, counter-attacks, forest concealment, weather, balance report from the simulator; keep Auto Battle/AI working with each):
   - `data/items.json` + equipment slots (weapon, off-hand, armor, helm, accessory x2); rarity tiers.
   - Character sheet resource separate from `BattleUnit`; derived stats; EXP = 80+20*level; growth rolls; promotion rules (GDD 4.2).
   - Remaining classes from the master spec as data; skills v1 (3-5 per first-tier class); status effects, fatigue, counter-attacks, forest concealment, weather.
   - `GameState` autoload for the persistent party; results screen with EXP and level-ups; basic equipment screen.
   - Extend the simulator into a balance report (win rate, average turns, damage per class).
3. Milestones 3-10 per GDD section 16.

## Per-milestone deliverables (from the master prompt)
Design specs, complete implementation code (never pseudocode), folder structure, required assets, scene architecture, data structures, testing instructions, expected results, known limitations.

## Session rule
Reserve the last ~15% of capacity: update this file, README, create the zip, write `CONTINUATION_PROMPT.md`, and present both with `present_files`.
**Always deliver (every change, however small):** updated `docs/GDD.md` (version bump + revision-log line) and updated `docs/CONTINUATION_PROMPT.md`, inside the zip and as separate downloads (`GDD_Kindlewake.md`, `CONTINUATION_PROMPT.md`).
