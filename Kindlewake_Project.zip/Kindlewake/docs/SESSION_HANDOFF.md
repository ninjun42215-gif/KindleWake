# Session Handoff — KINDLEWAKE: THE SUNDERED VOW (current state: v0.9.3; Recruitment Hall profile cards expanded, Godot review pending)

**Read `docs/CHECKPOINT.md` and `docs/WIP.md` first.** The latest update adds origin, personal-quest, combat-stat and readable unlock-condition details to the three named recruit cards. It is presentation-only; recruitment rules and saves are unchanged.

## v0.9.3: Recruitment Hall profile cards
- `data/recruits.json` now supplies origin, personal quest and readable requirement copy for Hask, Edda and Joss.
- `WorldScene._recruit_card()` displays origin, story/rumour, a compact stat line sourced from `characters.json`, personal quest, and the human-readable condition while locked.
- Added metadata completeness checks. No new save fields or recruitment rule changes.
- Godot is unavailable: import, runtime, scroll sizing, portrait framing and touch review remain unverified.

## Resume order
1. Run static and JSON checks; review `docs/WIP.md`.
2. When Godot 4.2+ is available, import and run `tests/run_tests.gd`; inspect Recruitment Hall at phone aspect ratios, especially long stories and card scrolling.
3. Continue with one authored recruit story at a time (rumour trail, duel or rescue), not generic filler.
4. Review room transitions, save/load and world map in-engine before release.
5. Do not add voxel assets until licence status in `docs/ASSETS.md` is resolved. Preserve offline-only operation and no INTERNET permission.
