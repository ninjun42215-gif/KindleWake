# Session Handoff — KINDLEWAKE: THE SUNDERED VOW (current state: v0.9.5 waystone fast travel; v0.9.4 asset library, music and credits; v0.9.3: Recruitment Hall profile cards expanded, Godot review pending)

**Read `docs/CHECKPOINT.md` and `docs/WIP.md` first.** The latest update adds origin, personal-quest, combat-stat and readable unlock-condition details to the three named recruit cards. It is presentation-only; recruitment rules and saves are unchanged.

## v0.9.5: waystone fast travel
**Done this session (v0.9.5):** feature `fast_travel`. The Map panel has a new **Fast Travel** button that opens a Waystone panel: from inside a settlement's safe ground the party can travel to any settlement it has seen (`seen_<id>`), nearest first, for gold by distance (3 per 10 tiles, multiples of 5, 10..120, `data/travel.json`). A town behind a shut story gate shows as cut off (flood fill over the live gate-aware map), an unaffordable trip is disabled, arrival uses a short black wipe, resets the ambush counter, pays the fare and autosaves. New `scripts/world/fast_travel.gd` (`FastTravel`), `GameData.travel`, `_test_fast_travel()`, and `tools/check_fast_travel.py` (offline Python mirror of the gate overlay: shut gates reach only Sethmarch and Orrowen towns, each opened gate adds exactly its region, all 23 settlements reachable when open; mutation-tested). Also removed a duplicate `root.add_child(journal_panel)` in `world_scene.gd` that would have logged an error. No save-schema change, no new assets, no permissions. Static checker 34 files/classes, 0 errors, 0 warnings. **Not run in Godot.** Base for this pack: v0.9.4 rebuilt from the repo history (v0.9.3 zip + `Feature_asset_library_credits.zip`); binaries (`assets/library`, `assets/audio`) were not available in this session and are untouched.

Where to look: `docs/features/fast_travel.md` (rules, files, checks), `data/travel.json` (all numbers and texts), `scripts/world/fast_travel.gd`, the "waystone fast travel" block in `scripts/ui/world_scene.gd`, GDD 11.14. Next: review in Godot, then `transports` (horse: faster on grass and roads, blocked by forest and marsh, a mount/dismount toggle, bought at a town stable) and `map_fog` as separate feature packs; the ship idea needs real sea, which the baked world does not have.

## v0.9.4: asset library, music and credits
**Done this session (v0.9.4):** the user supplied 19 asset packs and said the game is for private use and that the creator is Jose Basinillo Jr. Imported and credited all of them: `assets/library/` (17 sprite/tile packs, `.gdignore`), `assets/audio/music/` (11 Reeder tracks + 29 Abstraction loops as OGG q3, 37 MB), `data/audio.json` + `AudioManager.start_music(context)`, `data/credits.json` -> `CREDITS.md` via `tools/credits.py`, Home Credits button, `tools/promote_asset.py`. Not stored: the 3D Quaternius outfits and `Skeleton_Sprite_Pack.rar` (could not be opened here: ask for a ZIP). The user said more assets are still coming. Nothing here has been run in Godot.

## v0.9.3: Recruitment Hall profile cards
- `data/recruits.json` now supplies origin, personal quest and readable requirement copy for Hask, Edda and Joss.
- `WorldScene._recruit_card()` displays origin, story/rumour, a compact stat line sourced from `characters.json`, personal quest, and the human-readable condition while locked.
- Added metadata completeness checks. No new save fields or recruitment rule changes.
- Godot is unavailable: import, runtime, scroll sizing, portrait framing and touch review remain unverified.

## Resume order
1. Run static and JSON checks; review `docs/WIP.md`.
2. When Godot 4.2+ is available, import and run `tests/run_tests.gd`; inspect Recruitment Hall at phone aspect ratios, especially long stories and card scrolling.
3. Continue with one authored recruit story at a time (rumour trail, duel or rescue), not generic filler.
4. Review room transitions, save/load and world map in-engine before release.
5. Do not add voxel assets until licence status in `docs/ASSETS.md` is resolved. Preserve offline-only operation and no INTERNET permission.
