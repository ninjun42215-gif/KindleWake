# Feature fast_travel: waystone fast travel (v0.9.5, IMPLEMENTED / ENGINE REVIEW REMAINS)

Asked for by the user: travelling the world map "like FF7 and Suikoden II" (Suikoden II's Blinking Mirror jumps between towns you have visited). The world is 452 x 340 tiles, so walking everywhere is slow. Built on v0.9.4. **Not run in Godot.**

## Rules (all numbers in `data/travel.json`, logic in `scripts/world/fast_travel.gd` / `FastTravel`)
* A waystone only answers while the walker stands inside the safe ground of a settlement (`origin_radius` = the world's `safe_radius`, 6 tiles). Out in the wild the panel explains why it is dark.
* Destinations are settlements (keep, city, town, village) the party has **seen** (existing flag `seen_<id>`). No new save field; old saves work at once.
* The destination must be reachable ON FOOT from the origin with the quest gates as they are now (flood fill over the live `WorldMap`, where shut gates are mountains). Waystones never skip a sealed gate: a town behind a shut gate shows "cut off" with the gate text.
* Price: `gold_per_10_tiles` (3) per 10 tiles of straight-line distance between the two settlements, rounded to a multiple of 5, clamped to `min_gold` (10) .. `max_gold` (120). The price is the same both ways. The party starts with 150 gold, so the first trips are affordable.
* Arrival: black wipe (0.25 s in, 0.45 s out), the party is placed on the settlement's own tile, the ambush counter is reset, gold is paid at the darkest moment, and the game autosaves.

## UI
* Map panel: new **Fast Travel** button next to Close. It opens the Waystone panel: intro line, gold, and one 78 px button per seen settlement (name, price, region and distance; disabled buttons show the reason). Tapping a button travels.
* While the wipe runs `_blocked()` is true, so nothing else can be tapped.

## Files (for merging)
Added: `data/travel.json`, `scripts/world/fast_travel.gd`, `tools/check_fast_travel.py`, `docs/features/fast_travel.md`.
Changed: `scripts/core/game_data.gd` (loads `travel.json`), `scripts/ui/world_scene.gd` (travel panel, Fast Travel button, wipe; also removes a duplicate `root.add_child(journal_panel)` that would have logged an error), `tests/run_tests.gd` (`_test_fast_travel`), version files, docs.

## Checks
* `python3 -I tools/check_fast_travel.py` (no Godot needed): data sanity, prices, and a Python mirror of the gate overlay proving that with all gates shut only Sethmarch and Orrowen towns are reachable, that each opened gate adds exactly the right region, and that with all gates open all 23 settlements are reachable. Mutation-tested (broken walls and a wrong radius are caught).
* `_test_fast_travel()` in `tests/run_tests.gd` checks the same rules in the engine. Not run yet.

## Not done / next
* Horse and ship (`transports`), a fog-of-war map (`map_fog`), travel by tapping a marker on the big map, a travel sound of its own (it reuses the gate chime), day/night and travel time.
* Balance: the price table and the "safe ground only" departure rule are a first guess. Tune `data/travel.json` after playing.
