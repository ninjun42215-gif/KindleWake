# Feature hero_battle_sprites: the four protagonists drawn in battle

Built on v0.7.2 (feature character_select). Written and statically checked only; **not run in Godot**.
Merging: `python3 -I tools/merge_features.py apply Feature_hero_battle_sprites.zip` (dry run), then `--apply`. Needs feature `character_select` first (it uses `HeroArt`, `HeroLooks` and the hero sheets). Only code files change; docs text on this page is pasted into the GDD and handoff by hand.

## Why
After the character select, the heroes had unique designs on the overworld and the select screen, but battles still drew grey blocks with class glyphs.

## What the player gets
Player units are drawn with their hero sprite in battle: idle loop, walk while moving, attack when they act (attack, skill damage, heal), hurt (pink flash) when they are hit, blue team ring, Bram 1.12x and Sela 0.96x. Enemies and any player unit without a sheet keep the old drawn figure. HP bar, name and ROUTED tag are shared by both (`_draw_unit_labels`).

## Files (all in the pack)
- `scripts/ui/battle_scene.gd`: `anim_clock`, `anim_override`, `ANIM_REDRAW_STEP` (14 fps redraw, battery), `_play_anim`, `_on_unit_acted` plays attack/hurt, `_draw_unit` calls `_draw_hero_sprite`, labels moved into `_draw_unit_labels`.
- `tests/run_tests.gd`: two checks on `HeroArt` (frame clamping and wrapping, timing, Soldier fallback).
- `project.godot`, `scripts/core/save_system.gd`: version 0.7.3. Docs.

## Limits
No death animation (defeated units leave the board as before), no sprites for enemies (this line has no Orc sheet; a future feature can reuse the Soldier or Orc with a red tint), no per-frame check that the idle redraw is cheap enough on low-end phones (14 fps), the whole battle screen redraws on each step. Not run in Godot.
