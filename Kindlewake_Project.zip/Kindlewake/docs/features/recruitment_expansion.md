# Recruitment expansion (v0.9.2)

## New companions

- **Edda Stonehand — Wallwright:** a Brennhallow siege-wright. Her lead appears after the party visits Ironford (`seen_ironford`); she judges the company by what it chooses to defend.
- **Joss Harrow — Cutpurse:** a Ysmark smuggler. His lead appears after the party searches the Wreck of the Gilded Hind (`looted_gilded_hind`); he offers coastal contacts and infiltration skills.

Both have complete combat definitions in `data/characters.json`, authored rumours, histories, joining lines and method metadata in `data/recruits.json`, and individual portrait assets at `assets/portraits/edda_stonehand.png` and `assets/portraits/joss_harrow.png`.

## Behavior preserved

The recruitment board evaluates existing requirement tokens, checks for duplicate party membership, inserts the existing character definition, sets `recruited_<id>` and uses the existing world autosave. No new save field, migration, network permission or online dependency is introduced.

## Art note

The two portrait candidates were adapted to the project's square portrait format and upscaled to 512×512. They are distinct character images, but should receive a final in-engine crop/lighting review alongside the other portraits.

## Verification limits

Static GDScript/data checks and the source-level recruitment tests are prepared; Godot import, headless test execution, portrait rendering, UI layout and touch review have not been run because Godot is unavailable in this environment.
