# Feature character_select: character select and unique protagonist designs

Built on v0.7.1 (Eldrimar + party_ui). Written and statically checked only; **not run in Godot**.
Merging: `python3 -I tools/merge_features.py apply Feature_character_select.zip` (dry run), then `--apply`. Eight existing files get small edits (listed below); the rest are new files. Docs text on this page is pasted into the GDD and handoff by hand.

## Why
The user asked for a character selection and design modifications: the protagonists must have unique designs (web sources allowed). All four starting heroes were the same sprite or a plain shape.

## What the player gets
- New Game (start menu) opens a **character select**: four protagonists on a stage (tap to select; the selected one is bigger and plays its attack now and then), a panel with name, class | house | level, tagline, role, design note, six stat tiles, and a big Begin button. Torren also has Hair and Scarf rows (3 x 3 colourways).
- The chosen hero is the **lead**: drawn as the walker on the overworld and first in the roster. No stat, story or battle rule changes. Continue restores the lead and Torren's colours from the world save.
- Four unique designs (silhouette, palette, one accent colour, size): Torren = bare head, ember scarf with a swaying tail, charcoal gambeson; Bram = plumed great helm, grey beard, pauldrons, bone-white tabard, drawn 1.12x; Sela = pointed green hood, auburn braid, long bow, own bow-draw animation, drawn 0.96x; Wystan = tonsured crown, indigo robe, lantern staff taller than the head, own lantern-flare animation.

## Files
New: `data/looks.json`, `scripts/core/hero_looks.gd` (HeroLooks, pure rules), `scripts/core/hero_art.gd` (HeroArt, sheet loading and drawing), `scripts/ui/character_select.gd` (CharacterSelect, no autoload references), `scripts/ui/start_scene.gd`, `CharacterSelect.tscn`, `tools/make_hero_sprites.py`, `tools/sprite_src/soldier_*.png` (5 source sheets), `assets/sprites/characters/heroes/*.png` (60 files, 12 sheet sets), `docs/hero_designs.png`, `docs/torren_colourways.png`.
Changed: `scripts/core/game_data.gd` (`looks`), `scripts/core/game_state.gd` (`lead_id`, `appearance`, `begin_campaign`, `look_kind`, `look_scale`, `lead_kind`, `look_to_dict`, `look_from_dict`; `"look"` in `save_payload`/`apply_payload`; defaults in `new_game`), `scripts/ui/world_scene.gd` (`_load_lead_sprites`, called in `_ready` and `_after_load`; lead scale in `_draw_player`; New Game opens `CharacterSelect.tscn` when it exists), `tests/run_tests.gd` (`_test_looks_and_select`), `project.godot` (version only; `run/main_scene` is NOT changed, so the planned `home_screen` feature is not blocked), `README.md`, `docs/*`.

## Merge notes
- `run/main_scene` stays `World.tscn`. When `home_screen` arrives, its New Game button should open `CharacterSelect.tscn` too (that scene sets `GameState.booted = true` and loads `World.tscn`).
- The old (v0.7.3-line) zip has a battle-scene version of this feature (battle sprites per hero, `Art.usable_kind`); this line has no battle sprites, so battles still draw shapes. Porting hero sprites into battles is a later feature.
- Tests: `tests/run_tests.gd` gets one call after `_test_town_shops()` and the new function with its three counters (`chosen_count`, `chosen_lead`, `chosen_look`).

## Not done / limits
Recolour-and-overlay on a 17x21 px base, not new hand-drawn art; equipment is not shown on sprites (paper-doll layers later); no portraits; name entry not done; no Back button on the select screen; battle sprites not wired in this line. The select screen layout (stage 520 px + panel 440 px) is untested on a phone.
