# Feature `town_buildings` — authored settlement silhouettes (v0.8.5)

## Purpose
Make inhabited places recognizable at a glance on the Eldrimar overworld without introducing new licensed assets or changing the baked terrain map.

## Implementation
- `data/town_buildings.json` contains one authored composition for every keep, city, town and village (23 settlements total).
- Each definition includes a short style descriptor, palette and 3-7 building sprite placements relative to the settlement marker.
- `GameData.town_buildings` loads the definitions from local JSON.
- `WorldScene._draw_place()` uses the place-specific palette and placements. If a definition is absent, the existing `PLACE_LAYOUT` by place kind remains as a compatibility fallback. Missing textures still use the existing drawn fallback.
- `tools/make_town_buildings.py` regenerates the JSON from its authored layout table and checks settlement coverage, sprite existence and composition size.
- `_test_town_buildings()` checks all 23 settlement definitions, palette names, sprite stems and coordinate fields.

## Authored landmarks
Kaer Sethorn, Orrowen Hall, Brennhold, Ironford, Tarnholt Abbey, Quillon Tower, Aurelmont, Kingsway, Harrowgate, Cindermead, Brinegate and Salt Market each have a distinct composition. Smaller villages also have different arrangements. Region palettes are preserved, including Vessmoor's sand palette.

## Validation
Run:

```sh
python3 -I tools/make_town_buildings.py --check
python3 -I tools/gd_static_check.py
```

Then, with Godot installed and the project imported:

```sh
godot --headless --path . --import
godot --headless --path . --script res://tests/run_tests.gd
```

Expected offline data check: 23 settlement layouts and all sprite references present. Engine import, test suite, visual overlaps, label clearance and mobile scaling have not been verified in this environment.

## Scope and known limits
This feature changes only overworld settlement art. It does not add town interiors, new voxel models, NPCs, collision, shops or services. All referenced PNGs already exist in the project; the original voxel source-pack licences are still unverified. Keep the game offline and do not add network permissions.
