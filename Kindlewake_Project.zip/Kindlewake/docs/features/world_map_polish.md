# Feature `world_map_polish` — Eldrimar overworld presentation (v0.8.6)

## Purpose
Improve the readability and atmosphere of the free-roam overworld with a Final Fantasy-style JRPG presentation, while keeping the existing baked map and rules untouched.

## Implementation
- `scripts/ui/world_scene.gd` decorates visible terrain cells with deterministic details based on `WorldMap.hash01`: grass flecks, layered forest trees, hill contours, water/ford highlights, marsh reeds, sand striations and snow flecks.
- Road cells draw outlined paths connected to adjacent road/bridge cells. Bridge cells use a distinct deck tone and timber cross-planks.
- Discovered settlements draw a subtle plinth/ring beneath the authored `town_buildings` composition and use dark, gold-edged name plaques for contrast.
- `scripts/core/save_system.gd` reports game version 0.8.6; `SAVE_VERSION` and the save payload schema are unchanged.

## Compatibility and scope
- No changes to `data/world_map.json`, `data/world.json`, gate data, collision, movement, terrain IDs, encounter logic, battle-map conversion or save payload fields.
- No new assets or external dependencies. All detail is rendered with existing CanvasItem primitives and deterministic hashes.
- Rendering remains limited to the current visible camera rectangle.

## Validation
- `python3 -I tools/gd_static_check.py` — passed (0 errors, 0 warnings).
- `python3 -I tools/build_apk.py --check` — passed (offline preset/assets/permissions preflight).
- Godot is not installed here. Import, headless tests, visual overlap, frame-time and phone readability remain unverified.

## Review checklist in Godot
1. Import once, then run `tests/run_tests.gd`.
2. Walk across road junctions, bridges, forest, marsh, snow and Vessmoor sand; confirm the paths connect and terrain details do not obscure the walker.
3. Visit settlements at phone zoom; inspect plinth overlap, label plaque width and text clipping.
4. Pan across region boundaries and closed story gates; confirm gate markers remain visible above the terrain and roads.
