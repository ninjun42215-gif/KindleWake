# Feature `home_screen` — step 4/4 (v0.8.3)

## Included in this checkpoint
- Added `SettingsStore` autoload (`scripts/core/settings_store.gd`) for offline settings in `user://settings.cfg`. Defaults cover master/music/SFX volume, screen-shake preference and battle Auto Battle. Values are clamped and saved locally; the store preserves unrelated sections.
- Added `AudioManager` autoload (`scripts/core/audio_manager.gd`) with dedicated Music and SFX buses, a generated low-volume ambient loop, a generated UI preview tone and a gate-open chime. Audio data is synthesized in memory; no external audio files, network access or downloads are needed.
- Added reusable `SettingsPanel` with touch-sized master, music and SFX sliders and a sound preview. It is reachable from Home and the world menu.
- Home, World and Battle start the generated ambient loop. Successful story-gate actions play the generated gate chime.
- Battle Auto Battle now reads/writes the shared `SettingsStore`, keeping the existing `battle/auto_battle` key in the same `user://settings.cfg` file.
- Added settings persistence, clamping and battle-preference coverage to `tests/run_tests.gd`.

## Preserved behavior
- All settings are local and offline. Save-game payloads and save-slot format are unchanged.
- Existing `[battle] auto_battle` setting is preserved when the audio settings are saved.
- Audio is placeholder synthesis, not final soundtrack or production sound design.

## Step 4/4 completed
- Removed the legacy Continue/New Game boot overlay from `world_scene.gd`; the app now enters through `Home.tscn` only.
- World scene no longer blocks movement behind a boot panel and no longer has duplicate New Game/Continue flows.
- Home remains responsible for Continue, Load Game, confirmed New Game, and Settings. World menu retains Save, Load and Settings.
- App pause now records the current world position and autosaves directly while the world scene is active; it no longer depends on the obsolete `GameState.booted` gate.
- Added a navigation regression test for the configured Home entry scene, required scene resources and absence of the legacy boot overlay.
- Updated the Home version label to v0.8.3.

## Remaining review
Run engine/touch review when Godot is available. The navigation code is statically checked, but scene import, runtime transitions, audio playback, visual layout and touch interaction have not been run in Godot.

## Verification and limitations
- Static checker: 33 files/classes, 0 errors, 0 warnings.
- Added settings persistence/clamping tests, but the test suite has not been run because Godot is not installed here.
- Audio bus creation, generated WAV playback, scene import, slider layout and touch interaction remain unverified in Godot.
