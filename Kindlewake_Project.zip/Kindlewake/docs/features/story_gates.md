# Feature story_gates: quest-locked passes, flags, quests and a journal (STEPS 1-5 IMPLEMENTED / ENGINE REVIEW REMAINS; status in docs/WIP.md)

Asked for by the user: "some areas are only passable through quests", travelling "like FF7 and Suikoden II". Built on v0.7.1 (the 452 x 340 Eldrimar). **Built in small checkpointed steps.**

## Principle: an overlay, no change to the baked world
`data/world.json` and `data/world_map.json` stay exactly as `tools/make_world.py` bakes them. A second generator, `tools/make_gates.py`, reads them and writes ONE new file, `data/world_gates.json`:
* `bands`: run-length cells (`[y, x0, x1]`) of mountain walls raised along every sealed region border. `WorldMap` stamps them as MOUNTAIN at load. Re-bake the world, re-run `make_gates.py`, done. For each gate, `WorldMap` finds a shortest contiguous corridor through its band between walkable cells in the two named regions; this is important because the authored marker cells alone may not span an irregular boundary.
* `gates`: id, name, kind (barricade / ward / iron / toll), cells (3 road cells inside a band), `requires`, `hint`, `open_text`.
* `place_actions`: extra buttons on place panels (talk, pay a toll, swear an oath) with `requires`, `cost`, `set`, `text`.
* `quests`: journal entries (flag steps).
A road that crosses a sealed border outside its pass is cut by the band. The runtime map overlay and offline tests verify that with every gate shut only the free regions are reachable and, with every gate open, all places are reachable. Place-action solvability is part of the next integration step.

## Requirements language (`WorldStory.met(reqs, flags, party)`)
`"flag"` set, `"!flag"` not set, `"item:id"` in the bag, `"gold:N"` at least N. Flags live in `GameState.world_flags` (already saved with the world). Existing flags keep their names: `cleared_<camp>`, `looted_<ruin>`, `seen_<place>`.

## Region ladder for the live world (8 regions, tiers 1-5)
Free: Sethmarch (1) <-> Orrowen (2). Sealed otherwise; a pass is an EXISTING road crossing:
| gate | border (road) | key |
|---|---|---|
| g_roadwolf (barricade) | Sethmarch / Ysmark (crossing - salt_market) | `cleared_roadwolf_camp` |
| g_oakroad (ward) | Orrowen / Aurelmont (thornwick - kingsway) | `lucan_oath`: loot the Hollow Oak, then swear at Orrowen Hall |
| g_toll (toll) | Ysmark / Aurelmont (brinegate - harrowgate) | `toll_paid`: pay 150 gold at Brinegate |
| g_dustwell (barricade) | Aurelmont / Vessmoor (harrowgate - dustwell) | `cleared_deserter_camp` |
| g_cloister (ward) | Aurelmont / Tarnholt (kingsway - candlemere) | `pilgrim_seal`: loot Osric's Field, ask at Kingsway |
| g_starwick (iron) | Vessmoor / Quillon (dustwell - starwick) | `cleared_sandjackal_camp` |
| g_ironford (iron) | Tarnholt / Brennhallow (candlemere - ironford) | `cleared_flamebearer_camp` (a Quillon camp: two branches meet) |
Everything else (Orrowen/Brennhallow, Tarnholt/Quillon, Ysmark/Vessmoor, ...) is a plain wall.

## Steps
1. `tools/make_gates.py` + `data/world_gates.json` (verified offline). 2. `scripts/world/world_story.gd` (`WorldStory`: `met`, `gate_open`, `quest_state`, `journal_lines`) + tests. 3. `WorldMap` stamps bands and honours closed gates (`passable`, `connected_with`). 4. `world_scene.gd` integration now draws closed gate markers, shows bump hints, wires pay-toll/oath/seal actions, refreshes passability and autosaves, and adds a Journal overlay. Still needs Godot visual/input review. 5. Final docs, static check, checkpoint and merge-ready `Feature_story_gates.zip` are complete (v0.7.9). The pack is based on the v0.7.4 baseline; engine import, tests, visuals and touch input remain unverified.
Later features (separate packs): `fast_travel` (Flame beacons, Suikoden's Blinking Mirror), `transports` (horse: fast, no forest/marsh; ship: sea only, needs a sea edge), `map_fog` (explored-only map), `town_interiors` (from the v0.7.3-line chat: `Location.tscn`, `LocalMap`, `locations.json`).

## Reference
`tools/prototypes/eldrimar2/` holds an alternative 13-region world with 8 gates and verified closure; `build_barriers`, `astar`, `flood` there are the model for `make_gates.py`.
