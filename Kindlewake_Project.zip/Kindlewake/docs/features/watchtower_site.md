# Feature `watchtower_site` — The Old Watchtower (v0.8.7)

## Purpose
Add another explorable point of interest to the Sethmarch overworld while Godot is unavailable for engine review. The feature extends the existing data-driven room/site system and reuses room geometry and rendered images already shipped in the project.

## Implementation
- The existing `watch` ruin in `data/world.json` now links to the `watchtower` site.
- `data/sites.json` defines a two-room route: **The Fallen Watch** (corridor model) and **The Upper Watch** (stairs model). The rooms connect through their authored exit pads; the lower room also returns to the overworld.
- Added the Muster Roll lore spot, a one-time Watch Captain's Lockbox (65 gold), and the Signal Brazier lore spot.
- `tests/run_tests.gd::_test_rooms()` now asserts the site loads, contains two rooms and is linked from the Old Watchtower overworld ruin. The existing `RoomMap.validate()` suite validates geometry, spawns, exits, reachable spots, chest data and site graph connectivity.
- Corrected project version metadata to 0.8.7 in `project.godot`, the Android export preset and `SaveSystem.GAME_VERSION`; save schema/version is unchanged.

## Compatibility and scope
- No new image, model, external dependency, permission, network path or save field.
- Existing room assets are reused; voxel room-pack licence status remains unverified, so public/commercial release still requires the checks in `docs/ASSETS.md`.
- The ruin's existing overworld search reward remains separate from the room's chest reward. The chest has its own unique ID.

## Validation
- Python parity check against the `RoomMap` walk-grid, exit and spot reachability rules: all 3 sites / 11 rooms pass.
- Static checker, JSON validation and offline APK preflight are recorded in the checkpoint.
- Godot import, `tests/run_tests.gd`, room transition behavior, chest persistence and phone visual review are **not run** because Godot is unavailable.
