# Feature `room_swirl_transition` — radial spiral room wipe (v0.8.8)

## Purpose
Give screen-to-screen movement in the pre-rendered room system a more authored transition than a flat alpha fade, while preserving the existing callback and save flow.

## Implementation
- Added `assets/shaders/room_swirl.gdshader`, a procedural full-screen CanvasItem shader. It builds a radial spiral front with restrained ember/gold glints over a deep-ink field.
- `RoomScene._build_ui()` assigns the shader to the existing full-screen transition `ColorRect` with progress initialized to zero.
- `RoomScene._fade()` tweens the shader's `progress` parameter. Existing calls remain at the same points: room exits fade fully before loading the next room or leaving the site; dungeon encounters fade fully before the battle scene change; successful room transitions reveal the destination with the reverse wipe.
- If the shader material is unexpectedly absent, the callback is still invoked rather than deadlocking the room transition.

## Compatibility and scope
No external textures, new assets, save fields, room data, dependencies, permissions or network paths. Existing transition callback ordering, room persistence and autosave calls are unchanged. The project and Android export display version plus `SaveSystem.GAME_VERSION` advance to 0.8.8; the save schema/version is unchanged.

## Validation and limitations
Static GDScript checks, JSON validation, existing world/site generators and APK offline preflight are run at checkpoint. Godot shader compilation, actual visual output, transition timing and phone performance are not verified because Godot is unavailable in this environment.

## Regression guard (v0.8.9)
`tools/check_room_transition.py` checks the shader contract and the eight source-wiring points that connect it to `RoomScene`. `tools/checkpoint.py` invokes it automatically. A pass confirms source consistency only; it does not establish Godot shader compilation or runtime rendering.
