# Feature party_ui: Party screen redesign, shop compare + confirm, touch scrolling

Built on v0.7.0 (Eldrimar). Written and statically checked only; **not run in Godot**.
Merging: `python3 -I tools/merge_features.py apply Feature_party_ui.zip` (dry run), then `--apply`. The code files below merge cleanly into a v0.7.0 project; the docs text on this page is pasted into the GDD and handoff by hand.

## Why
A real phone screenshot showed the old Party screen cramped: the Gold label wrapped one letter per line and made the top bar half the screen high, the panels were squeezed into the lower half, the equipment lists were hard to scroll by touch (full-width Buttons take the finger), and nothing showed what a purchase would change.

## Files (all in the pack)
- `scripts/ui/party_screen.gd` rewritten (same public API as v0.7.0: `setup(party, db, shop, can_edit)`, `has_shop()`, `tab_ids()`, `open(start_tab)`, `close()`, `closed`, `builds`, `message`, `changed`, every `_on_*` handler; `can_edit` false = view-only, the Shop tab only where the town has a shop).
- `scripts/ui/tap_card.gd` new: `TapCard`, a PanelContainer that taps on a short press and scrolls the nearest ScrollContainer when the finger moves more than 12 px (mouse wheel works too).
- `scripts/core/item_info.gd`: new `delta_parts(before, after)` (per-stat changes for green/red colouring).
- `tests/run_tests.gd`: shop compare/confirm checks, TapCard tap / drag / disabled checks, a view-only check that a shop card cannot be opened.
- `tools/gd_static_check.py`: knows PanelContainer subclasses and `accept_event`.

## GDD text (paste into section 4.7, after the Party screen paragraph)
**Layout (feature party_ui).** Top bar (62 px): title, a Gold chip that never wraps, Close; the phone Back button / Esc also closes the screen. Roster: one card per hero (level badge, name, class, green PROMOTE tag). Sheet: `<` `>` buttons step through the roster; EXP bar; HP/MP and nine combat numbers as stat tiles; the ten base stats as tiles that turn green or red when gear adds or removes points; skills as small boxes; promotion buttons (a note in view-only mode). Equipment tab: six slot cards (slot, item name in its rarity colour, item numbers); tapping a slot opens the choices below it, each with its stat change in green (better) and red (worse), blocked items dimmed with the reason, Unequip, a read-only Bag list, an "Open the Shop" shortcut only where the town has a shop. Sigils tab: socket cards with level and AP; the choices panel shows level, effect, the linked Tutor bonus, Remove and the bag sigils as cards. Message banner: always visible; a hint for the tab, green after something worked, red after a refusal, and in view-only mode the line "View only. Change gear, sigils and rank inside a town." Scroll positions of the roster, sheet and right panel are kept across rebuilds. Colours and sizes are constants at the top of `party_screen.gd`.

**Shop: compare before buying, confirm every buy and sell.** Tapping a gear card opens it (state `shop_pick`, e.g. `buy:item:mace`, `sell:item:mace`, `sell:sigil:0`): the stat change (green/red) if the selected hero wore it, in every slot it fits (both accessory slots), what it would replace, the reason when it cannot be used, and one line per other hero (`<` `>` on the sheet changes who is compared). Sigil cards show effect and AP line. The opened card shows Cancel and a Confirm button ("Confirm: buy for 60 g", "Confirm: sell for 30 g"; when gold is short it is disabled and says how much is missing). Handlers: `_on_shop_pick`, `_on_confirm_buy`, `_on_confirm_sell_item`, `_on_confirm_sell_sigil`; the direct `_on_buy` / `_on_sell_item` / `_on_sell_sigil` still act at once (tests use them). Prices use the town's `price_mult` and the section header shows it ("prices +25%").

**Touch scrolling.** Every card is a `TapCard`, not a Button (a Button swallows a finger drag that starts on it). After each build `_relax_mouse` sets every non-interactive Control to ignore the mouse so a drag that starts on a tile or a gap also scrolls. Plain buttons left inside lists (Unequip, Cancel / Confirm, Promote, Remove) still take a drag that starts on them.

## Handoff text
Check on a phone: card heights with long item text, tap routing on cards (`_seal`), wrapping of the green/red delta rows (HFlowContainer), the `await` in `_restore_scroll`, drag from the middle of a card scrolls and a short tap selects (no double scrolling, no jump), fit at 1280x720 and 20:9 (minimum widths 250 + 400 + 460). If scrolling is still stiff: add inertia to TapCard or turn Unequip / Cancel / Confirm into TapCards too. Ideas not done: item icons, sort/filter for a long bag, compare sigils by resulting stats.

## Revision-log row
| 0.7.1 | Feature party_ui: Party screen redesign (cards, stat tiles, green/red gear deltas, Bag list, message banner, Back button, kept scroll), shop compare-before-buy and Confirm on every buy and sell, `TapCard` touch scrolling, `ItemInfo.delta_parts`; keeps the v0.7.0 view-only and per-town shop rules. Not run in Godot. |
