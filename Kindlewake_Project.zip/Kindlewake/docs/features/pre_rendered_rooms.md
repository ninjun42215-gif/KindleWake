# Feature pre_rendered_rooms: FF7-style pre-rendered rooms, a keep and a dungeon

Built on v0.7.3 (this line: 452 x 340 Eldrimar world). Written and statically checked only; **not run in Godot**.
Merging: `python3 -I tools/merge_features.py apply Feature_pre_rendered_rooms.zip` (dry run), then `--apply`. JSON (`characters`, `encounters`, `world`) merges by key; docs text is merged by hand.

## Why
The user asked for the game to feel like Final Fantasy VII or Suikoden II on the world map, in towns, in rooms and in dungeons, using the voxel packs in `sprite.zip`. The packs contain nine voxel "dollhouse" rooms (50 x 50 x 50 voxels, sandstone ruin theme): Boss Room, Dragon Room (waterfall), Garden, King's Throne, Princess Chamber, Stairs, Thirsty Corridor, Trapped Room, Treasure. That is exactly the FF7 recipe: a fixed pre-rendered picture, a small hero walking on a hidden walk grid, props that pass in front of him, and screen-to-screen room changes.

## What the player gets
- **Kaer Sethorn** (the keep on the overworld) has an *Enter* button: the Great Hall (throne room, steward, war table = Party and Gear) and the Lord's Chamber (maid, old footlocker).
- **Dunmarrow Barrow** (existing ruin in Sethmarch) has an *Enter* button: a 7-room dungeon, **Beneath Dunmarrow Barrow** (Thirsty Gate, Trial Chamber, Stair Hall, Weeping Fall, Ember Spring, Reliquary, Warden's Seal). Walk to a glowing pad to change room (fade). Random encounters roll while you walk in the dungeon rooms (110 to 260 cells of walking), the Ember Spring is safe, chests hold gold and gear (remembered in `world_flags`), the Warden's Seal starts the boss fight `battle_02` and the boss stays dead (`hollow_cleared`), after which the Warden's Hoard chest appears.
- Battles started in a room return to that room, at the same cell ("Back to the World" button label is unchanged; it now calls `GameState.return_from_battle()`).

## Files (all in the pack)
- `tools/vox_iso.py` (MagicaVoxel `.vox` reader + 2:1 isometric painter's-algorithm renderer, ambient occlusion on top faces), `tools/build_scenes.py` (renders the nine rooms, the occluder slices, derives walk grids and heights from the voxels, writes `data/rooms.json`). Run: `python3 tools/build_scenes.py <folder with the unzipped sprite packs> [--debug]`. The packs are NOT shipped; the generated PNGs and JSON are.
- `assets/art/rooms/<model>.png` (404 x 448 backgrounds) and `<model>_o<k>.png` (occluder slices: props that draw in front of the hero when he stands behind them).
- `data/rooms.json` (generated geometry: projection, 50 x 50 walk grid, base-36 floor heights, slice placement), `data/sites.json` (hand-authored: sites, rooms, exits, spots, spawns, encounters), `data/battles/battle_02.json`.
- `scripts/world/room_map.gd` (`RoomMap`: pure logic, projection, BFS route with line-of-sight smoothing, exits, `validate()`), `scripts/ui/room_scene.gd` + `Room.tscn` (the scene).
- Small edits: `game_data.gd` (`rooms`, `sites`, `battle_02`), `game_state.gd` (`pending_site/room/spawn`, `battle_return`, `start_battle_from_room`, `return_from_battle`, `skirmish_def(table)`), `encounter_builder.gd` (optional table name), `battle_scene.gd` (Back button, `clear_flag`), `world_scene.gd` (*Enter* button, `_enter_site`), `tests/run_tests.gd` (`_test_rooms`).
- Data merged by key: `characters.json` (+ `hollow_husk`, `hollow_shade`, `hollow_warden`), `encounters.json` (+ `skirmish_hollow`), `world.json` (`site` on places `sethorn` and `barrow`).

## How the rooms work
- Camera: true 2:1 dimetric, rotation 2 of the voxel model (the open front faces the camera; back walls are the planes x = 0 and y = 0). Cell (x, y) is one voxel column. `RoomMap.project(p, dz)` gives the pixel in the background image, `unproject` inverts it for taps (height settles in a few passes).
- Walk grid: a column is floor when its solid run from the bottom has at least 9 free voxels above it, props taller than 3 voxels block with a one-cell margin, the largest region joined by steps of at most 2 voxels is the walkable area.
- Depth: occluder slices are the prop voxels cut into bands of 4 along x + y. The scene sorts hero, spots and slices by x + y and draws them in that order, so a slice drawn after the hero covers him.
- Exits are rectangles in cell coordinates (`rect: [x0, y0, x1, y1]`) with a target room and a spawn cell; arriving inside a pad does not trigger it. `"@leave"` returns to the overworld.

## Tests (`_test_rooms`)
`RoomMap.validate` over every site (50 x 50 grids, walkable spawns, exits reachable and not spawning inside a pad of the target room, spots reachable, chests with real items, boss battle exists, every room reachable from the start), projection round trip, route over the grid, nearest walkable cell, `world.json` sites exist, barrow encounter table, `battle_02` terrain, Warden reward. A Python mirror of the reachability checks passed on the real data in the build session.

## Known limitations and risks (first Godot run)
- Never run in Godot. Likely trouble: `Camera2D` zoom with the HUD safe area, `get_canvas_transform()` taps, `Tween` on `ColorRect.color:a`, the lambda in `items.sort_custom`, texture import of ~380 small slice PNGs, hero scale (`HERO_SCALE` 1.9) against the room, the walk speed (`WALK_SPEED` 11 cells/s).
- Room position is not saved (a load puts you on the overworld at the entrance). Chest and boss flags are in `world_flags` and are saved.
- The battle result text is generic ("The enemy is broken"). Dungeon fights reuse the 12 x 10 `battle_02` map for every encounter.
- Door positions were placed by eye from rulers drawn on the renders; if a pad looks misplaced, edit the `rect` in `data/sites.json` (the validator will say if it becomes unreachable).
- The Dragon Room is split by its water channel, so only the back strip is walkable; the Stairs room is walkable only in front of the steps (its *up* pad is the way on).
- Licence of the voxel room packs is **unverified** (no licence files in the upload). See `docs/ASSETS.md`.
- Town interiors from the older v0.7.3 line (`Location.tscn`) are not part of this pack. When `town_interiors` is ported, give a door `"site": "<id>", "room": "<room>"` and send the hero to `Room.tscn` the same way `_enter_site` does.

## Ideas not built
Town buildings drawn from the CountrySide and Medieval Town voxel sets (Suikoden-style), an ancient-temple sprite for dungeon places on the overworld, a swirl transition into battle, torch flicker and light shafts in the rooms, more rooms (Ancient Temple, Rock Statues, Cosmic Portal are in the pack but unused), saving the current room, the Isometric Free Sample 2D pieces for a second dungeon style.
