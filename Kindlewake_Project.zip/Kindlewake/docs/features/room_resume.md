# Feature `room_resume` — persist pre-rendered room location (v0.8.4)

## Purpose
A world save previously stored only the overworld position and flags. Entering Kaer Sethorn or Dunmarrow Barrow and continuing later returned the player to the overworld. This feature stores the current site, room and hero cell so the player resumes where they left off.

## Save schema
The existing world payload remains `{"kind":"world","party":...,"world":...}`. The `world` object now optionally contains:

```json
{"room":{"site":"hollow","room":"reliquary","cell":[24,31]}}
```

- `site`: key in `GameData.sites`
- `room`: key in that site's `rooms` dictionary
- `cell`: hero cell in room coordinates

The field is optional; old saves load as overworld saves. Invalid or unknown site/room identifiers are ignored for resume and fall back to the overworld.

## Runtime behavior
- `GameState.current_room` is the live persisted location; `set_current_room`, `clear_current_room`, `has_saved_room` and `prepare_saved_room` own the state transitions.
- `RoomScene` records the current cell as the hero moves. It autosaves on room load/transition, after chest loot, before a room boss battle and when the app pauses or loses focus.
- Leaving a site clears the room marker and autosaves, preserving the overworld location saved on entry.
- Home Continue and Load Game resume `Room.tscn` when the loaded save points to a valid room; otherwise they open `World.tscn`.
- Loading a room save from the world menu also changes to `Room.tscn`.
- A battle started in a room still returns to the same room/cell through the existing `battle_return` hand-off.

## Scope and limitations
- Saves store a safe cell, not the active path, walking animation, open panel, encounter timer or camera tween.
- Room cell is normalized by `RoomScene` to a walkable cell on load; invalid saved cells fall back to that room's authored spawn.
- Autosave on app pause depends on the existing `SaveSystem.app_paused` lifecycle signal.
- Static validation and save-envelope tests are written; Godot import, headless suite and phone resume flow have not been run in this environment.
