# Recruitment Hall portraits (v0.9.1)

## Scope

- Four original 512 x 512 character portraits added: Torren, Sela, Brother Wystan and Hask Gravelteeth.
- Bram's earlier portrait remains unchanged. All five current named characters now have distinct portrait files.
- Town tavern Recruitment leads now renders portrait cards with character name, class, story/rumour, join quote, locked/available state and Invite action.
- `data/recruits.json` selects Hask's portrait with `portrait`; character portraits in the Company screen continue to use the character ID filename convention.

## Preserved behavior

Recruitment still checks the existing requirements through `WorldStory.met`, prevents duplicate party members, adds the existing character definition, sets `recruited_<id>`, autosaves, and plays the existing gate-open sound. No new save fields or network code.

## Verification limits

Static source/data checks only. Godot import, actual Control layout, portrait rendering and touch interaction have not been run or reviewed in-engine.
