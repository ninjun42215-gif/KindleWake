# Kindlewake — Professional Design & Production Review
Reviewed: 7 on-device screenshots (world, Company, battle briefing, battle, town, recruit x2) + APK v0.12.0 code/data.
Verdict: **a very solid systems prototype (data, rules, saves, 34 characters, 106 items, runes, forge) wearing a prototype skin.**
The gap to "premium" is ~80% presentation, ~20% flow. Good news: presentation is the cheaper part to fix.

## 1. Screen-by-screen critique
**World map (screenshot 1)**
- Ground is a flat grid of big shaded squares → reads as a debug map. Voxel/3D buildings + tiny pixel hero + flat tiles = three art styles in one frame.
- HUD buttons (COMPANY / SAVE / WORLD ATLAS) are stacked at different widths, staggered, overlapping the terrain; place labels are cut off ("er Sethorn", "The Vessmoor C…").
- EXP bar is a thin grey line (fill invisible); minimap is good but unframed from the world art.
- No sense of place: no lighting, weather, shadows, ambient motion, footprints, wind, water animation.
**Company screen (2)**
- Information architecture is GOOD (list | stats | gear tabs, compare hint). Keep it.
- Bug: minimap drawn over it (fixed in patch). World strip visible on the left edge.
- No portraits, no slot icons, no rarity colour (all "Common" text), HP/MP shown as bare numbers, stats are a wall of 9+ boxes.
**Battle (3, 4)**
- Briefing modal hides the battlefield; three actions are plain text, no icons/hierarchy.
- Black void around the iso diamond; panels use 3 different dark styles; action buttons disabled-grey, low contrast, no icons; empty combat-log box; "Auto Battle: ON" looks like a label not a toggle.
- Turn chips "TOR ROA ROA" cryptic; name tags overlap on clusters; "Mis" clipped; all HP bars identical green; no portraits, no damage-preview on target selection, no hit-stop/shake/particles.
**Town (5)**
- Flat green rectangle, brown rectangles as doors, grey brick frame in a black void. NPC uses the SAME sprite as the hero. No building signage/names. Towns are the emotional hub — currently the weakest screen.
**Recruit (6, 7)**
- Good copy and loyalty mechanic. Missing: portrait, class/stat preview, skills, cost. Ghost duplicate title visible behind the card. "Invite" button still shown after joining.

## 2. Root causes (fix these, not symptoms)
1. **No art direction.** Pick ONE: **pixel-art "HD-2D-lite"** — pixel characters/tiles + soft lights, vignette, particles, parallax. Retire the voxel pack (also your licence blocker).
2. **No UI system.** Three palettes (brown parchment, navy, black). One theme, one panel family, one button family, one icon set, one font pair.
3. **No feedback layer.** No sound, no tweens, no haptics, no hit effects → nothing feels "alive".
4. **Content shown as text.** Premium RPGs show portraits, icons, bars, colours. Replace numbers/words with pictures wherever possible.
5. **Layout built from magic numbers.** Needs responsive containers + safe-area wrapper.

## 3. Target experience (design pillars)
- **Readable in 1 second:** who is acting, who is in danger, what can I do next.
- **Tactile:** every tap animates, sounds and buzzes.
- **Cozy-dark fantasy:** warm lantern light against cold blue night; brass + ink UI; serif titles.
- **Respect the thumb:** 56 px targets, bottom-reachable actions, no tiny text (min 14 pt body 16).
- **Story-forward:** portraits + dialogue + choices with visible consequences (loyalty, flags).

## 4. Concrete upgrade list (ordered by impact per hour)
**A. Quick wins (1–2 days)** 
1. Add KW autoload (global theme, button feel). 2. Bundle fonts: Cinzel (titles) + Inter or Noto Sans (body). 3. UI + combat SFX and 4 music loops. 4. Ember/dust particles on title and world. 5. Camera vignette + CanvasModulate tint per time/place. 6. Damage numbers with outline + crit colour (done) + screen shake on crit. 7. HUD: group COMPANY/SAVE/ATLAS into one top-right icon bar (3 square 56 px icon buttons), full-width EXP bar. 8. Place labels: pill background, never clipped.
**B. UI foundation (3–5 days)** 
Theme resource with 3 panel styles (solid, glass, parchment), 4 button styles (primary, secondary, danger, ghost), rarity colours (common grey, uncommon green, rare blue, epic purple, legendary gold, mythical crimson-glow). Icons: slots, stats, elements, status. Portrait frame component (circular, rarity ring).
**C. Battle HUD (1 week)** 
Bottom action bar with icons (Move/Attack/Skill/Item/Wait) 64 px; skill cards; target preview (hit %, damage range); turn ribbon with portraits; unit plate (portrait + HP/MP bars) top-left; collapsible log; hit flash, knockback tween, floating numbers, camera nudge, death dissolve; battlefield framed with parallax backdrop instead of black void; Auto toggle as a pill switch; x1/x2/x3 speed.
**D. World & towns (1–2 weeks)** 
Re-skin tiles with a consistent pixel tileset (16/32 px) + auto-tiling; animated water; shadow blob under props; building sprites with names; NPC unique sprites; interactables glow + "!" bubble; day/night tint; footstep SFX by terrain. Towns: draw them as small illustrated scenes (shop counter, inn bar) with portrait NPCs — fastest way to premium feel.
**E. Characters & story (ongoing)** 
Portraits for all 34 characters (bust + 4 expressions), dialogue box with typewriter, voice-less "blips" per character, recruit cards with class preview.
**F. Progression & depth (design)** 
- Clear 5-minute loop: explore → skirmish → loot → upgrade (forge/runes) → story beat. 
- First-hour onboarding: contextual hint cards (tap-to-move, sigils, auto-battle), unlock complexity gradually (runes after battle 2, forge after chapter I).
- Difficulty: Story / Standard / Veteran; retry-with-adjustment on defeat; no hard-lock after party wipe.
- Meaningful choices: prologue choice should change dialogue, loyalty and a unique item/skill later (flag already exists).
- Sigil/rune chase: visible rarity pop on drops (beam of light + jingle) — the dopamine moment.
- Descendant/lineage system (your idea) is a strong hook: show a family-tree screen with legacy perks.

## 5. Asset sourcing (licences — ALWAYS confirm on the download page and log in data/asset_provenance.json)
| Need | Source | Licence | Notes |
|---|---|---|---|
| Tiles, characters, UI theme, spell icons, SFX, music, fonts | **Ninja Adventure Asset Pack** (pixel-boy.itch.io) | **CC0** (verified on the page; author confirms commercial use) | Biggest single win. Theme is east-Asian flavoured: use its tiles/UI/SFX/music and recolour or pick the generic villagers/knights; Godot 4 project included. |
| UI kits, icons, input prompts, particles, tiny tiles | **Kenney.nl** (UI Pack RPG Expansion, Tiny Town, Tiny Dungeon, Particle Pack, Game Icons) | CC0 (confirm per pack) | Very consistent style. |
| Skill/item/status icons (thousands) | **game-icons.net** | CC BY 3.0 (credit authors) | Recolour via modulate; add a credits screen. |
| Fonts | **Google Fonts**: Cinzel / Cormorant Garamond (titles), Inter / Noto Sans (body), Noto Sans JP/SC fallback if localising | SIL OFL | Bundle .ttf files in `assets/fonts/`. |
| Dungeon/enemy pixel sprites | **0x72 DungeonTileset II** (itch.io) | CC0 | Good for enemies/props. |
| Music | **OpenGameArt** (filter CC0), **Pixabay Music**, **Incompetech** | CC0 / Pixabay licence / CC BY | Need loops: title, overworld, town, battle, boss, sad story. Check each track's licence. |
| SFX | **Freesound** (filter CC0), **Kenney Audio**, **Sonniss GDC bundles** | per file | Download UI tap/confirm, sword hit, bow, magic, level-up, coin, footsteps. |
| Portraits | AI-assisted + hand cleanup, or commission on itch.io/Fiverr/ArtStation | your contract | Must have a consistent style; keep proof of rights. Avoid mixing sources. |
| Free-with-terms packs (Pixel Frog "Tiny Swords", etc.) | itch.io | custom — READ terms | Fine if commercial use allowed; record evidence. |

Process: download → put licence text in `/licenses/` → add row to `data/asset_provenance.json` → only then commit. Remove "Voxel building packs" (unverified) before any public release.

## 6. Technical notes for a premium feel on Android
- Renderer: you use GL Compatibility → WorldEnvironment Glow is not available; fake bloom with additive sprites/gradients, use `CanvasModulate`, `PointLight2D` (supported) sparingly, `CPUParticles2D` for embers.
- Keep draw calls low: atlas textures, avoid per-frame full-screen `queue_redraw()` for static scenes; cache StyleBoxes; pool popups.
- Use `Input.vibrate_handheld` lightly; provide a haptics toggle (already in KW).
- Safe-area wrapper on every screen; landscape lock is correct for this game — test 20:9 and tablets.

## 7. Production plan (solo dev friendly)
Sprint 1 (week 1): KW kit, fonts, SFX/music, HUD icon bar, battle chips/tags/popups, remove black void, title polish.
Sprint 2 (week 2): UI theme + rarity system, Company screen portraits/icons, recruit card redesign, dialogue box.
Sprint 3 (weeks 3–4): tileset swap + auto-tiling, town illustrations, NPC sprites, lighting/particles.
Sprint 4 (month 2): battle HUD v2 + skill UI, onboarding, difficulty modes, first-hour balance pass.
Sprint 5+: new classes/skills, shops/trade, lineage system, continent 2.
Ship gates: licences clean, 60 fps on mid-range phone, no crash in 2-hour soak test, save migration tested.

## 8. Test checklist after applying Premium Pass v1
- Open Company: minimap no longer overlaps; gear compare still works.
- Battle: chips show names, tags only on active/inspected unit, "Miss"/damage fully visible.
- With KW autoload: buttons squash + buzz; sliders/scrollbars/inputs brass-themed; nothing unreadable.
- With KW removed from autoload: game still runs (script patches are independent).
