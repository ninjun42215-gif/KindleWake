extends Node
## Kindlewake premium-UX bootstrap. Register as an AUTOLOAD named "KW"
## (Project > Project Settings > Autoload > path res://scripts/core/kw.gd, name KW).
##
## What it does with ZERO edits to existing screens:
##   1. Applies one global Theme (buttons, option buttons, inputs, sliders, scrollbars, progress bars, popups).
##      Screens that already set their own style overrides keep them; everything else becomes consistent.
##   2. Every Button gets press-scale animation, a short haptic tick and a UI click sound.
##   3. Optional fonts: drop OFL fonts at res://assets/fonts/body.ttf (and title.ttf) and they are used automatically.
##   4. Optional audio: drop .ogg files in res://assets/audio/sfx/ (ui_tap, ui_confirm, ui_back, hit, miss, level_up)
##      and res://assets/audio/music/ (title, world, town, battle). Missing files are silently ignored.
##   5. KW.goto("res://World.tscn") = fade transition (opt-in; replace get_tree().change_scene_to_file calls over time).

const INK := Color("#101820")
const INK_RAISED := Color("#1b2b35")
const INK_DEEP := Color("#0b141a")
const BRASS := Color("#b9955e")
const BRASS_LIGHT := Color("#e4c991")
const PARCHMENT := Color("#f0e5ce")
const MUTED := Color("#aeb8b4")
const DANGER := Color("#e6a18f")
const SUCCESS := Color("#a8c7a0")

const FONT_BODY := "res://assets/fonts/body.ttf"
const FONT_TITLE := "res://assets/fonts/title.ttf"
const SFX_DIR := "res://assets/audio/sfx/"
const MUSIC_DIR := "res://assets/audio/music/"

var reduce_motion: bool = false
var haptics: bool = true
var sfx_enabled: bool = true
var title_font: Font = null

var _fade_layer: CanvasLayer
var _fade_rect: ColorRect
var _busy: bool = false
var _music: AudioStreamPlayer
var _music_id: String = ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().root.theme = _build_theme()
	get_tree().node_added.connect(_on_node_added)
	_build_fade()
	_music = AudioStreamPlayer.new()
	_music.bus = "Master"
	add_child(_music)


# ------------------------------------------------------------------ theme

func _box(bg: Color, border: Color, bw: int = 2, radius: int = 10, margin: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(margin)
	return s


func _build_theme() -> Theme:
	var t := Theme.new()
	if ResourceLoader.exists(FONT_BODY):
		t.default_font = load(FONT_BODY) as Font
	if ResourceLoader.exists(FONT_TITLE):
		title_font = load(FONT_TITLE) as Font
	t.default_font_size = 18

	for type_name in ["Button", "OptionButton", "MenuButton"]:
		t.set_stylebox("normal", type_name, _box(INK_RAISED, BRASS))
		t.set_stylebox("hover", type_name, _box(Color("#29404a"), BRASS_LIGHT))
		t.set_stylebox("pressed", type_name, _box(INK_DEEP, BRASS_LIGHT))
		t.set_stylebox("focus", type_name, _box(Color(0, 0, 0, 0), Color("#f3dba9"), 3))
		t.set_stylebox("disabled", type_name, _box(Color("#172129"), Color("#59646a")))
		t.set_color("font_color", type_name, PARCHMENT)
		t.set_color("font_hover_color", type_name, Color("#fff4dc"))
		t.set_color("font_pressed_color", type_name, BRASS_LIGHT)
		t.set_color("font_disabled_color", type_name, MUTED)

	t.set_stylebox("normal", "LineEdit", _box(INK_DEEP, Color("#596873"), 2, 8, 10))
	t.set_stylebox("focus", "LineEdit", _box(INK_DEEP, BRASS_LIGHT, 2, 8, 10))
	t.set_color("font_color", "LineEdit", PARCHMENT)
	t.set_color("caret_color", "LineEdit", BRASS_LIGHT)

	t.set_stylebox("panel", "PopupMenu", _box(INK, BRASS, 2, 10, 8))
	t.set_stylebox("hover", "PopupMenu", _box(Color("#29404a"), BRASS_LIGHT, 1, 6, 6))
	t.set_color("font_color", "PopupMenu", PARCHMENT)

	t.set_stylebox("background", "ProgressBar", _box(INK_DEEP, Color("#3a4650"), 1, 6, 0))
	t.set_stylebox("fill", "ProgressBar", _box(BRASS, BRASS_LIGHT, 0, 6, 0))

	for slider in ["HSlider", "VSlider"]:
		t.set_stylebox("slider", slider, _box(INK_DEEP, Color("#3a4650"), 1, 6, 0))
		t.set_stylebox("grabber_area", slider, _box(BRASS, BRASS, 0, 6, 0))
		t.set_stylebox("grabber_area_highlight", slider, _box(BRASS_LIGHT, BRASS_LIGHT, 0, 6, 0))

	for bar in ["VScrollBar", "HScrollBar"]:
		t.set_stylebox("scroll", bar, _box(Color(0, 0, 0, 0.25), Color(0, 0, 0, 0), 0, 6, 0))
		t.set_stylebox("grabber", bar, _box(Color(BRASS.r, BRASS.g, BRASS.b, 0.75), Color(0, 0, 0, 0), 0, 6, 0))
		t.set_stylebox("grabber_highlight", bar, _box(BRASS_LIGHT, Color(0, 0, 0, 0), 0, 6, 0))
		t.set_stylebox("grabber_pressed", bar, _box(BRASS_LIGHT, Color(0, 0, 0, 0), 0, 6, 0))
	return t


## Use on big headings: KW.style_title(label, 32)
func style_title(label: Label, size: int = 32) -> void:
	if title_font != null:
		label.add_theme_font_override("font", title_font)
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", BRASS_LIGHT)
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	label.add_theme_constant_override("outline_size", 4)


# ------------------------------------------------------------------ button feel

func _on_node_added(n: Node) -> void:
	if n is BaseButton and not n.has_meta("kw_no_fx"):
		var b := n as BaseButton
		b.button_down.connect(_on_button_down.bind(b))
		b.button_up.connect(_on_button_up.bind(b))


func _on_button_down(b: BaseButton) -> void:
	if not is_instance_valid(b) or b.disabled:
		return
	b.pivot_offset = b.size * 0.5
	if not reduce_motion:
		var tw := b.create_tween()
		tw.tween_property(b, "scale", Vector2(0.96, 0.96), 0.06)
	buzz(12)
	sfx("ui_tap")


func _on_button_up(b: BaseButton) -> void:
	if not is_instance_valid(b):
		return
	if not reduce_motion:
		var tw := b.create_tween()
		tw.tween_property(b, "scale", Vector2.ONE, 0.10).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	else:
		b.scale = Vector2.ONE


func buzz(ms: int = 15) -> void:
	if haptics and OS.has_feature("mobile"):
		Input.vibrate_handheld(ms)


# ------------------------------------------------------------------ audio (ignored until files exist)

func sfx(id: String, volume_db: float = -4.0) -> void:
	if not sfx_enabled:
		return
	var path: String = SFX_DIR + id + ".ogg"
	if not ResourceLoader.exists(path):
		return
	var p := AudioStreamPlayer.new()
	p.stream = load(path)
	p.volume_db = volume_db
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()


func music(id: String, fade: float = 0.8) -> void:
	if id == _music_id:
		return
	var path: String = MUSIC_DIR + id + ".ogg"
	if not ResourceLoader.exists(path):
		return
	_music_id = id
	var stream: AudioStream = load(path)
	if "loop" in stream:
		stream.loop = true
	var tw := create_tween()
	if _music.playing:
		tw.tween_property(_music, "volume_db", -40.0, fade * 0.5)
	tw.tween_callback(func() -> void:
		_music.stream = stream
		_music.volume_db = -40.0
		_music.play())
	tw.tween_property(_music, "volume_db", -8.0, fade)


# ------------------------------------------------------------------ transitions

func _build_fade() -> void:
	_fade_layer = CanvasLayer.new()
	_fade_layer.layer = 128
	add_child(_fade_layer)
	_fade_rect = ColorRect.new()
	_fade_rect.color = Color(0.03, 0.05, 0.07, 0.0)
	_fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fade_layer.add_child(_fade_rect)


## Fade out, switch scene, fade in. Input is blocked while fading.
func goto(path: String, duration: float = 0.22) -> void:
	if _busy:
		return
	_busy = true
	var d: float = 0.0 if reduce_motion else duration
	_fade_rect.mouse_filter = Control.MOUSE_FILTER_STOP
	var out_tw := create_tween()
	out_tw.tween_property(_fade_rect, "color:a", 1.0, d)
	await out_tw.finished
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var in_tw := create_tween()
	in_tw.tween_property(_fade_rect, "color:a", 0.0, d)
	await in_tw.finished
	_fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false
