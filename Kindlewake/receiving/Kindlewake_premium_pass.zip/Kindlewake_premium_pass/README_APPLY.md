# Premium Pass v1 — how to apply (5 minutes)
Based on your newest APK (Kindlewake-1.apk), which already contains the Chapter I / creator fixes.

1. Copy `scripts/ui/world_scene.gd` and `scripts/ui/battle_scene.gd` over the same files in your project.
   (Only small, reviewed changes — see `diffs/`. If those files changed since your last APK, apply the .diff by hand instead.)
2. Copy `scripts/core/kw.gd` into `scripts/core/`.
3. Godot: Project > Project Settings > Autoload > add `res://scripts/core/kw.gd` with name **KW**.
   Instantly gives every Button press-animation + haptic + click-sound hook, a global brass/ink theme for sliders, inputs,
   scrollbars, popups and progress bars, and `KW.goto(path)` fade transitions. Nothing breaks if you skip it.
4. Optional but high-impact: drop fonts in `res://assets/fonts/body.ttf` + `title.ttf`, sounds in `res://assets/audio/sfx/*.ogg`
   (ui_tap, ui_confirm, hit, miss, level_up) and music in `res://assets/audio/music/*.ogg` (title, world, town, battle). They load automatically.
5. Rebuild and run the checklist at the end of docs/DESIGN_REVIEW.md.

What the two script patches fix (seen in your screenshots):
- Minimap + HUD drawn on top of the Company screen  -> overlay is raised to the top.
- Turn-order chips "TOR/ROA/ROA" -> readable names (Torren, Reaver, Bowman), wider chips.
- Overlapping unit name tags ("Torren Du…", "Sela Wren…") -> tag only on the active/inspected unit, outlined.
- Floating "Mis" clipped -> popups widened + outlined ("Miss", damage numbers readable).
Not tested in the Godot editor (none available here) — please build and check.
