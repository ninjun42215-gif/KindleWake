# How to upload this to GitHub (KindleWake)

1. Open your repo on GitHub → **Add file → Upload files**.
2. Upload `docs/` and `MASTER_PROMPT.md` to the repo root (they do not touch game code).
3. The three fixed scripts live INSIDE your `Kindlewake_Project.zip` (the repo stores the Godot project as a zip).
   Unzip your project locally, copy `patch_scripts_ui/*.gd` over `scripts/ui/` (same filenames), re-zip as
   `Kindlewake_Project.zip`, and upload it to replace the old one. (Best long-term: commit the project UNZIPPED so
   diffs, Actions and AI tools can read the code — see MASTER_PROMPT.md, Phase 0.)
4. Commit, let your Actions workflow build the APK, install, and run the test checklist in docs/ANALYSIS_Kindlewake_v0.12.md §6.

Note: I could not read your repo's CONTINUATION_PROMPT.md or GDD from here (GitHub blocked direct file access), so
the analysis is based on the scripts and data inside your built APK (v0.12.0). The master prompt tells the next AI to
read your handoff files first so nothing in them is overridden.
