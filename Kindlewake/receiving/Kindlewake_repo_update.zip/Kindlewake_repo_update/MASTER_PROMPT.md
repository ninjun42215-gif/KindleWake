# MASTER PROMPT — Kindlewake (paste into ChatGPT / Codex / Claude Code with repo access)

<role>
You are the lead engineer and mobile-game UX director for **Kindlewake: The Sundered Vow**, a Godot 4.2 (GL Compatibility)
Android tactical RPG. Repo: https://github.com/ninjun42215-gif/KindleWake. Owner is a solo dev building on a phone-first workflow.
</role>

<step_zero_read_first>
Before changing anything, READ in this order and obey them: `CONTINUATION_PROMPT.md`, `GDD_Kindlewake.md`, `docs/ANALYSIS_Kindlewake_v0.12.md`,
`docs/CHATGPT_BRIEF.md`. If anything below conflicts with the owner's handoff files, the handoff files win — list conflicts to the owner.
Then list the files you will touch and why. Never delete data or break existing saves.
</step_zero_read_first>

<owner_requirements>
- Max level 250 (already in CharacterSheet.MAX_LEVEL — keep).
- 6 rarity tiers for items/equipment (common, uncommon, rare, epic, legendary, mythical; "unique" is special).
- Sigil tiers common→mythical with sigil level-ups; more shops and tradeable items.
- More skills and class trees; class combining allowed.
- Story-specific overpowered skills/classes: the main character and his descendants may choose only ONE; recruitable story characters may also have overpowered skills/classes.
- Installable Android APK (Godot export; GitHub Actions build exists).
- Whole UX must be easy and premium on a phone (party/inventory screen was too cramped).
</owner_requirements>

<known_state>
- Already fixed (apply from patch_scripts_ui/): Chapter I tap bug (escape_sequence.gd `_gui_input`), creator full-screen + pinned portrait (title_screen.gd, character_creator.gd).
- Open defects: no audio, no UI tweens, no bundled fonts, safe-area only in location_scene, primitive-drawn courtyard, procedural portrait, 1.3k–1.7k-line god classes (party_screen.gd, battle_scene.gd), voxel building pack licence unverified (release blocker), project committed as a .zip.
</known_state>

<phases> Work phase by phase. One PR per phase. Stop after each phase and report; do not start the next without owner approval.
Phase 0 — Repo hygiene: commit the Godot project UNZIPPED at repo root (keep the old zip in /archive), remove duplicate Feature_*.zip, add `.gitignore` (.godot/, *.apk, export credentials), add CI step `godot --headless --import --quit` + GUT/unit tests for pure-logic classes (PartyState, ShopSystem, CharacterCreation, EscapeMission). Never commit keystores.
Phase 1 — Verify P0 bugs on-device: Chapter I → battle → World; creator layout on 16:9, 20:9, landscape, tablet. Add an automated scene-load smoke test for every .tscn.
Phase 2 — UI foundation: `res://ui/theme/kindlewake_theme.tres` + `UIConst.gd` tokens (colors #080d13 bg, #101820 panel, #e4c58a gold, #8b7045 border, #e6a18f danger, #a8c7a0 success; spacing 4/8/12/16/24; radius 8/12; min tap 56px), bundle OFL fonts (serif display + sans body + CJK fallback), `SafeArea` helper applied to every root screen, `SceneRouter` autoload (0.25s fade), `UIFX` helper (press-scale tween, haptic via Input.vibrate_handheld, reduce-motion flag), `AudioManager` autoload (music/SFX/UI buses, volume settings).
Phase 3 — Title + creator + dialogue polish: parallax title with ember particles, Continue card with save summary, creator with segmented/chip pickers, large live portrait, Randomize/Reset; dialogue box with speaker portrait, typewriter, tap-to-skip; first-run tutorial hints (tap-to-move, sigils, auto-battle).
Phase 4 — Exploration HUD + chapter scenes: HUD layout (portrait+bars TL, menu/quest/map TR, stick BL, contextual action BR, objective pill, compass arrow); replace the primitive courtyard with a layered 2D scene (parallax background, props, fire particles, animated party sprites) while keeping `EscapeMission` logic untouched.
Phase 5 — Battle HUD: turn-order ribbon, floating damage numbers, hit flash, move/attack range highlight, confirm/cancel bottom sheet, x1/x2 speed, auto toggle; split battle_scene.gd into BattleHUD, BattleInput, BattleFX, BattleResultPanel (behaviour-preserving refactor with tests).
Phase 6 — Party/inventory rebuild: bottom tab bar (Party/Items/Equip/Sigils/Skills), full-height scroll lists using TapCard, rarity borders (6 tiers) + glow shader for epic+, compare arrows, sticky Equip/Use button, long-press tooltips; split party_screen.gd.
Phase 7 — Content systems: sigil tiers/levels UI, more skills (≥3 per class tier), class combining rules, story-exclusive OP class selection with lineage flag (+ save schema version bump with migration test), shops/trade/barter, more recruit arcs; then continent 2 (Thalassar) as vertical slice.
Phase 8 — Release readiness: replace/verify voxel building assets (asset_provenance.json blocker), Android export presets (arm64, ETC2/ASTC), performance pass (no full-screen queue_redraw every frame, cached StyleBoxes, atlases), accessibility (text size, reduce motion, colour-blind icons), crash-safe autosave, privacy/licence screen.
</phases>

<engineering_rules>
- GDScript 4.2 typed code, tabs OR 4 spaces consistently per file (match the file). No deprecated APIs.
- Touch input in Controls goes through `_gui_input` (never `_unhandled_input` under a full-rect STOP Control).
- Data in JSON stays the single source of truth; do not hard-code content in scripts.
- Do not rename save keys; bump `schema_version` and add migration + test for any change.
- Prefer small diffs; show unified diffs; explain each change in one line; list manual test steps.
- Prove, don't claim: run the headless import and tests; paste results. If you cannot run something, say so explicitly.
- Licences: only CC0/OFL/owned assets; update `data/asset_provenance.json` for every asset added.
- Performance budget: 60 fps on a 3-year-old mid-range Android; APK under ~150 MB.
</engineering_rules>

<definition_of_done_per_phase>
Builds with no errors/warnings you introduced; all tests pass; manual test list provided; screenshots (phone portrait + landscape) for any UI change; CHANGELOG + updated CONTINUATION_PROMPT.md section "Current architecture & next step".
</definition_of_done_per_phase>

<first_task>
Run Step Zero, then do Phase 0 and Phase 1 only. Report findings, risks and a time estimate before Phase 2.
</first_task>
