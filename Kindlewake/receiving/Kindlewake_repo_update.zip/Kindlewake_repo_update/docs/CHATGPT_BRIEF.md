# Kindlewake — brief for ChatGPT / Codex (paste this whole file)

Repo: https://github.com/ninjun42215-gif/KindleWake  (Godot 4.2, GL Compatibility, Android APK, UI built in code)
Please keep all existing systems/data. Work on branch `fix/ch1-and-creator-ux`. Do not rewrite unrelated files.

## 1. Bugs already diagnosed (fixes attached as 3 .gd files — apply them first)

### A. Chapter 1 "Burning Courtyard" — taps do nothing, never reaches Postern Gate
File: `scripts/ui/escape_sequence.gd`
Cause: root `Control` (full-rect, default `mouse_filter = STOP`) consumes every touch, so `_unhandled_input()` never fires.
Fix: read taps/drags in `_gui_input()`, clamp target to playable area, gate reach radius 120px, gate placed below the objective card.

### B. "Begin a New Chronicle" misaligned, portrait not visible
Files: `scripts/ui/title_screen.gd`, `scripts/ui/character_creator.gd`
Cause: creator was instanced INSIDE the 440px title card with `custom_minimum_size.y = 430`, so its own full-rect backdrop/margins were squeezed; on narrow screens the portrait (`CharacterPreview`) was appended AFTER 11 dropdowns, i.e. off-screen at the bottom of the scroll.
Fix: creator is now a full-screen overlay on the title screen; on phones the portrait + compact summary is pinned ABOVE the scrolling form and updates live. Desktop layout unchanged.

### C. Please verify (I could not run Godot headless)
1. Title → NEW GAME → creator fills screen, portrait visible at top, BACK returns to menu.
2. BEGIN CHRONICLE → Prologue → choice → Escape.tscn → tap moves party → "BREAK THROUGH THE POSTERN" button appears → battle_01 starts → victory sets `east_gallery_escaped` → World.tscn.
3. Test on 20:9 phone portrait AND landscape (check `display/window/handheld/orientation`, safe-area/notch).
4. Add GUT or a simple headless smoke test + GitHub Action step that runs `godot --headless --quit` to catch parse errors before building the APK.

## 2. Premium UX / UI / HUD upgrade plan (in priority order)

**Foundation (do first)**
- One global `Theme` resource (`res://ui/kindlewake_theme.tres`) — fonts, colors, StyleBoxes, button/panel/slider/OptionButton styles. Remove per-screen inline StyleBoxFlat. Extend existing `premium_ui_theme.gd`.
- Design tokens: bg #080d13, panel #101820, gold #e4c58a, border #8b7045, danger #e6a18f, success #a8c7a0. Spacing scale 4/8/12/16/24. Min touch target 56px.
- Real fonts: a serif display face (e.g. Cinzel / Cormorant) for titles, a readable sans (e.g. Inter / Noto Sans) for body — bundle OFL fonts. Never rely on `ThemeDB.fallback_font`.
- Safe-area helper (`DisplayServer.get_display_safe_area()`) applied to every root screen; responsive layout helper (phone portrait / phone landscape / tablet).
- `SceneRouter` autoload with fade transitions (0.25s), no hard `change_scene_to_file` cuts.

**Navigation / menu**
- Title: animated parallax illustration, soft ember particles (CPUParticles2D), logo glow, primary button visually dominant, "Continue" shows last save summary (chapter, location, playtime).
- Replace OptionButton popups in creator with swipeable chips/segmented pickers and a big live portrait; add "Randomize" and "Reset".
- Settings: music/SFX/UI volume, text size (Small/Normal/Large), vibration, reduce motion, language.

**HUD (exploration + battle)**
- Top-left: portrait + HP/MP/XP bars with tween animation; top-right: menu/quest/map buttons (56px); bottom-left virtual stick (exists) with dead-zone and fade-when-idle; bottom-right context action button that changes label (Talk / Open / Enter).
- Objective tracker pill (collapsible) + minimap/compass edge arrow toward objective.
- Battle: turn-order bar across the top with portraits, floating damage numbers, hit flash, screen shake (respect reduce-motion), tile highlight for move/attack range, confirm/cancel bottom sheet, speed x1/x2 toggle, auto-battle toggle.
- Toasts for loot/quest updates; slide-in dialogue box with speaker portrait, typewriter text, tap-to-skip.

**Party / inventory (already flagged as cramped)**
- Bottom tab bar (Party · Items · Equip · Sigils · Skills), full-height scrollable card lists (use existing `TapCard`), item rarity borders for the 6 rarity tiers, comparison arrows (green/red) when equipping, sticky Equip/Use button.
- Stat bars instead of raw numbers where possible; tooltips by long-press.

**Juice & polish**
- Button press scale tween (0.96) + haptic (`Input.vibrate_handheld(15)`), click/hover SFX, ambient music per location, page transitions, rarity glow shader for legendary/mythic items.
- Loading/empty/error states for every list. Autosave toast.

**Performance (Android)**
- Keep GL Compatibility; texture atlases, ETC2/ASTC import, avoid per-frame `queue_redraw()` on full screen unless animating, cache StyleBoxes, test on a low-end device (target 60fps UI).

## 3. Deliverables requested
1. Apply the attached fixes, then PR with a short changelog.
2. Implement "Foundation" + "Navigation/menu" + exploration HUD first (one PR each).
3. Provide updated `CONTINUATION_PROMPT.md` so future sessions know the current UI architecture.
