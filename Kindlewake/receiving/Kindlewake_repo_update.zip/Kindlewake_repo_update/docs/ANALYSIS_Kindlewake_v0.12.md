# Kindlewake v0.12.0 — Deep Analysis (from the built APK)

Method: unpacked `Kindlewake.apk`, read all 38 GDScript files (~10.2k lines) and 17 data JSON files. Not run on a device.

## 1. What the game is today
- Godot 4.2, GL Compatibility, touch-first, almost entirely UI-built-in-code (scenes are one-node shells).
- Story: Prologue (choice: rescue people / take record / split) → Chapter I escape courtyard → tactical battle → Sethmarch Frontier overworld.
- Systems present: FF7-style sigil/rune system (77 runes, 11 sigils, AP/levels), 28 classes, 34 characters, 106 items (70 weapons),
  6 rarity tiers + "unique", level cap 250 (already implemented), turn-based grid battles with AI + auto-battle,
  saves (slots 1-3 + autosave A/B), shops with regional stock, 38 town/dungeon maps, 7-continent atlas (only Eldrimar + a Brinegate Coast slice playable).
- Strong data-driven design (JSON), save versioning and tests-friendly pure-logic classes (PartyState, ShopSystem, EncounterBuilder).

## 2. Defects found (ranked)
| # | Severity | Finding | Status |
|---|---|---|---|
| 1 | BLOCKER | Chapter I courtyard: taps never register (root Control STOP swallows input; handler was `_unhandled_input`) | Fixed in patch |
| 2 | HIGH | New-chronicle creator embedded in 440px title card, 430px tall → misaligned; portrait placed after 11 dropdowns, off-screen | Fixed in patch |
| 3 | HIGH | No audio at all (0 sound files, no AudioStreamPlayer) | Open |
| 4 | HIGH | No UI animation: no Tween anywhere → screens feel static, buttons give no feedback, no transitions | Open |
| 5 | HIGH | Release blocker in `asset_provenance.json`: "Voxel building packs" licence unverified (used in game) | Open — replace or verify before any public release |
| 6 | MED | No bundled fonts → default Godot font on every screen; CJK/ID language glyph risk | Open |
| 7 | MED | Safe-area (notch) handled only in location_scene; title, creator, prologue, escape, party, battle ignore it | Partly fixed (creator top margin) |
| 8 | MED | Magic numbers in escape_sequence (150/120px) assume portrait phone; fragile on tablets/landscape | Improved |
| 9 | MED | Escape scene is drawn with primitives (circles/rects) — reads as a prototype, not a chapter opener | Open |
| 10 | MED | Creator portrait is a procedural geometric bust (documented as "not production art") | Open |
| 11 | LOW | party_screen.gd 1341 lines, battle_scene.gd 1763 lines: God-classes; hard to theme/test | Open |
| 12 | LOW | Project stored as `Kindlewake_Project.zip` in git: no diffs, no code review, AI tools can't read it | Open — commit unzipped |
| 13 | LOW | Several `Feature_*.zip` files in repo root duplicate code | Open |

## 3. Why the game does not yet feel "premium"
1. **No motion language**: nothing fades, slides, eases or pulses. Premium mobile RPGs animate every state change (150–300 ms).
2. **No sound**: UI taps, ambience, music, battle SFX are 50% of perceived quality.
3. **Primitive visuals in key moments**: courtyard, creator bust and map props are flat shapes next to SVG illustration — inconsistent art direction.
4. **Typography**: one default font, sizes hard-coded per screen (14–34).
5. **Layout built per-screen in code** with magic numbers instead of one Theme + layout helpers → inconsistent spacing, cramped party screen.
6. **Feedback gaps**: no haptics, no damage numbers/hit-flash audit, no loading/empty/error states, no autosave toast.
7. **Onboarding**: no tutorial for tap-to-move, sigils, auto-battle; first 5 minutes decide retention.

## 4. UX / UI / HUD target (concise)
- Global `Theme` + tokens (colors/spacing/radius/font sizes) → apply to every Control. Min touch target 56 px.
- Bundled fonts: serif display (Cinzel/Cormorant) + sans body (Inter/Noto) + CJK fallback; OFL only.
- `SceneRouter` autoload: fade transitions, safe-area wrapper, orientation handling.
- Exploration HUD: portrait+HP/MP top-left, objective pill, menu/quest/map top-right, virtual stick bottom-left (fade when idle), contextual action button bottom-right, compass arrow to objective.
- Battle HUD: turn-order ribbon with portraits, floating damage numbers, range tiles, confirm/cancel bottom sheet, x1/x2 speed, auto toggle.
- Party/inventory: bottom tab bar, full-height card lists (TapCard), rarity borders for 6 tiers, equip comparison arrows, sticky action button, long-press tooltips.
- Juice: press-scale tween + haptic, ember particles on title, rarity glow shader for epic+, screen shake (reduce-motion aware).
- Accessibility: text size setting, reduce-motion, colour-blind-safe rarity icons, vibration toggle.

## 5. Content/systems backlog (matches your stated goals)
- More shops + tradeable items (regional stock exists for 8 shops; add player-to-NPC trade/barter, sell-back rules, price drift by region).
- Sigil tiers common→mythical with level-ups (grades exist in items.json; runes have `grade`) — unify naming "rune" vs "sigil" in UI and data.
- More classes/skills (28 classes, 15 skills only → skills are the bottleneck: ≥3 skills per class tier).
- Story-exclusive overpowered classes: protagonist + descendants pick ONE (needs `lineage` flag + generational save schema).
- Recruitable characters with story-locked OP skills; 34 characters defined but only a few have authored arcs.
- Continents 2–7 are gated stubs: need region maps, quests, encounters, travel links, tests per the notes in continents.json.
- Save schema: version bump + migration test before adding lineage/generations.

## 6. Test checklist for the patched build
1. Title → NEW GAME: creator fills screen, portrait + summary visible at top, form scrolls, BACK returns to menu.
2. Change every dropdown; portrait updates live; BEGIN CHRONICLE enabled only when 8 attribute points are spent.
3. Prologue choice → Continue → courtyard: tap anywhere → party glides → gate button appears → battle starts.
4. Win battle → returns to world, banner "The postern is behind you…", flag `east_gallery_escaped` saved; kill app, Continue works.
5. Lose battle → "Retry Escape" works.
6. Rotate device; test 16:9 and 20:9; notch not covering buttons.

## 7. Priority roadmap
- **P0 (this week):** apply patch, verify Chapter I→World, commit project unzipped, add CI parse check (`godot --headless --import --quit`).
- **P1:** Theme+fonts+SceneRouter+safe-area; title screen polish; audio pack (CC0/licensed) + AudioManager; haptics.
- **P2:** Exploration HUD, dialogue box, battle HUD, party screen rebuild.
- **P3:** Replace primitive courtyard with authored art; real portraits (layered paper-doll sprites); resolve voxel licence blocker.
- **P4:** Content: skills, classes, sigil tiers, shops/trade, continent 2.
